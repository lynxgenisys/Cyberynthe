import React, { useMemo, useEffect, useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGame } from '../../context/GameContext';
// import { generateMaze } from '../../engine/MazeGenerator'; // Legacy Sync
// Worker Import handled via new URL() pattern
import { RigidBody, CuboidCollider } from '@react-three/rapier';
import MobManager from './MobManager';
import LootManager from './LootManager';
import InstancedWalls from './InstancedWalls';

import HazardManager from './HazardManager';
import * as THREE from 'three';

import wallGlitchASrc from '../../assets/Wall_GlitchCode_A.webp';
import wallGlitchBSrc from '../../assets/Wall_GlitchCode_B.webp';
import wallGlitchAASrc from '../../assets/Wall_GlitchCode_AA.webp';
import wallCityASrc from '../../assets/Wall_City_A.webp';
import floorTexSrc from '../../assets/Floor_A.webp';

/**
 * IDENTITY: ARCH_SYS_01
 * DIRECTIVE: Render the 3D Labyrinth with HD Procedural Textures & Objectives
 * OPTIMIZATION: InstancedMesh for Walls (Draw Calls: ~1)
 */

// Advanced Procedural Texture Generator (Kept same)
const createProceduralTexture = (type, preset = 'DEFAULT') => {
    const size = 1024;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');

    if (type === 'WALL_GRID') {
        // PRESET LOGIC
        const isSector2 = preset === 'SECTOR_02';

        // 1. Base: True Black for Sector 1, Dark Navy for Sector 2
        const gradient = ctx.createLinearGradient(0, 0, 0, size);
        gradient.addColorStop(0, isSector2 ? '#000510' : '#000000');
        gradient.addColorStop(1, isSector2 ? '#001133' : '#000000');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);

        // 2. Scanline Noise (High Res) - Subtle
        ctx.fillStyle = isSector2 ? '#000000' : '#050510';
        for (let i = 0; i < size; i += 2) {
            if (Math.random() > 0.8) ctx.fillRect(0, i, size, 1);
        }

        // 3. The Grid
        // SECTOR 2: COPPER TRACE (#B87333) vs SECTOR 1: CYAND GLOW (#00FFFF)
        const mainColor = isSector2 ? '#B87333' : '#00FFFF';
        const glowColor = isSector2 ? '#aa4400' : '#00FFFF';
        const secondaryColor = isSector2 ? '#552200' : '#008888';

        // Outer Glow
        ctx.strokeStyle = secondaryColor;
        ctx.lineWidth = 16;
        ctx.shadowBlur = 20;
        ctx.shadowColor = glowColor;
        ctx.strokeRect(0, 0, size, size);

        // Core Line
        ctx.strokeStyle = mainColor;
        ctx.lineWidth = 6;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#FFFFFF';
        ctx.strokeRect(0, 0, size, size);

        // Cross-Section (Subtle)
        ctx.strokeStyle = secondaryColor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(size / 2, 0); ctx.lineTo(size / 2, size);
        ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2);
        ctx.stroke();

        // 4. Data Nodes (Corners)
        ctx.fillStyle = mainColor;
        ctx.shadowBlur = 30;
        ctx.shadowColor = glowColor;
        const nodeSize = 24;
        ctx.fillRect(0, 0, nodeSize, nodeSize);
        ctx.fillRect(size - nodeSize, 0, nodeSize, nodeSize);
        ctx.fillRect(0, size - nodeSize, nodeSize, nodeSize);
        ctx.fillRect(size - nodeSize, size - nodeSize, nodeSize, nodeSize);
    }
    else if (type === 'FLOOR_PLATE') {
        // 1. Base: Wet Black Asphalt Look
        ctx.fillStyle = '#020202';
        ctx.fillRect(0, 0, size, size);

        // 2. Hex Pattern (Subtle)
        ctx.strokeStyle = '#111111';
        ctx.lineWidth = 1;
        ctx.beginPath();
        const hexSize = size / 8;
        for (let y = 0; y < size; y += hexSize) {
            for (let x = 0; x < size; x += hexSize) {
                const xOff = (y / hexSize) % 2 === 0 ? 0 : hexSize / 2;
                ctx.strokeRect(x + xOff, y, hexSize, hexSize);

                // Random Neon Puddles (Reflection Hints)
                if (Math.random() > 0.98) {
                    ctx.fillStyle = Math.random() > 0.5 ? '#003333' : '#330033'; // Deep Cyan/Magenta
                    ctx.fillRect(x + xOff + 4, y + 4, hexSize - 8, hexSize - 8);
                }
            }
        }
        ctx.stroke();

        // 3. Navigation Lines (Gradient Flow)
        const lineGrad = ctx.createLinearGradient(0, 0, size, 0); // Horizontal Gradient across line? Or Vertical path?
        // Line is "MoveTo(0, size/2) LineTo(size, size/2)" -> Horizontal line across texture.
        lineGrad.addColorStop(0, '#00FFFF');
        lineGrad.addColorStop(0.5, '#EA00FF');
        lineGrad.addColorStop(1, '#00FFFF');

        ctx.strokeStyle = lineGrad;
        ctx.lineWidth = 6;
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#00FFFF';
        ctx.beginPath();
        ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2);
        ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.needsUpdate = true;
    return texture;
};

// Extracted EXIT Component to handle Scan State
const ExitTile = ({ x, z, gameState, advanceFloor, addNotification, WallHeight, CellSize }) => {
    const [scanTimer, setScanTimer] = useState(0);
    const meshRef = useRef();

    // SCAN & ANIMATION LOGIC
    useFrame((state, delta) => {
        // 1. ANIMATION (Rotate & Pulse)
        if (meshRef.current) {
            meshRef.current.rotation.y += delta * 0.5; // Slow Rotate
            const pulse = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.1; // 1.0 to 1.2
            meshRef.current.scale.setScalar(pulse);
        }

        // 2. SCAN VISIBILITY
        if (gameState.lastScanTime) {
            const playerX = gameState.playerGridPos?.x * 2 || 0;
            const playerZ = gameState.playerGridPos?.y * 2 || 0;
            const dx = playerX - x;
            const dz = playerZ - z;
            const distSq = dx * dx + dz * dz;

            const scanAge = (Date.now() - gameState.lastScanTime) / 1000;
            if (scanAge < 2.5) {
                const waveRadius = scanAge * 25;
                const dist = Math.sqrt(distSq);
                if (dist < waveRadius && dist > waveRadius - 5) {
                    if (scanTimer <= 0) setScanTimer(10.0);
                }
            }
        }
        if (scanTimer > 0) setScanTimer(prev => prev - delta);
    });

    return (
        <group>
            {/* PHYSICAL BARRIER IF LOCKED */}
            {gameState.isPortalLocked && (
                <RigidBody position={[x, WallHeight / 2, z]} type="fixed">
                    <CuboidCollider args={[0.4, WallHeight / 2, 1.0]} />
                    {/* Red Forcefield */}
                    <mesh>
                        <boxGeometry args={[1.8, WallHeight, 0.2]} />
                        <meshBasicMaterial color="#FF0000" wireframe transparent opacity={0.3} />
                    </mesh>
                </RigidBody>
            )}

            <RigidBody
                type="fixed"
                sensor
                onIntersectionEnter={() => {
                    if (gameState.isPortalLocked) {
                        addNotification("PORTAL_LOCKED: REQUIRES_KERNEL_KEY");
                    } else {
                        addNotification("PORTAL_BREACH: ADVANCING...");
                        advanceFloor();
                    }
                }}
                position={[x, 0, z]}
            >
                <group>
                    <pointLight
                        color={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                        intensity={2}
                        distance={5}
                        position={[0, 2, 0]}
                    />
                    <mesh ref={meshRef} position={[0, WallHeight / 2, 0]}>
                        <torusGeometry args={[1, 0.2, 16, 32]} />
                        <meshStandardMaterial
                            color={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                            emissive={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                            emissiveIntensity={2}
                        />
                    </mesh>

                    {/* SCAN REVEAL BEACON */}
                    {scanTimer > 0 && (
                        <mesh position={[0, 10, 0]}> {/* Tall Beacon */}
                            <cylinderGeometry args={[0.1, 0.1, 20]} />
                            <meshBasicMaterial color="#EA00FF" transparent opacity={0.5} depthTest={false} />
                        </mesh>
                    )}

                    {/* WIREFRAME CAGE (Only if Locked) */}
                    {gameState.isPortalLocked && (
                        <mesh position={[0, WallHeight / 2, 0]}>
                            <boxGeometry args={[2.2, WallHeight, 2.2]} />
                            <meshBasicMaterial color="#FF0000" wireframe transparent opacity={0.5} />
                        </mesh>
                    )}
                </group>
            </RigidBody>
        </group>
    );
};

export default function MazeRenderer() {
    // ... (Hooks kept same)
    const { gameState, advanceFloor, setGameState, addNotification } = useGame();

    // CONSTANTS
    const CELL_SIZE = 2;
    const WALL_HEIGHT = 4;

    // 1. GENERATE MAZE (Async Web Worker)
    const [maze, setMaze] = useState(null);

    useEffect(() => {
        // Clear previous maze immediately to prevent ghost rendering while worker matches new seed
        setMaze(null);

        // Instantiate Worker
        const worker = new Worker(new URL('../../workers/maze.worker.js?v=13', import.meta.url), { type: 'module' });

        worker.onmessage = (e) => {
            if (e.data.success) {
                console.log(`[MAZE_RENDERER]: Worker Success | Size: ${e.data.data.width}x${e.data.data.height} | Start: ${e.data.data.metadata?.start?.x},${e.data.data.metadata?.start?.y}`);

                // DEBUG: Inspect Center Row for Pillars
                if (e.data.data.grid && e.data.data.grid[15]) {
                    console.log(`[MAZE_DEBUG_ROW_15]: ${JSON.stringify(e.data.data.grid[15])}`);
                }

                setMaze(e.data.data);
            } else {
                console.error('[MAZE_RENDERER]: Worker Failed', e.data.error);
            }
            worker.terminate(); // One-shot usage
        };

        worker.postMessage({ seed: gameState.seed, floorLevel: gameState.floorLevel });

        return () => {
            worker.terminate();
        };
    }, [gameState.seed, gameState.floorLevel]);





    // 3. MATERIALS (Memory Safe)
    const [materials, setMaterials] = useState(null);

    useEffect(() => {
        const isSector2 = gameState.floorLevel >= 11 && gameState.floorLevel <= 25;
        const preset = isSector2 ? 'SECTOR_02' : 'DEFAULT';

        // ASSET LOADING
        let wallTex = null;
        let floorTex = null;
        const loader = new THREE.TextureLoader();

        if (isSector2) {
            // SECTOR 2: CITY ASSETS
            console.log("[RENDERER]: APPLYING_SECTOR_02_TEXTURES (City A)");
            wallTex = loader.load(wallCityASrc);
            floorTex = createProceduralTexture('FLOOR_PLATE', preset); // Keep Procedural Floor

            wallTex.colorSpace = THREE.SRGBColorSpace;
            wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
        } else if (gameState.floorLevel === 999) {
            // BESTIARY MODE: PURE FLOOR_A
            console.log("[RENDERER]: APPLYING_BESTIARY_TEXTURES (Floor_A)");
            wallTex = loader.load(floorTexSrc);
            floorTex = loader.load(floorTexSrc);

            wallTex.colorSpace = THREE.SRGBColorSpace;
            floorTex.colorSpace = THREE.SRGBColorSpace;
            wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
            floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
            floorTex.repeat.set(4, 4);
        } else {
            // SECTOR 1: CYBER GLOW ASSETS
            // Level 1-10: Glitch Code AA (Unified)
            console.log(`[RENDERER]: APPLYING_SECTOR_01_ASSETS (Unified AA)`);

            wallTex = loader.load(wallGlitchAASrc);
            floorTex = loader.load(floorTexSrc);

            wallTex.colorSpace = THREE.SRGBColorSpace;
            floorTex.colorSpace = THREE.SRGBColorSpace;

            // Enable Wrapping for Scrolling Shader
            wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
            floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
            floorTex.repeat.set(4, 4);
        }

        const wallMat = new THREE.MeshStandardMaterial({
            color: '#FFFFFF',
            emissive: isSector2 ? '#aa4400' : '#00FFFF', // Copper vs Cyan
            emissiveIntensity: 0.8,
            emissiveMap: isSector2 ? wallTex : null, // Procedural used emissiveMap. New uses custom shader uTex.
            roughness: 0.2,
            metalness: 0.8,
            map: wallTex
        });

        const floorMat = new THREE.MeshStandardMaterial({
            color: isSector2 ? '#222233' : '#FFFFFF',
            roughness: isSector2 ? 0.4 : 0.1,
            metalness: isSector2 ? 0.5 : 0.8,
            map: floorTex,
            emissive: isSector2 ? '#000000' : '#444444', // Boost Sector 1 Floor Brightness
            emissiveMap: isSector2 ? null : floorTex,  // Self-illuminate texture lightly
            emissiveIntensity: 0.25 // 25% brightness boost
        });

        setMaterials({ wall: wallMat, floor: floorMat, wallTexture: wallTex });

        return () => {
            console.log('[RENDERER]: DISPOSING MATERIALS & TEXTURES');
            wallMat.dispose();
            if (wallMat.map) wallMat.map.dispose();
            if (wallMat.emissiveMap) wallMat.emissiveMap.dispose();
            floorMat.dispose();
            if (floorMat.map) floorMat.map.dispose();
        };
    }, [gameState.floorLevel]);

    if (!maze || !materials) return null;

    return (
        <MazeScene
            maze={maze}
            materials={materials}
            gameState={gameState}
            advanceFloor={advanceFloor}
            addNotification={addNotification}
            setGameState={setGameState}
            CELL_SIZE={CELL_SIZE}
            WALL_HEIGHT={WALL_HEIGHT}
        />
    );
}

// Sub-Component: Only renders when data is ready. Guarantees hook stability.
function MazeScene({ maze, materials, gameState, advanceFloor, addNotification, setGameState, CELL_SIZE, WALL_HEIGHT }) {
    const { wall: wallMaterial, floor: floorMaterial, wallTexture } = materials;

    // SYNC SPAWN POINT
    useEffect(() => {
        if (maze.metadata?.start) {
            const startNode = maze.metadata.start;
            setGameState(prev => ({
                ...prev,
                spawnPoint: { x: startNode.x * CELL_SIZE, y: 1.5, z: startNode.y * CELL_SIZE },
                playerGridPos: { x: startNode.x, y: startNode.y },
                mazeGrid: maze.grid,
                mazeWidth: maze.width,
                mazeHeight: maze.height
            }));
        }
    }, [maze, setGameState]);

    return (
        <group>
            {/* 1. INSTANCED GEOMETRY */}
            <InstancedWalls
                key={`walls-${gameState.floorLevel}`}
                maze={maze}
                wallMaterial={wallMaterial}
                cellSize={CELL_SIZE}
                wallHeight={WALL_HEIGHT}
                floorLevel={gameState.floorLevel}
                texture={wallTexture}
            />

            {/* 2. DYNAMIC OBJECTS */}
            {maze.metadata?.start && (
                <group position={[maze.metadata.start.x * CELL_SIZE, 0.1, maze.metadata.start.y * CELL_SIZE]}>
                    <mesh rotation={[-Math.PI / 2, 0, 0]}>
                        <ringGeometry args={[0.5, 0.8, 32]} />
                        <meshStandardMaterial color="#00FFFF" emissive="#00FFFF" emissiveIntensity={1} />
                    </mesh>
                </group>
            )}

            {maze.metadata?.exit && (
                <ExitTile
                    key={`exit-${maze.metadata.exit.x}-${maze.metadata.exit.y}`}
                    x={maze.metadata.exit.x * CELL_SIZE}
                    z={maze.metadata.exit.y * CELL_SIZE}
                    gameState={gameState}
                    advanceFloor={advanceFloor}
                    addNotification={addNotification}
                    WallHeight={WALL_HEIGHT}
                    CellSize={CELL_SIZE}
                />
            )}

            {/* FLOOR PLANE */}
            <RigidBody
                key={`floor-${maze.width}-${maze.height}`}
                type="fixed"
                rotation={[-Math.PI / 2, 0, 0]}
                position={[maze.width, -0.1, maze.height]}
            >
                <mesh receiveShadow>
                    <planeGeometry args={[maze.width * CELL_SIZE * 2, maze.height * CELL_SIZE * 2]} />
                    <primitive object={floorMaterial} attach="material" />
                </mesh>
            </RigidBody>

            {/* MOBS */}
            <MobManager maze={maze} floorLevel={gameState.floorLevel} />

            {/* HAZARDS */}
            <HazardManager maze={maze} floorLevel={gameState.floorLevel} />

            {/* LOOT */}
            <LootManager maze={maze} floorLevel={gameState.floorLevel} />
        </group>
    );
}
