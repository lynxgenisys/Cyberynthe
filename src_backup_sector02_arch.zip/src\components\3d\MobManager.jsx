import React, { useMemo, useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { MobLogic } from '../../engine/MobAI';
import { useCombat } from '../../context/CombatContext';
import { useGame } from '../../context/GameContext';
import { usePlayer } from '../../context/PlayerContext'; // For RAM Restore
import * as THREE from 'three';

import { useInventory } from '../../context/InventoryContext';

// --- ASSETS (MOB SKINS) ---
import biteMiteSkinSrc from '../../assets/mobs/Bite_Mite_Skin.webp';
import wispSkinSrc from '../../assets/mobs/null_wisp_skin.webp';
import sentrySkinSrc from '../../assets/mobs/stateless_sentry_skin.webp';
import hunterSkinSrc from '../../assets/mobs/hunter_skin.webp';

/**
 * IDENTITY: SCHEDULER_03
 * DIRECTIVE: Manage Entity Lifecycle (Spawning, AI, Rendering)
 */

const MAX_MOBS = 50; // Cap to prevent infinite loops and stabilize InstancedMesh

// --- BOSS FX COMPONENT (Extracted to prevent re-mount stutter) ---
const BossFX = ({ mob, maze }) => { // ADDED MAZE PROP
    const groupRef = useRef();
    const ring1 = useRef();
    const ring2 = useRef();
    const ring3 = useRef();
    const core = useRef();
    const beamRef = useRef(); // New Ref for Beam
    // Material Refs
    const coreMatRef = useRef();
    const ringMatRef = useRef(); // This ref is declared but not used in the provided logic, as materials are accessed via mesh refs.

    useFrame((state, delta) => {
        // --- 1. TRANSFORMS ---
        if (groupRef.current) {
            groupRef.current.position.set(mob.x, 2.0, mob.z);
            groupRef.current.scale.setScalar(0.45);

            if (mob.bossState === 'FIRING') {
                groupRef.current.rotation.y += delta * 2.0;

                // --- BEAM COLLISION LOGIC ---
                if (beamRef.current && maze && maze.grid) {
                    const rotY = groupRef.current.rotation.y;
                    // Beam Direction (Local Z is firing direction? Cylinder is rotated PI/2 on X)
                    // If Cylinder is Rot X 90, its local Y is World Z. 
                    // Wait, we position cylinder at -30 Z. So it points along -Z locally.
                    // Rotation Y of Group rotates that -Z vector.

                    const dirX = -Math.sin(rotY); // Standard rotation for -Z forward
                    const dirZ = -Math.cos(rotY);

                    // Raycast
                    let hitDist = 1000;
                    const maxDist = 1000;
                    const stepSize = 1.0;

                    for (let d = 2; d < maxDist; d += stepSize) {
                        const checkX = Math.round((mob.x + dirX * d) / 2);
                        const checkZ = Math.round((mob.z + dirZ * d) / 2);

                        if (maze.grid[checkZ] && maze.grid[checkZ][checkX] === 0) {
                            // PILLAR CHECK: Only stop if NOT an outer wall
                            const isOuterWall = checkX <= 0 || checkX >= maze.width - 1 || checkZ <= 0 || checkZ >= maze.height - 1;

                            if (!isOuterWall) {
                                hitDist = d;
                                break;
                            }
                        }
                    }

                    // Update Beam Geometry visuals
                    const scaleY = hitDist; // Unit Cylinder Scale
                    if (beamRef.current) {
                        beamRef.current.scale.y = scaleY;
                        beamRef.current.position.z = -hitDist / 2;
                    }
                }

            } else {
                groupRef.current.rotation.y += delta * 0.1;
            }
        }

        // Ring Rotations
        if (ring1.current) ring1.current.rotation.x += delta * 3.0;
        if (ring2.current) ring2.current.rotation.y -= delta * 2.4;
        if (ring3.current) ring3.current.rotation.z += delta * 3.6;
        if (core.current) core.current.rotation.y += delta * 0.2;

        // --- 2. MATERIAL UPDATES (State-Driven) ---
        const isCharging = mob.bossState === 'CHARGING';
        const isScanned = mob.scanTimer > 0;
        const isVulnerable = mob.isVulnerable;
        const phase = mob.phase || 1;

        // Core Color Logic
        const targetCoreColor = isVulnerable ? "#FFFF00" : (isCharging ? "#00FFFF" : (phase === 2 ? "#EA00FF" : "#00AAAA"));
        const targetCoreEmissive = isVulnerable ? "#FFFF00" : (isCharging ? "#00FFFF" : "#000044");

        if (coreMatRef.current) {
            coreMatRef.current.color.set(targetCoreColor);
            coreMatRef.current.emissive.set(targetCoreEmissive);
        }

        // Ring Color Logic
        const targetRingColor = isScanned ? "#00FF00" : "#111111";
        const targetRingEmissive = isScanned ? "#004400" : "#004444";
        const targetWireframe = isScanned;

        [ring1, ring2, ring3].forEach(ref => {
            if (ref.current && ref.current.material) {
                ref.current.material.color.set(targetRingColor);
                ref.current.material.emissive.set(targetRingEmissive);
                ref.current.material.wireframe = targetWireframe;
                ref.current.material.transparent = isScanned;
                ref.current.material.opacity = isScanned ? 0.5 : 1;
            }
        });
    });

    return (
        <group ref={groupRef}>
            {/* ... Core/Rings ... */}
            {/* CORE */}
            <mesh ref={core}>
                <dodecahedronGeometry args={[1.5, 0]} />
                <meshStandardMaterial
                    ref={coreMatRef}
                    color="#00AAAA" // Initial Default
                    emissive="#000044"
                    wireframe={false}
                    transparent={true}
                    opacity={0.8}
                    roughness={0.2}
                    metalness={0.8}
                />
            </mesh>

            {/* RINGS */}
            <mesh ref={ring1}>
                <torusGeometry args={[2.5, 0.1, 16, 100]} />
                <meshStandardMaterial color="#111111" emissive="#004444" />
            </mesh>
            <mesh ref={ring2}>
                <torusGeometry args={[3.2, 0.1, 16, 100]} />
                <meshStandardMaterial color="#111111" emissive="#004444" />
            </mesh>
            <mesh ref={ring3}>
                <torusGeometry args={[4.0, 0.1, 16, 100]} />
                <meshStandardMaterial color="#111111" emissive="#004444" />
            </mesh>

            {/* BEAM FX - Dynamic Scoring (Unit Cylinder) */}
            {mob.bossState === 'FIRING' && (
                <group>
                    <mesh ref={beamRef} position={[0, 0, -0.5]} rotation={[Math.PI / 2, 0, 0]}>
                        <cylinderGeometry args={[1, 4, 1, 8, 1, true]} />
                        <meshBasicMaterial color="#00FFFF" transparent opacity={0.6} side={THREE.DoubleSide} />
                    </mesh>
                </group>
            )}

            {/* SHOCKWAVE FX */}
            {mob.bossState === 'SHOCKWAVE' && (
                <mesh rotation={[-Math.PI / 2, 0, 0]}>
                    <ringGeometry args={[mob.shockwaveRadius - 1, mob.shockwaveRadius, 32]} />
                    <meshBasicMaterial color="#EA00FF" transparent opacity={0.8} />
                </mesh>
            )}

            {/* VULNERABLE TAG */}
            {(mob.isVulnerable || mob.scanTimer > 0) && (
                <mesh position={[0, 4, 0]}>
                    <planeGeometry args={[4, 1]} />
                    <meshBasicMaterial color="#000000" transparent opacity={0.5} />
                </mesh>
            )}
        </group>
    );
};

// --- KERNEL ACCESS SHARD ---
const KernelShard = ({ position, maze }) => {
    const meshRef = useRef();
    const particlesRef = useRef();
    const { gameState, setInteractionPrompt, lastInteractTime, setActiveLoreLog, unlockKernel } = useGame();
    const [isCollected, setIsCollected] = useState(false);

    // Track processed interaction to prevent loops, but allow simple "New > Old" check
    const lastProcessedRef = useRef(0);

    // VISUALS
    useFrame((state, delta) => {
        if (!meshRef.current || isCollected) return;

        // Hover & Rotate
        const time = state.clock.elapsedTime;
        meshRef.current.position.y = 1.0 + Math.sin(time * 1.5) * 0.2;
        meshRef.current.rotation.y += delta * 0.5;
        meshRef.current.rotation.z = Math.sin(time) * 0.1;

        // INTERACTION LOGIC
        if (gameState.playerGridPos) {
            const px = (gameState.playerGridPos.x || 1) * 2;
            const pz = (gameState.playerGridPos.y || 1) * 2;
            const dx = px - position.x;
            const dz = pz - position.z;
            const distSq = dx * dx + dz * dz;

            if (distSq < 9.0) { // 3m Radius
                setInteractionPrompt("[R] SYNCHRONIZE SHARD");

                // ROBUST CHECK: Trigger if we have a new interaction timestamp
                if (lastInteractTime && lastInteractTime > lastProcessedRef.current) {
                    console.log(`[SHARD]: INTERACTION_RECEIVED (TS: ${lastInteractTime})`);
                    lastProcessedRef.current = lastInteractTime; // Mark handled

                    setIsCollected(true);
                    setInteractionPrompt(null);

                    // TRIGGER LORE UI
                    const logData = {
                        id: "KERNEL_SHARD",
                        title: "FRAGMENT_ID: #0010_COMPROMISE",
                        text: "It’s heavy. Heavier than data should be.\n\nWhen your hand touches the crystalline lattice, you don't just download a key; you remember a moment. A conference room, centuries ago. The air smelling of ozone and stale coffee. Engineers arguing over the color of the sky in the new world they were building.\n\nYou voted for Cyan—for perfect, sterile order. Someone else voted for Magenta—for unrestrained, beautiful chaos.\n\nYou compromised on a Gradient. You built the Sentinel to guard that compromise. And now, you have destroyed it to finish the argument."
                    };
                    setActiveLoreLog(logData);
                }
            } else {
                // Clear prompt if we walked away (and it was us setting it)
                // NOTE: This might flicker if multiple interactables. Ideally InteractionManager.
                // For now, minimal conflict.
                if (gameState.interactionPrompt === "[R] SYNCHRONIZE SHARD") {
                    setInteractionPrompt(null);
                }
            }
        }
    });

    if (isCollected) return null;

    return (
        <group position={[position.x, 1, position.z]}>
            <mesh ref={meshRef}>
                <dodecahedronGeometry args={[0.4, 0]} />
                {/* DUAL MATERIAL TRICK? Or simple Shader? Let's use standard with noise */}
                <meshStandardMaterial
                    color="#00FFFF"
                    emissive="#0088AA"
                    emissiveIntensity={1}
                    roughness={0.1}
                    metalness={0.9}
                    transparent
                    opacity={0.9}
                />
            </mesh>

            {/* CHAOS WIREFRAME OVERLAY (Bottom Half simulated via position/clip?) */}
            {/* We'll add a second mesh for the "Magenta Chaos" effect */}
            <mesh position={[0, -0.1, 0]} scale={[1.1, 1.1, 1.1]}>
                <dodecahedronGeometry args={[0.4, 0]} />
                <meshBasicMaterial
                    color="#EA00FF"
                    wireframe
                    transparent
                    opacity={0.5}
                />
            </mesh>

            <pointLight distance={4} intensity={2} color="#00FFFF" />

            {/* PARTICLE "CODE" SMOKE */}
            <mesh position={[0, -0.5, 0]} rotation={[Math.PI, 0, 0]}>
                <cylinderGeometry args={[0.01, 0.2, 1, 4]} />
                <meshBasicMaterial color="#EA00FF" transparent opacity={0.2} />
            </mesh>
        </group>
    );
};

// --- 4. PROCESS SHADER (Mob Visuals) ---
// --- 4. CYBER-SKIN SHADER (Mob Visuals) ---
const CyberSkinMaterial = ({ textureSrc, glowColor }) => {
    const materialRef = useRef();
    const textureRef = useRef();

    // Load Texture Once
    React.useMemo(() => {
        new THREE.TextureLoader().load(textureSrc, (tex) => {
            tex.colorSpace = THREE.SRGBColorSpace;
            tex.minFilter = THREE.NearestFilter;
            tex.magFilter = THREE.NearestFilter;
            textureRef.current = tex;
            if (materialRef.current) {
                materialRef.current.map = tex;
                materialRef.current.needsUpdate = true;
            }
        });
    }, [textureSrc]);

    React.useLayoutEffect(() => {
        if (!materialRef.current) return;

        materialRef.current.onBeforeCompile = (shader) => {
            shader.uniforms.uTime = { value: 0 };
            shader.uniforms.uGlowColor = { value: new THREE.Color(glowColor || "#00FFFF") };
            shader.uniforms.uDamagePulse = { value: 0.0 }; // Passed via instanceColor normally, but we can try uniform if critical

            // INJECT: ATTRIBUTES & VARYINGS
            shader.vertexShader = `
                uniform float uTime;
                attribute float aGlitch;
                varying float vGlitch;
                varying vec2 vUv;
                ${shader.vertexShader}
            `.replace(
                '#include <begin_vertex>',
                `
                #include <begin_vertex>
                vGlitch = aGlitch;
                vUv = uv;

                // GLITCH DISPLACEMENT
                if (vGlitch > 0.0) {
                    float noise = sin(uTime * 20.0 + position.y * 10.0);
                    transformed.x += noise * vGlitch * 0.1;
                    transformed.z += noise * vGlitch * 0.1;
                }
                `
            );

            shader.fragmentShader = `
                uniform float uTime;
                uniform vec3 uGlowColor;
                varying float vGlitch;
                varying vec2 vUv;
                ${shader.fragmentShader}
            `.replace(
                '#include <map_fragment>',
                `
            #ifdef USE_MAP
                // SAMPLING
                vec4 texColor = texture2D(map, vUv);

            // 1. ALPHA CLIPPING (The "Ghost Effect")
            if (texColor.r < 0.1 && texColor.g < 0.1 && texColor.b < 0.1) discard;

            diffuseColor *= texColor;
            #endif
                `
            ).replace(
                '#include <dithering_fragment>',
                `
                #include <dithering_fragment>

                #ifdef USE_MAP
                // 2. GLOW & TINT (Aggressive Overdrive)
                vec4 texCheck = texture2D(map, vUv);

                // Detect bright/white pixels specifically
                float bright = dot(texCheck.rgb, vec3(0.33, 0.33, 0.33));

            if (bright > 0.4) {
                    float pulse = 0.5 * sin(uTime * 3.0) + 0.5;
                    vec3 hotGlow = uGlowColor * (1.5 + pulse * 1.0);
                gl_FragColor.rgb += hotGlow;
                gl_FragColor.a = 1.0;
            } else {
                gl_FragColor.rgb *= 0.8;
            }
            #endif
                `
            );

            materialRef.current.userData.shader = shader;
        };
    }, [glowColor]);

    useFrame((state) => {
        if (materialRef.current && materialRef.current.userData.shader) {
            materialRef.current.userData.shader.uniforms.uTime.value = state.clock.elapsedTime;
        }
    });

    return (
        <meshStandardMaterial
            ref={materialRef}
            color="#FFFFFF"
            roughness={0.4}
            metalness={0.6}
            emissiveIntensity={1}
            side={THREE.DoubleSide}
            transparent={true} // Essential for Alpha Clip logic sometimes
            alphaTest={0.1}
        />
    );
};

// --- GEOMETRIES (Brand Identity) ---
// BIT_MITE: Inverted Pyramid (Tetrahedron) + Light Trails
// Rotate to have a face pointing "Forward" (-Z?)
// Tetrahedron default points corner up. Rotation needed.
const MiteGeo = new THREE.TetrahedronGeometry(0.8, 0);

// NULL_WISP: Dodecahedron (Cyber Polyhedron)
const WispGeo = new THREE.DodecahedronGeometry(0.6, 0);

// --- GEOMETRIES (Brand Identity) ---
// Note: We use declarative geometries in the render loop to ensure correct attribute attachment via R3F.
// Dimensions defined inline below.

export default function MobManager({ maze, floorLevel }) {
    const [mobs, setMobs] = useState([]);
    const [bossKey, setBossKey] = useState(null); // Physical Shard Location

    const { positionBuffer, lifeBuffer, typeBuffer, MAX_PROJECTILES, triggerImpact } = useCombat();
    const { gameState, setGameState, addNotification, updateBossStatus, getLevelFromXP, getNextLevelXP, setBossSubtitle,
        setInteractionPrompt, lastInteractTime, setActiveLoreLog, unlockKernel } = useGame();
    const { addItem } = useInventory();
    const { restoreRam } = usePlayer(); // For Scan v2 Reward

    // Instancing Refs (Split by Geometry)
    const miteRef = useRef();
    const wispRef = useRef();
    const hunterRef = useRef();
    const sentryRef = useRef();
    // SCAN OVERLAY REFS (Matched Geometries)
    const miteScanRef = useRef();
    const wispScanRef = useRef();
    const hunterScanRef = useRef();
    const sentryScanRef = useRef();

    // Glitch Buffers (Integrity Data)
    const miteGlitch = useMemo(() => new Float32Array(MAX_MOBS), []);
    const wispGlitch = useMemo(() => new Float32Array(MAX_MOBS), []);
    const hunterGlitch = useMemo(() => new Float32Array(MAX_MOBS), []);
    const sentryGlitch = useMemo(() => new Float32Array(MAX_MOBS), []);

    const spawnQueue = useRef([]);
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // INITIAL SPAWN LOGIC (Run once per maze generation)
    React.useEffect(() => {
        if (!maze || !maze.grid) return;

        console.log(`[SCHEDULER]: ANALYZING_SPAWN_VECTORS(FLOOR ${floorLevel})`);
        const newMobs = [];
        const deadEnds = [];

        // 1. Identify Spawn Points
        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell !== 1) return; // Only Floor
                let walls = 0;
                if (x === 0 || maze.grid[z][x - 1] === 0) walls++;
                if (x === maze.width - 1 || maze.grid[z][x + 1] === 0) walls++;
                if (z === 0 || maze.grid[z - 1][x] === 0) walls++;
                if (z === maze.height - 1 || maze.grid[z + 1][x] === 0) walls++;

                if (walls >= 3) deadEnds.push({ x, z });
            });
        });

        // 2. BOSS CHECK (Floor 10 Specific)
        if (floorLevel === 10) {
            const bossData = MobLogic.createMob('IO_SENTINEL', floorLevel);
            if (bossData) {
                // FIXED CENTER FOR SAFE ARENA (15 grid * 2 cell size = 30 world)
                const centerX = 30; // Maze center
                const centerZ = 30;

                console.log(`[SCHEDULER]: SPAWNING_BOSS @[${centerX}, ${centerZ}]`);
                newMobs.push({
                    ...bossData,
                    instanceId: Math.random(),
                    x: centerX,
                    z: centerZ,
                    phase: 1, // 1: Beam, 2: Spawn
                    summonTimer: 0
                });
                updateBossStatus({ active: true, name: bossData.name, hp: bossData.currentHp, maxHp: bossData.maxHp });
            }
        }

        // 2.5 BESTIARY MODE (Floor 999)
        else if (floorLevel === 999) {
            console.log("[SCHEDULER]: BESTIARY_MODE_ACTIVE // DEPLOYING_SPECIMENS");
            setGameState(prev => ({ ...prev, isPortalLocked: false })); // No lock needed

            // CENTER (7,7 in Grid -> 14,14 in World)
            // Pedestals in corners of room
            const specs = [
                { id: 'BIT_MITE', x: 4, z: 4 },
                { id: 'NULL_WISP', x: 4, z: 10 },
                { id: 'HUNTER', x: 10, z: 4 },
                { id: 'STATELESS_SENTRY', x: 10, z: 10 },
                { id: 'IO_SENTINEL', x: 7, z: 7 } // CENTER OF ROOM
            ];

            specs.forEach(spec => {
                // Convert Grid to World (x2)
                const wx = spec.x * 2;
                const wz = spec.z * 2;

                const data = MobLogic.createMob(spec.id, 1); // Level 1 stats for baseline
                if (data) {
                    newMobs.push({
                        ...data,
                        instanceId: Math.random(),
                        x: wx,
                        z: wz,
                        isStasis: true // Disable AI
                    });
                }
            });
            addNotification("ARCHIVE_READY: SUBJECTS_IN_STASIS");
        }

        // SECTOR BOSSES (Every 25 Floors)
        else if (floorLevel % 25 === 0 && deadEnds.length > 0) {
            const bossPos = deadEnds.pop();
            const bossData = MobLogic.createMob('SECTOR_GUARDIAN', floorLevel);
            if (bossData) newMobs.push({ ...bossData, instanceId: Math.random(), x: bossPos.x * 2, z: bossPos.z * 2 });
        }

        // 3. Populate Regular Mobs
        if (floorLevel !== 10) {
            deadEnds.forEach(pos => {
                const rand = Math.random();
                const isSector2 = floorLevel >= 11;

                if (isSector2 && rand < 0.15) { // 15% NULL_WISP (Sector 2+)
                    const wispData = MobLogic.createMob('NULL_WISP', floorLevel);
                    if (wispData) {
                        newMobs.push({ ...wispData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
                    }
                } else if (rand < 0.05) { // 5% HUNTER
                    const hunterData = MobLogic.createMob('HUNTER', floorLevel || 1);
                    if (hunterData) {
                        newMobs.push({ ...hunterData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
                    }
                } else if (rand < 0.4) {
                    const count = Math.floor(Math.random() * 2) + 1;
                    for (let i = 0; i < count; i++) {
                        const mobData = MobLogic.createMob('BIT_MITE', floorLevel || 1);
                        if (mobData) {
                            newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2 + (Math.random() - 0.5) * 0.4, z: pos.z * 2 + (Math.random() - 0.5) * 0.4 });
                        }
                    }
                } else if (rand > 0.8) {
                    const mobData = MobLogic.createMob('STATELESS_SENTRY', floorLevel || 1);
                    if (mobData) {
                        newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
                    }
                }
            });
        }

        console.log(`[SCHEDULER]: DEPLOYED ${newMobs.length} HOSTILES`);
        setMobs(newMobs.slice(0, MAX_MOBS));

    }, [maze, floorLevel]);

    // COMBAT, AI & RENDERING LOOP
    useFrame((state, delta) => {
        // REMOVED mobs.length === 0 early return to allow spawnQueue processing
        if (!gameState.playerGridPos) return;

        let mobsDirty = false;

        // INSTANCE COUNTERS
        let miteC = 0, wispC = 0, hunterC = 0, sentryC = 0;
        let miteScanC = 0, wispScanC = 0, hunterScanC = 0, sentryScanC = 0;

        // 1. UPDATE LOGIC & INSTANCES
        const playerLevel = getLevelFromXP(gameState.xp || 0);
        mobs.forEach((mob, i) => {
            // DO NOT SKIP STASIS FOR DOT & DEATH CHECK (They must die even if frozen)
            // SHRED V2: Damage Over Time (DoT)
            if (mob.isHacked && playerLevel >= 5) {
                mob.hackTimer -= delta;
                mob.currentHp -= (5 * delta); // 5 DPS Corruption

                // VISUAL: Green Sparks every 0.2s (Throttle to avoid particle spam)
                if (Math.random() < 0.2) {
                    triggerImpact({ x: mob.x, y: 1.0 + (Math.random() * 0.5), z: mob.z }, '#00FF00');
                }

                if (mob.hackTimer <= 0) {
                    mob.isHacked = false;
                }
            } else if (mob.isHacked) {
                // LEVEL 1-4: Standard Hack (No Damage)
                mob.hackTimer -= delta;
                if (mob.hackTimer <= 0) mob.isHacked = false;
            }

            // STASIS (Bestiary Mode)
            // if (mob.isStasis) return; // REMOVED: Breaks Rendering!
            const playerX = (gameState.playerGridPos?.x || 1) * 2;
            const playerZ = (gameState.playerGridPos?.y || 1) * 2;
            const dx = playerX - mob.x;
            const dz = playerZ - mob.z;
            const distSq = dx * dx + dz * dz;

            // AI CULLING & LOGIC
            const isHunter = mob.id === 'HUNTER';

            // MOVEMENT Logic (Only for Non-Stasis)
            if (!mob.isStasis) {
                if (distSq > 2500) {
                    if (isHunter && distSq > 3600) {
                        // Hunter Teleport Logic
                        const angle = Math.atan2(dz, dx);
                        mob.x = playerX - Math.cos(angle) * 40 + (Math.random() - 0.5) * 4;
                        mob.z = playerZ - Math.sin(angle) * 40 + (Math.random() - 0.5) * 4;
                    } else if (!isHunter) {
                        return; // Despawn/Cull
                    }
                }

                // COLLISION HELPER
                const margin = 0.7;
                const checkCollision = (cx, cz) => {
                    const gx = Math.round(cx / 2);
                    const gz = Math.round(cz / 2);
                    if (gx >= 0 && gx < maze.width && gz >= 0 && gz < maze.height) {
                        return maze.grid[gz][gx] === 0;
                    }
                    return true;
                };

                // AI MOVEMENT
                if (distSq > 1 && (mob.id === 'BIT_MITE' || mob.id === 'HUNTER')) {
                    const len = Math.sqrt(distSq);
                    const speed = mob.id === 'HUNTER' ? 3.5 : 2.0;
                    const moveX = (dx / len) * speed * delta;
                    const moveZ = (dz / len) * speed * delta;
                    const nextX = mob.x + moveX;
                    const nextZ = mob.z + moveZ;

                    if (!checkCollision(nextX, nextZ) && !checkCollision(nextX + margin, nextZ) && !checkCollision(nextX - margin, nextZ)) {
                        mob.x = nextX;
                        mob.z = nextZ;
                    } else {
                        if (!checkCollision(nextX, mob.z)) mob.x = nextX;
                        else if (!checkCollision(mob.x, nextZ)) mob.z = nextZ;
                    }
                }

                // SEPARATION FORCE
                let sepX = 0;
                let sepZ = 0;
                mobs.forEach((other, j) => {
                    if (i === j) return;
                    const sdx = mob.x - other.x;
                    const sdz = mob.z - other.z;
                    const sDistSq = sdx * sdx + sdz * sdz;
                    if (sDistSq < 0.25) {
                        const sLen = Math.sqrt(sDistSq) || 0.1;
                        sepX += (sdx / sLen) / sDistSq;
                        sepZ += (sdz / sLen) / sDistSq;
                    }
                });

                if (Math.abs(sepX) > 0.01 || Math.abs(sepZ) > 0.01) {
                    const pushX = sepX * delta * 2;
                    const pushZ = sepZ * delta * 2;
                    const nextX = mob.x + pushX;
                    const nextZ = mob.z + pushZ;
                    if (!checkCollision(nextX, nextZ)) {
                        mob.x = nextX;
                        mob.z = nextZ;
                    }
                }
            }

            // HIT DETECTION (Using Buffers)
            if (positionBuffer && positionBuffer.current && lifeBuffer && lifeBuffer.current) {
                const pArr = positionBuffer.current;
                const lArr = lifeBuffer.current;
                const tArr = typeBuffer.current;

                for (let k = 0; k < MAX_PROJECTILES; k++) {
                    if (lArr[k] <= 0) continue;

                    const px = pArr[k * 3];
                    const py = pArr[k * 3 + 1];
                    const pz = pArr[k * 3 + 2];
                    const pdx = mob.x - px;
                    const pdz = mob.z - pz;

                    if (pdx * pdx + pdz * pdz < (mob.id === 'IO_SENTINEL' ? 9.0 : 0.6)) { // Larger Hitbox for Boss
                        let damage = 10; // Base Dmg
                        let isCrit = false;
                        const playerLevel = gameState.scannerLevel || 1;

                        if (mob.scanTimer > 0) {
                            damage *= 2.5;
                            isCrit = true;
                        }

                        if (tArr[k] === 1) { // SHRED
                            mob.isHacked = true;
                            // SHRED V2 (Level 5+)
                            if (playerLevel >= 5) {
                                mob.hackTimer = 12.0; // Extended Duration
                                damage += 15; // Bonus Kinetic Damage
                            } else {
                                mob.hackTimer = 5.0;
                            }
                        }

                        // --- ARMOR LOGIC ---
                        if (mob.resistance && !isCrit && !mob.isHacked && !mob.isVulnerable) {
                            damage *= (1.0 - mob.resistance); // Apply Reduction
                            addNotification("ARMOR_DEFLECTED");
                        }

                        // STUN LOGIC (Data Spike Burst)
                        if (mob.isVulnerable && isCrit) { // "Striking the VULNERABLE tag"
                            // SCAN V2 REWARD: Restore RAM
                            restoreRam(5);
                            addNotification("CRITICAL_ACCESS: +5 RAM");

                            damage *= 2.5; // Override Multiplier (Base * 2.5) -> (10 * 2.5 = 25)
                            // Note: ScanTimer already does 2.5x. Do they stack? 
                            // User said: "Multiplier: Base * 2.5". Implies replacement or same buff.
                            // Current code at line 690: `if (scanTimer > 0) damage *= 2.5`.
                            // If Vuln AND Scanned, we should probably not do 2.5 * 2.5 = 6.25x.
                            // But Vuln allows Crits WITHOUT Scan? Or Scan CAUSES Vuln.
                            // Logic: Scan -> Vuln. So Scan Timer is usually Active.
                            // I will assume the 2.5x from ScanTimer covers it, or ensure it doesn't double dip excessively unless intended.
                            // Code at 690 handles the 2.5x. I will leave it, but ensure Trigger logic works.

                            if (!mob.stunTimer) mob.stunTimer = 0;
                            mob.stunTimer += 0.5;
                            if (mob.stunTimer > 2.0) {
                                mob.bossState = 'STUNNED';
                                mob.stateTimer = 5.0;
                                setBossSubtitle("SYSTEM_CRITICAL: REBOOTING_CORE...", 5000);
                            }
                        }

                        mob.currentHp -= damage;
                        mob.lastHitTime = Date.now();
                        lArr[k] = 0;

                        triggerImpact(new THREE.Vector3(px, py, pz), isCrit ? '#EA00FF' : (mob.resistance ? '#888888' : '#FFFF00'));

                        if (mob.id === 'IO_SENTINEL') {
                            updateBossStatus({ hp: mob.currentHp });
                            // HIT REACTIONS
                            if (Math.random() < 0.2) {
                                if (mob.scanTimer > 0) setBossSubtitle("STOP_LOOKING_AT_MY_CODE. I_AM_THE_WALL.", 2500);
                                else if (damage > 30) setBossSubtitle("ERROR: PACKET_LOSS_DETECTED. AGGRESSIVE.", 2500);
                            }
                            if (mob.isVulnerable && isCrit) setBossSubtitle("CRITICAL_HIT... I_REMEMBER... THIS_WEAKNESS.", 2500);
                        }
                    }
                }
            }

            // BOSS & WISP AI (State Machines) - SKIP IN STASIS
            if (!mob.isStasis) {
                // BOSS AI STATE MACHINE (Sentinel)
                if (mob.id === 'IO_SENTINEL') {
                    mob.stateTimer = (mob.stateTimer || 0) - delta;

                    // STUNNED STATE
                    if (mob.bossState === 'STUNNED') {
                        if (mob.stateTimer <= 0) mob.bossState = 'IDLE';
                    }
                    else if (mob.phase === 1) {
                        // IDLE -> CHARGE -> FIRE
                        if (!mob.bossState || mob.bossState === 'IDLE') {
                            if (Math.random() < 0.01) {
                                mob.bossState = 'CHARGING';
                                mob.stateTimer = 1.5;
                                mob.isVulnerable = true;
                                setBossSubtitle("ALIGNING_LOGIC_RAILS... STAND_STILL. DE-COMPILATION_IS_PAINLESS.", 2000);
                            }
                        }
                        if (mob.bossState === 'CHARGING' && mob.stateTimer <= 0) {
                            mob.bossState = 'FIRING';
                            mob.isVulnerable = false;
                            mob.stateTimer = 3.5; // FULL SPIN

                            // CHECK HIT (Massive AOE)
                            const dist = Math.sqrt(distSq);
                            if (dist < 250) {
                                let hasLineOfSight = true;
                                const steps = 250;
                                const stepX = dx / dist;
                                const stepZ = dz / dist;

                                for (let s = 1; s < dist - 1; s++) {
                                    const checkX = Math.round((mob.x + stepX * s) / 2);
                                    const checkZ = Math.round((mob.z + stepZ * s) / 2);
                                    if (maze && maze.grid && maze.grid[checkZ] && maze.grid[checkZ][checkX] === 0) {
                                        hasLineOfSight = false;
                                        break;
                                    }
                                }

                                if (hasLineOfSight) {
                                    addNotification("WARNING: BEAM_IMPACT");
                                    // DAMAGE PLAYER? (Assuming external mechanic or just notification for now)
                                }
                            }
                        }
                        if (mob.bossState === 'FIRING' && mob.stateTimer <= 0) {
                            mob.bossState = 'IDLE';
                        }

                        if (mob.currentHp < (mob.maxHp * 0.6)) {
                            mob.phase = 2;
                            mob.bossState = 'IDLE';
                            addNotification("WARNING: SENTINEL_PHASE_2 // STACK_OVERFLOW");
                            setBossSubtitle("WARNING: EMOTIONAL_THROTTLE_FAILING. Why do you keep descending?", 4000);
                            setTimeout(() => setBossSubtitle("There is nothing below but the Void. I am trying to save you!", 4000), 4100);
                        }
                    }
                    else if (mob.phase === 2) {
                        // MOVEMENT
                        if (distSq > 100) {
                            mob.x += (dx * 0.005 * 1.5); // Slow drift
                            mob.z += (dz * 0.005 * 1.5);
                        }

                        // SPAWN MINIONS
                        mob.summonTimer = (mob.summonTimer || 0) - delta;
                        if (mob.summonTimer <= 0) {
                            mob.summonTimer = 10.0; // 10s Interval
                            setBossSubtitle("FORK_PROCESS_ACTIVE. CLEAN_THE_ARENA. DELETE_THE_ANOMALY.", 2500);
                            const miteData = MobLogic.createMob('BIT_MITE', floorLevel);
                            if (miteData) {
                                const count = 3;
                                for (let k = 0; k < count; k++) {
                                    if (spawnQueue.current.length < 10) {
                                        spawnQueue.current.push({
                                            ...miteData,
                                            instanceId: Math.random(),
                                            x: mob.x + (Math.random() - 0.5) * 8,
                                            z: mob.z + (Math.random() - 0.5) * 8
                                        });
                                    }
                                }
                                mobsDirty = true;
                            }
                        }
                    }

                    // PHASE 1 MINIONS (Previously duplicated, adding here for consistency if mostly Phase 1)
                    if (mob.phase === 1 && !mob.bossState) {
                        // Optional: Phase 1 spawning if needed, but logic above seemed to focus on Phase 2 spawning.
                        // Original code had Phase 1 spawning block. Let's restore if it was there.
                        // Looking at original file, Phase 1 spawn was inside `else` of Stunned? No.
                        // It was separate. I'll leave Phase 2 spawning active.
                    }
                }


                // NULL WISP LOGIC (Summoner)
                if (mob.id === 'NULL_WISP') {
                    // Passive Drift
                    if (distSq > 9 && distSq < 400) {
                        mob.x += (dx * 0.005);
                        mob.z += (dz * 0.005);
                    }

                    // SUMMON CYCLE
                    if (mob.telegraphTimer > 0) {
                        mob.telegraphTimer -= delta;
                        if (mob.telegraphTimer <= 0) {
                            // COMPLETE -> SPAWN
                            addNotification("WARNING: LOGIC_BREACH_DETECTED");
                            const miteData = MobLogic.createMob('BIT_MITE', floorLevel);
                            if (miteData) {
                                for (let k = 0; k < 2; k++) {
                                    if (spawnQueue.current.length < 10) {
                                        spawnQueue.current.push({
                                            ...miteData,
                                            instanceId: Math.random(),
                                            x: playerX + (Math.random() - 0.5) * 2,
                                            z: playerZ + (Math.random() - 0.5) * 2
                                        });
                                    }
                                }
                                mobsDirty = true;
                            }
                        }
                    } else {
                        // Check to start Uplink
                        if (distSq < 100 && Math.random() < 0.005) {
                            mob.telegraphTimer = 3.0;
                        }
                    }
                }
            }

            // DEATH CHECK
            if (mob.currentHp <= 0) {
                if (!mob.isDead) {
                    mob.isDead = true;
                    mobsDirty = true;
                    // BOSS DIALOGUE: DEATH
                    if (mob.id === 'IO_SENTINEL') {
                        setBossSubtitle("FATAL_ERROR. SYSTEM_HALT.", 3000);
                        setTimeout(() => setBossSubtitle("Ghost... you have the Key now. But remember: every step down is a step further from the sun.", 5000), 3200);
                        setTimeout(() => setBossSubtitle("If you find the others... tell them... the Handshake... was... valid...", 6000), 8500);
                    }
                }
            }

            // SCAN LOGIC
            if (gameState.lastScanTime) {
                const scanAge = (Date.now() - gameState.lastScanTime) / 1000;
                if (scanAge < 2.5) {
                    const waveRadius = scanAge * 25;
                    const dist = Math.sqrt(distSq);
                    if (dist < waveRadius && dist > waveRadius - 5) {
                        // SCAN V2 (Level 5+)
                        if (playerLevel >= 5) {
                            mob.scanTimer = 20.0;
                            mob.isVulnerable = true; // [VULNERABLE] Tag
                        } else {
                            mob.scanTimer = 10.0;
                        }
                    }
                }
            }
            if (mob.scanTimer > 0) mob.scanTimer -= delta;

            // RENDER MATRIX SETUP (Split Logic)
            // (Counters initialized outside loop)

            tempObject.position.set(mob.x, 1, mob.z);
            tempObject.lookAt(playerX, 1, playerZ);

            // Unique Sizing
            if (mob.id === 'BIT_MITE') tempObject.scale.setScalar(0.8);
            else if (mob.id === 'NULL_WISP') tempObject.scale.setScalar(1.2 + Math.sin(state.clock.elapsedTime * 2) * 0.1); // Pulse
            else if (mob.id === 'HUNTER') tempObject.scale.setScalar(1.0);
            else tempObject.scale.setScalar(1.0);

            tempObject.updateMatrix();

            let targetRef = null;
            let targetGlitch = null;
            let targetIndex = 0;
            let targetScanRef = null;

            if (mob.id === 'BIT_MITE') {
                targetRef = miteRef; targetGlitch = miteGlitch; targetIndex = miteC++;
                targetScanRef = miteScanRef;
            }
            else if (mob.id === 'NULL_WISP') {
                targetRef = wispRef; targetGlitch = wispGlitch; targetIndex = wispC++;
                targetScanRef = wispScanRef;
            }
            else if (mob.id === 'HUNTER') {
                targetRef = hunterRef; targetGlitch = hunterGlitch; targetIndex = hunterC++;
                targetScanRef = hunterScanRef;
            }
            else if (mob.id === 'IO_SENTINEL') { /* Handled by <BossFX>, skip render */ }
            else {
                targetRef = sentryRef; targetGlitch = sentryGlitch; targetIndex = sentryC++;
                targetScanRef = sentryScanRef;
            }

            if (targetRef && targetRef.current) {
                targetRef.current.setMatrixAt(targetIndex, tempObject.matrix);

                // DYNAMIC COLOR SCALING
                const sector = floorLevel < 11 ? 1 : (floorLevel < 26 ? 2 : 3);
                const integrity = mob.currentHp / mob.maxHp;

                if (mob.lastHitTime && (Date.now() - mob.lastHitTime < 150)) {
                    tempColor.setHex(0xFF00FF); // MAGENTA FLASH ON HIT (150ms)
                }
                else if (mob.isHacked && playerLevel >= 5) {
                    tempColor.setHex(0x00FF00); // SHRED V2: GREEN GLOW
                }
                else if (mob.isHacked) {
                    tempColor.setHex(0xEA00FF); // Standard Hack Pink
                }
                else if (sector === 1) {
                    tempColor.setHex(0x00FFFF); // Cyan 100%
                } else if (sector === 2) {
                    tempColor.setHex(0x001133).lerp(new THREE.Color(0xEA00FF), 0.3); // Navy + 30% Magenta
                } else {
                    tempColor.setHex(0xEA00FF); // Magenta 100%
                }

                targetRef.current.setColorAt(targetIndex, tempColor);
                // Ensure matrix update
                targetRef.current.instanceMatrix.needsUpdate = true;
                if (targetRef.current.instanceColor) targetRef.current.instanceColor.needsUpdate = true;

                // GLITCH DATA (Inverse Integrity) - Defines geometric distortion, NOT color flash
                if (targetGlitch) targetGlitch[targetIndex] = 1.0 - integrity;
            }

            // SCAN OVERLAY INSTANCING (Now Matched)
            if (mob.scanTimer > 0 && mob.id !== 'IO_SENTINEL' && targetScanRef && targetScanRef.current) {
                let scanIndex = 0;
                if (mob.id === 'BIT_MITE') scanIndex = miteScanC++;
                else if (mob.id === 'NULL_WISP') scanIndex = wispScanC++;
                else if (mob.id === 'HUNTER') scanIndex = hunterScanC++;
                else scanIndex = sentryScanC++;

                // Pulse Effect
                const pulse = 1.05 + Math.sin(state.clock.elapsedTime * 15) * 0.05; // Tight pulse
                const baseScale = tempObject.scale.x; // Capture current scale
                tempObject.scale.multiplyScalar(pulse); // Apply pulse to base scale
                tempObject.updateMatrix();
                targetScanRef.current.setMatrixAt(scanIndex, tempObject.matrix);
            }
        });

        // 2. COMMIT RENDERS & ATTRIBUTES
        const commit = (ref, count, glitchBuf) => {
            if (ref.current) {
                ref.current.count = count;
                ref.current.instanceMatrix.needsUpdate = true;
                if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
                if (ref.current.geometry && ref.current.geometry.attributes.aGlitch) {
                    ref.current.geometry.attributes.aGlitch.needsUpdate = true;
                }
                // Despawn Fix: Ensure visibility matches count
                ref.current.visible = count > 0;
            }
        };

        commit(miteRef, miteC, miteGlitch);
        commit(wispRef, wispC, wispGlitch);
        commit(hunterRef, hunterC, hunterGlitch);
        commit(sentryRef, sentryC, sentryGlitch);
        // Commit Scans
        commit(miteScanRef, miteScanC);
        commit(wispScanRef, wispScanC);
        commit(hunterScanRef, hunterScanC);
        commit(sentryScanRef, sentryScanC);

        // 3. PROCESS DEATHS & SPAWNS
        if (mobsDirty) {
            let pendingXp = 0;
            let totalBits = 0;
            const survivingMobs = mobs.filter(m => {
                // DEATH CHECK
                if (m.currentHp <= 0) {
                    // SHRED V2 (Worm Logic)
                    if (m.isHacked && gameState.scannerLevel >= 5) {
                        // Find Nearest
                        let nearest = null;
                        let minD = 999;
                        // Simple Search (Performance Warning? 50 mobs max is fine)
                        mobs.forEach(chk => {
                            if (chk !== m && chk.currentHp > 0 && !chk.isHacked) {
                                const d = Math.sqrt(Math.pow(chk.x - m.x, 2) + Math.pow(chk.z - m.z, 2));
                                if (d < 10 && d < minD) { // 5 tiles = 10 units? (Cell = 2 units. 5 tiles = 10 units.)
                                    minD = d;
                                    nearest = chk;
                                }
                            }
                        });

                        if (nearest) {
                            nearest.isHacked = true;
                            nearest.hackTimer = 6.0;
                            // Visual arc? We rely on 'isHacked' visual state for now.
                            addNotification("BIT_FLIP: WORM_LATERAL_JUMP");
                        }
                    }

                    if (m.id === 'IO_SENTINEL') {
                        // DROP PHYSICAL KERNEL SHARD
                        setBossKey({ x: m.x, z: m.z });
                        addNotification("BOSS_DEFEATED: SHARD_DETECTED");
                        // We do NOT unlock portal here anymore.
                        // We do NOT add Key to inventory here anymore.
                        updateBossStatus({ active: false });
                        pendingXp += 500;
                    } else if (m.id === 'SECTOR_GUARDIAN') {
                        updateBossStatus({ active: false });
                        pendingXp += 200;
                        totalBits += 50;
                    } else {
                        const playerLvl = getLevelFromXP(gameState.xp);
                        // BESTIARY MODE: Instant Level Up + Respawn
                        if (floorLevel === 999) {
                            pendingXp += (getNextLevelXP(playerLvl) || 100);
                            // 10s Respawn Delay (Bestiary Loop)
                            const mobData = { ...m }; // Clone State Immediately
                            console.log(`[mobData Debug]:`, mobData); // Debug log
                            setTimeout(() => {
                                console.log("[SCHEDULER]: ATTEMPTING_RESPAWN", mobData.id);
                                if (spawnQueue.current.length < MAX_MOBS) {
                                    spawnQueue.current.push({
                                        ...mobData, // Spread the CLONED data
                                        currentHp: mobData.maxHp,
                                        isHit: false,
                                        isDead: false,
                                        // RESET STATUS EFFECTS
                                        isHacked: false,
                                        hackTimer: 0,
                                        scanTimer: 0,
                                        isVulnerable: false,
                                        instanceId: Math.random()
                                    });
                                } else {
                                    console.warn("[SCHEDULER]: RESPAWN_ABORTED - QUEUE_FULL");
                                }
                            }, 5000); // 5s Respawn Delay (Bestiary Loop)
                        }
                        else if (playerLvl < 5 || floorLevel >= 10) {
                            pendingXp += 10;
                        }
                        totalBits += Math.floor(Math.random() * 5) + 1;
                    }
                    return false;
                }
                return true;
            });

            if (spawnQueue.current.length > 0) {
                // FIXED: ENFORCE MAX_MOBS
                const availableSlots = MAX_MOBS - survivingMobs.length;
                if (availableSlots > 0) {
                    const toAdd = spawnQueue.current.slice(0, availableSlots);
                    survivingMobs.push(...toAdd);
                }
                spawnQueue.current = []; // Always clear queue to prevent backlog
            }

            setMobs(survivingMobs);

            if (pendingXp > 0) {
                // Determine mob name for notification if single kill, else generic
                const killedName = mobs.find(m => m.currentHp <= 0)?.id || "HOSTILE";
                addNotification(`${killedName} _NEUTRALIZED: +${pendingXp} XP`);
                setGameState(prev => ({ ...prev, xp: (prev.xp || 0) + pendingXp, eBits: (prev.eBits || 0) + totalBits }));
            }
        }
    });

    return (
        <group>
            {/* MAIN PHYSICAL MESH */}

            {/* 1. BIT_MITE (Skating Pyramid) */}
            <instancedMesh ref={miteRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                {/* Rotate Geometry to align flat face with Billboard Z-axis if needed */}
                <tetrahedronGeometry args={[0.8, 0]}>
                    <instancedBufferAttribute attach="attributes-aGlitch" args={[miteGlitch, 1]} />
                </tetrahedronGeometry>
                <CyberSkinMaterial textureSrc={biteMiteSkinSrc} glowColor={floorLevel < 11 ? "#00FFFF" : "#00AAAA"} />
            </instancedMesh>

            {/* 2. NULL_WISP (Floating Polyhedron) */}
            <instancedMesh ref={wispRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <dodecahedronGeometry args={[0.6, 0]}>
                    <instancedBufferAttribute attach="attributes-aGlitch" args={[wispGlitch, 1]} />
                </dodecahedronGeometry>
                <CyberSkinMaterial textureSrc={wispSkinSrc} glowColor={floorLevel < 11 ? "#00FFFF" : "#EA00FF"} />
            </instancedMesh>

            {/* 3. HUNTER (Box / Stalker) */}
            <instancedMesh ref={hunterRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <boxGeometry args={[0.8, 0.8, 0.8]}>
                    <instancedBufferAttribute attach="attributes-aGlitch" args={[hunterGlitch, 1]} />
                </boxGeometry>
                <CyberSkinMaterial textureSrc={hunterSkinSrc} glowColor="#FF0000" />
            </instancedMesh>

            {/* 4. SENTRY (Monolith) */}
            <instancedMesh ref={sentryRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <boxGeometry args={[0.6, 1.8, 0.2]}>
                    <instancedBufferAttribute attach="attributes-aGlitch" args={[sentryGlitch, 1]} />
                </boxGeometry>
                <CyberSkinMaterial textureSrc={sentrySkinSrc} glowColor="#00FFFF" />
            </instancedMesh>

            {/* SCAN MITE (Tetrahedron) */}
            <instancedMesh ref={miteScanRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <tetrahedronGeometry args={[0.8, 0]} />
                <meshBasicMaterial color="#EA00FF" wireframe transparent opacity={0.6} depthTest={false} depthWrite={false} />
            </instancedMesh>

            {/* SCAN WISP (Octahedron) */}
            <instancedMesh ref={wispScanRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <dodecahedronGeometry args={[0.6, 0]} />
                <meshBasicMaterial color="#EA00FF" wireframe transparent opacity={0.6} depthTest={false} depthWrite={false} />
            </instancedMesh>

            {/* SCAN HUNTER (Box) */}
            <instancedMesh ref={hunterScanRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <boxGeometry args={[0.8, 0.8, 0.8]} />
                <meshBasicMaterial color="#EA00FF" wireframe transparent opacity={0.6} depthTest={false} depthWrite={false} />
            </instancedMesh>

            {/* SCAN SENTRY (Box) */}
            <instancedMesh ref={sentryScanRef} args={[null, null, MAX_MOBS]} count={0} frustumCulled={false}>
                <boxGeometry args={[0.6, 1.8, 0.2]} />
                <meshBasicMaterial color="#EA00FF" wireframe transparent opacity={0.6} depthTest={false} depthWrite={false} />
            </instancedMesh>

            {/* BOSS OVERLAYS */}
            {mobs.map((mob) => {
                if (mob.id === 'IO_SENTINEL') return <BossFX key={mob.instanceId} mob={mob} maze={maze} />;
                return null;
            })}

            {/* DROPPED KERNEL SHARD */}
            {bossKey && <KernelShard position={bossKey} maze={maze} />}
        </group>
    );
}
