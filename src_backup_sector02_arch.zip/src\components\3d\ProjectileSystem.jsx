import React, { useRef, useMemo, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useCombat } from '../../context/CombatContext';
import { useGame } from '../../context/GameContext';
import * as THREE from 'three';

/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Render Active Projectiles (OPTIMIZED)
 * MECHANIC: InstancedMesh for <1 draw call per frame
 */

const MAX_PROJECTILES = 200;

export default function ProjectileSystem() {
    const { positionBuffer, velocityBuffer, lifeBuffer, typeBuffer, MAX_PROJECTILES, triggerImpact } = useCombat();
    const { gameState, getLevelFromXP } = useGame();
    const meshRef = useRef();

    // Reusable Temporary Objects
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // Initialize Color Buffer
    useLayoutEffect(() => {
        if (meshRef.current) {
            meshRef.current.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_PROJECTILES * 3), 3);
        }
    }, [MAX_PROJECTILES]);

    useFrame((state, delta) => {
        const mesh = meshRef.current;
        if (!mesh) return;

        const pArr = positionBuffer.current;
        const vArr = velocityBuffer.current;
        const lArr = lifeBuffer.current;
        const tArr = typeBuffer.current;

        const playerLevel = getLevelFromXP(gameState.xp || 0);

        // Iterate ALL slots (Ring Buffer is sparse)
        // Optimization: 200 items is negligible for CPU loop.
        for (let i = 0; i < MAX_PROJECTILES; i++) {
            if (lArr[i] <= 0) {
                // INACTIVE: Hide
                tempObject.scale.setScalar(0);
                tempObject.updateMatrix();
                mesh.setMatrixAt(i, tempObject.matrix);
                continue;
            }

            // ACTIVE: Update Physics
            lArr[i] -= delta;

            if (lArr[i] <= 0) {
                // Just died in this frame
                tempObject.scale.setScalar(0);
                tempObject.updateMatrix();
                mesh.setMatrixAt(i, tempObject.matrix);
                continue;
            }

            // Move
            const idx3 = i * 3;
            pArr[idx3] += vArr[idx3] * delta;
            pArr[idx3 + 1] += vArr[idx3 + 1] * delta;
            pArr[idx3 + 2] += vArr[idx3 + 2] * delta;

            const px = pArr[idx3];
            const py = pArr[idx3 + 1];
            const pz = pArr[idx3 + 2];

            // COLLISION: WALL
            const gx = Math.round(px / 2);
            const gz = Math.round(pz / 2);

            if (gameState.mazeGrid) {
                if (gx >= 0 && gx < gameState.mazeWidth && gz >= 0 && gz < gameState.mazeHeight) {
                    if (gameState.mazeGrid[gz][gx] === 0) { // WALL
                        lArr[i] = 0;
                        // Impact Logic: Green if Level 5+ Shred
                        const impactColor = (tArr[i] === 1 && playerLevel >= 5) ? '#00FF00' : (tArr[i] === 1 ? '#EA00FF' : '#00FFFF');
                        triggerImpact({ x: px, y: py, z: pz }, impactColor);
                    }
                }
            }

            // COLLISION: FLOOR
            if (py <= 0.2) {
                lArr[i] = 0;
                const impactColor = (tArr[i] === 1 && playerLevel >= 5) ? '#00FF00' : (tArr[i] === 1 ? '#EA00FF' : '#00FFFF');
                triggerImpact({ x: px, y: 0, z: pz }, impactColor);
            }

            // RENDER
            tempObject.position.set(px, py, pz);

            // Look At Velocity
            // Target = Pos + Vel
            tempObject.lookAt(px + vArr[idx3], py + vArr[idx3 + 1], pz + vArr[idx3 + 2]);

            // Scale Effect (Bloom Pulse?)
            tempObject.scale.setScalar(1);

            tempObject.updateMatrix();
            mesh.setMatrixAt(i, tempObject.matrix);

            // COLOR & SCALE
            const isPing = tArr[i] === 0; // 0=PING

            if (isPing) {
                tempColor.set('#00FFFF');
                tempColor.multiplyScalar(3);
                tempObject.scale.set(1, 1, 1);
            } else {
                // SHRED (Gated Visuals)
                if (playerLevel >= 5) {
                    tempColor.set('#00FF00'); // Green
                    tempObject.scale.set(1, 0.5, 0.5); // Narrower
                } else {
                    tempColor.set('#EA00FF'); // Pink
                    tempObject.scale.set(1, 1, 1); // Standard width
                }
                tempColor.multiplyScalar(3);
            }
            mesh.setColorAt(i, tempColor);
            mesh.setMatrixAt(i, tempObject.matrix); // Re-set matrix after scale change
        }

        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    });


    return (
        <instancedMesh ref={meshRef} args={[null, null, MAX_PROJECTILES]} frustumCulled={false}>
            {/* Narrower "Laser" Beam (1/4 Width) */}
            <boxGeometry args={[0.2, 0.05, 0.05]} />
            <meshBasicMaterial
                toneMapped={false}
                color="#FFFFFF" // Tinted by instanceColor
            />
        </instancedMesh>
    );
}
