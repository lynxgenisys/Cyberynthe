import React, { createContext, useContext, useState, useEffect } from 'react';

/**
 * IDENTITY: LOGIC_BREACH_02 (The Engineer)
 * DIRECTIVE: Implement Meta-Game State (Seeds & Levels)
 * CONSTRAINTS:
 * - Seed: Derived from Date().toDateString() (Daily Run)
 * - Sector Logic: Level / 25
 */

const GameContext = createContext();

export const GameProvider = ({ children }) => {
    const playerRotationRef = React.useRef(0); // Zero-cost sync for Compass
    const [gameState, setGameState] = useState({
        seed: '',
        floorLevel: 1,
        preBestiaryFloor: 1, // Store floor to return from archives
        sectorId: 1,
        playerName: 'GHOST_USER',
        isPaused: false,
        isElite: false, // Permadeath Mode
        activePenalties: [],

        playerGridPos: { x: 1, y: 1 }, // Track player for Map
        spawnPoint: null, // Dynamic Spawn Point (Grid Coords)
        ethicsScore: 0.5, // 0.0 (Cyan) to 1.0 (Magenta)
        eBits: 0, // Currency
        isTransitioning: false, // Floor Loading State
        lootedCaches: [], // Array of IDs "x,y"
        notifications: [], // Array of {id, msg, time}
        xp: 0, // Experience Points
        scanningState: { active: false, progress: 0 }, // For HUD UI
        scannedTargets: [], // Array of {x, z, type}
        scannerLevel: 1, // 1: Short, 2: Med, 3: Long

        isPortalLocked: false, // Gatekeeper Logic
        mazeGrid: null, // For Projectile Collision
        bossEncounter: { active: false, name: '', hp: 0, maxHp: 0 },
        bossSubtitle: { text: '', duration: 0, timestamp: 0 },
        visualFilter: 'NONE' // 'NONE', 'CYAN_TINT', 'MAGENTA_JITTER'
    });

    const setVisualFilter = (filter) => {
        setGameState(prev => ({ ...prev, visualFilter: filter }));
    };

    const setBossSubtitle = (text, duration = 3000) => {
        setGameState(prev => ({
            ...prev,
            bossSubtitle: { text, duration, timestamp: Date.now() }
        }));
    };

    const addNotification = (msg) => {
        const id = Date.now();
        setGameState(prev => ({
            ...prev,
            notifications: [...prev.notifications, { id, msg, time: Date.now() }].slice(-5) // Keep last 5
        }));
    };

    const updateScannedTargets = (targets) => {
        setGameState(prev => ({ ...prev, scannedTargets: targets }));
    };

    const updateBossStatus = (status) => {
        setGameState(prev => ({
            ...prev,
            bossEncounter: { ...prev.bossEncounter, ...status }
        }));
    };

    const markCacheLooted = (x, y) => {
        const id = `${x},${y}`;
        setGameState(prev => ({
            ...prev,
            lootedCaches: [...prev.lootedCaches, id]
        }));
    };

    // PERSISTENCE PROTOCOL
    const checkPersistence = (currentIntegrity) => {
        if (currentIntegrity <= 0) {
            if (gameState.isElite) {
                console.warn("[SYSTEM]: ELITE_MODE_DEATH // WIPING_SESSION");
                localStorage.removeItem('CyberSynthe_Save'); // Clear Save
                // Reset to Floor 1, Seed Reset
                setGameState(prev => ({
                    ...prev,
                    floorLevel: 1,
                    sectorId: 1,
                    seed: btoa(Date.now().toString()).substring(0, 16)
                }));
                return 'WIPED';
            } else {
                console.log("[SYSTEM]: STANDARD_DEATH // RESPAWNING");
                return 'RESPAWNED';
            }
        }
    };

    const saveSession = () => {
        const data = {
            gameState,
            timestamp: Date.now()
        };
        localStorage.setItem('CyberSynthe_Save', JSON.stringify(data));
        console.log("[SYSTEM]: SESSION_SAVED_LOCALLY");
        addNotification("GAME SAVED: L1_CACHE_UPDATED");
    };

    const loadSession = (data) => {
        if (!data || !data.gameState) return;
        console.log("[SYSTEM]: RESTORING_SESSION...");
        setGameState(data.gameState);
        addNotification("SESSION_RESTORED");
    };

    // Initialize Session Seed
    useEffect(() => {
        // CHECK FOR SAVE ON START (For debug logs mostly, logic handled in App UI)
        const saved = localStorage.getItem('CyberSynthe_Save');
        if (saved) console.log("[SYSTEM]: FOUND_EXISTING_SAVE_FILE");

        const timestamp = Date.now().toString();
        // Uses current milliseconds for a truly unique session seed
        const seedHash = btoa(timestamp + "_CYBERYNTHE_SESSION").substring(0, 16);

        setGameState(prev => ({
            ...prev,
            seed: seedHash
        }));

        console.log(`[SYSTEM]: DAILY_SEED_INITIATED: ${seedHash}`);

        // INITIAL LORE TRIGGER (Floor 1)
        setBossSubtitle("HEURISTIC_SCAN_COMPLETE... ENTITY_ID: NULL_POINTER... 'Welcome back to the morgue.'", 6000);
    }, []);

    const enterBestiaryMode = () => {
        // 0. AUTO-SAVE BEFORE LEAVING MAIN LOOP
        saveSession();
        addNotification("ENTERING_ARCHIVES... SESSION_PAUSED");

        // 1. SIGNAL TRANSITION START
        setGameState(prev => ({
            ...prev,
            isTransitioning: true,
            preBestiaryFloor: prev.floorLevel // Save current floor
        }));

        // 2. DELAY & TELEPORT TO FLOOR 999
        setTimeout(() => {
            setGameState(prev => ({
                ...prev,
                floorLevel: 999, // BESTIARY_ID
                sectorId: 1,
                spawnPoint: { x: 14, y: 1.5, z: 24 }, // World Coords (7*2, 12*2)
                isPortalLocked: false,
                isTransitioning: true,
                bossSubtitle: { text: "WELCOME TO THE ARCHIVE. SPECIMENS ARE IN STASIS.", duration: 8000, timestamp: Date.now() + 600 },
                visualFilter: 'NONE' // Clear filters for clean inspection
            }));

            // 3. FINISH TRANSITION
            setTimeout(() => {
                setGameState(prev => ({ ...prev, isTransitioning: false }));
                console.log("[SYSTEM]: ARCHIVE_LOADED");
            }, 500);

        }, 100);
    };

    const advanceFloor = () => {
        // 0. AUTO-SAVE (L1 CACHE LOGIC)
        saveSession();

        // 1. SIGNAL TRANSITION START (Unmounts Maze)
        setGameState(prev => ({ ...prev, isTransitioning: true }));

        // 2. DELAY & UPDATE FLOOR
        setTimeout(() => {
            setGameState(prev => {
                let nextFloor = prev.floorLevel + 1;

                // BESTIARY EXIT LOGIC
                if (prev.floorLevel === 999) {
                    nextFloor = prev.preBestiaryFloor || 1;
                    addNotification(`EXITING_ARCHIVES... RETURNING_TO_FLOOR_${nextFloor}`);
                }

                // ASCENSION CHECK REMOVED -> ENDLESS MODE
                if (nextFloor === 100) {
                    console.log("[SYSTEM]: CLASS_CHOICE_MILESTONE_REACHED");
                    // TODO: Trigger Class Selection UI
                }

                const nextSector = Math.ceil(nextFloor / 25);

                // LORE FLAVOR TEXT (GHOST PROTOCOL)
                // We set this here so it appears exactly when the floor loads
                let subtitle = null;
                let subDuration = 0;

                if (nextFloor === 1) {
                    subtitle = "HEURISTIC_SCAN_COMPLETE... ENTITY_ID: NULL_POINTER... 'Welcome back to the morgue.'";
                    subDuration = 6000;
                } else if (nextFloor === 2) {
                    subtitle = "FRAGMENT_ID: #0001_WEIGHT... 'I remember the weight of a coffee mug...'";
                    subDuration = 5000;
                    // Trigger Special Choice via State? Or handled by Directive Engine?
                    // We'll set a flag/event that App.jsx monitors, or just roll a specific directive.
                    // Ideally, we push a custom notification or event.
                } else if (nextFloor === 3) {
                    subtitle = "WARNING: THE_STATIC_IS_LEAKING... 'You aren't here to beat the game, Ghost. You're here to keep the lights on.'";
                    subDuration = 7000;
                } else if (nextFloor === 4) {
                    subtitle = "[SEC_AUDIT]: INCONSISTENCY_FOUND. Subject exhibits non-linear decision making.";
                    subDuration = 5000;
                    // Trigger Red Audit Overlay (HUD will handle 'AUDIT_SCAN' logic based on floor or specific state)
                    // We'll set a generic 'narrativeState'
                } else if (nextFloor === 5) {
                    subtitle = "[ECHO_01]: '...ghost... can you hear the background? The Sentinel isn't a guard. It’s a janitor.'";
                    subDuration = 6000;
                } else if (nextFloor === 7) {
                    subtitle = "[LOG_FILE]: 'They told us the Labyrinth was a lifeboat... but I looked through a logic-leak today. I saw the city.'";
                    subDuration = 7000;
                } else if (nextFloor === 9) {
                    subtitle = "[CRITICAL_ALERT]: UPLINK_RESTRICTED. Subject #NULL_POINTER marked for De-compilation.";
                    subDuration = 6000;
                } else if (nextFloor === 11) {
                    subtitle = "[THE_MACHINE_ROOM]: SYSTEM_HANDSHAKE_COMPLETE. 'Welcome to the engine block, Ghost. Mind the gears.'";
                    subDuration = 7000;
                }

                return {
                    ...prev,
                    floorLevel: nextFloor,
                    sectorId: nextSector,
                    spawnPoint: null,
                    scanningState: { active: false, progress: 0 }, // FORCE RESET UI
                    isPortalLocked: false, // Reset Lock
                    isTransitioning: true,
                    // Apply Subtitle directly to state here to avoid race conditions
                    bossSubtitle: subtitle ? { text: subtitle, duration: subDuration, timestamp: Date.now() + 600 } : prev.bossSubtitle,

                    // NARRATIVE VISUAL FILTERS
                    visualFilter: (nextFloor === 11) ? 'SECTOR_02_NAVY' : ((nextFloor === 9) ? 'QUARANTINE_LUT' : ((nextFloor === 7) ? 'TEXTURE_BLEED' : prev.visualFilter))
                    // Add 600ms delay to timestamp so it starts AFTER transition finishes (approx)
                };
            });

            // 3. FINISH TRANSITION (Remounts Maze)
            // Giving Rapier 500ms to fully flush physics world
            setTimeout(() => {
                setGameState(prev => ({ ...prev, isTransitioning: false }));
                console.log("[SYSTEM]: TRANSITION_COMPLETE // SIMULATION_RESUMED");
            }, 500);

        }, 100);
    };

    const updatePlayerPos = (x, y) => {
        // Only update if changed to avoid render thrashing
        if (x !== gameState.playerGridPos.x || y !== gameState.playerGridPos.y) {
            setGameState(prev => ({ ...prev, playerGridPos: { x, y } }));
        }
    };

    const updateScanningState = (active, progress) => {
        setGameState(prev => ({ ...prev, scanningState: { active, progress } }));
    };

    const triggerScan = () => {
        setGameState(prev => ({ ...prev, lastScanTime: Date.now() }));
    };

    // SCAN PROGRESS TICKER
    useEffect(() => {
        if (!gameState.lastScanTime) return;

        // Start Scan
        updateScanningState(true, 0);

        const startTime = Date.now();
        const duration = 2000; // 2 Seconds

        const interval = setInterval(() => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1.0);

            updateScanningState(true, progress);

            if (progress >= 1.0) {
                clearInterval(interval);
                setTimeout(() => updateScanningState(false, 0), 500); // Clear after 0.5s completion
            }
        }, 50);

        return () => clearInterval(interval);
    }, [gameState.lastScanTime]);

    // --- LEVELING LOGIC ---
    const XP_THRESHOLDS = [0, 188, 470, 1175, 2938, 7344];

    const getLevelFromXP = (xp) => {
        // 1. Check Static Thresholds
        for (let i = 1; i < XP_THRESHOLDS.length; i++) {
            if (xp < XP_THRESHOLDS[i]) {
                return i;
            }
        }

        // 2. Dynamic Calculation for Lvl 7+
        // If we are here, XP > 7344 (Level 6)
        let level = 6;
        let limit = XP_THRESHOLDS[5];
        while (xp >= limit) {
            limit = Math.floor(limit * 2.5);
            level++;
        }
        return level;
    };

    const getNextLevelXP = (level) => {
        // 1. Static
        if (level < XP_THRESHOLDS.length) return XP_THRESHOLDS[level];

        // 2. Dynamic
        let limit = XP_THRESHOLDS[XP_THRESHOLDS.length - 1]; // Lvl 6 cap
        for (let i = XP_THRESHOLDS.length; i <= level; i++) {
            limit = Math.floor(limit * 2.5);
        }
        return limit;
    };

    // LEVEL UP MONITOR
    useEffect(() => {
        const currentLevel = getLevelFromXP(gameState.xp);
        if (currentLevel > gameState.scannerLevel) { // Use scannerLevel as proxy for Player Level for now
            // LEVEL UP DETECTED
            console.log(`[SYSTEM]: LEVEL_UP_DETECTED -> ${currentLevel}`);
            addNotification(`ACCESS_LEVEL_INCREASED: ${currentLevel}`);
            setBossSubtitle("USER_PRIVILEGE_ELEVATED... PROCESSING_POWER: EXPANDED.", 4000);

            // Update State
            setGameState(prev => ({ ...prev, scannerLevel: currentLevel }));
        }
    }, [gameState.xp]);

    const triggerInteract = () => {
        // VISUAL FEEDBACK FOR USER DEBUGGING
        addNotification("DEBUG: R_KEY_RECEIVED");
        setGameState(prev => ({ ...prev, lastInteractTime: Date.now() }));
    };

    return (
        <GameContext.Provider value={{
            gameState,
            enterBestiaryMode, // EXPOSED
            advanceFloor,
            updatePlayerPos,
            setGameState,
            checkPersistence,
            addNotification,
            markCacheLooted,
            updateScanningState,
            triggerScan,
            updateScannedTargets,
            updateBossStatus,
            setBossSubtitle,
            setVisualFilter, // EXPOSED
            getLevelFromXP,
            getNextLevelXP,
            saveSession, // EXPOSED
            loadSession, // EXPOSED
            playerRotationRef, // EXPOSED REF

            // INTERACTION & KERNEL LOGIC
            isKernelUnlocked: gameState.isKernelUnlocked,
            activeLoreLog: gameState.activeLoreLog,
            interactionPrompt: gameState.interactionPrompt,
            lastInteractTime: gameState.lastInteractTime,

            triggerInteract, // EXPOSED FUNCTION REF
            setInteractionPrompt: (prompt) => setGameState(prev => ({ ...prev, interactionPrompt: prompt })),
            setActiveLoreLog: (log) => setGameState(prev => ({ ...prev, activeLoreLog: log, isPaused: !!log })), // Pause on Log open
            unlockKernel: () => {
                addNotification("KERNEL_UPDATED: PORTAL_UNLOCKED");
                setGameState(prev => ({ ...prev, isKernelUnlocked: true, isPortalLocked: false, activeLoreLog: null, isPaused: false }));
            },
        }}>
            {children}
        </GameContext.Provider>
    );
};

export const useGame = () => useContext(GameContext);
