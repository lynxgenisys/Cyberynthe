import React, { useMemo, useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { MobLogic } from '../../engine/MobAI';
import { useCombat } from '../../context/CombatContext';
import { useGame } from '../../context/GameContext';
import * as THREE from 'three';

/**
 * IDENTITY: SCHEDULER_03
 * DIRECTIVE: Manage Entity Lifecycle (Spawning, AI, Rendering)
 * MECHANIC: Instanced Rendering for High Performance
 */

export default function MobManager({ maze, floorLevel }) {
    const [mobs, setMobs] = useState([]);
    const { projectilesRef } = useCombat();
    const { gameState, setGameState, addNotification } = useGame();

    // Instancing Refs
    const meshRef = useRef();
    const xrayMeshRef = useRef();
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // INITIAL SPAWN LOGIC (Run once per maze generation)
    useMemo(() => {
        if (!maze || !maze.grid) return;

        console.log(`[SCHEDULER]: ANALYZING_SPAWN_VECTORS (FLOOR ${floorLevel})`);
        const newMobs = [];
        const deadEnds = [];

        // 1. Identify Spawn Points
        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell !== 1) return; // Only Floor
                let walls = 0;
                if (x === 0 || maze.grid[z][x - 1] === 0) walls++;
                if (x === maze.width - 1 || maze.grid[z][x + 1] === 0) walls++;
                if (z === 0 || maze.grid[z - 1][x] === 0) walls++;
                if (z === maze.height - 1 || maze.grid[z + 1][x] === 0) walls++;

                if (walls >= 3) deadEnds.push({ x, z });
            });
        });

        // 2. BOSS CHECK
        if (floorLevel % 25 === 0 && deadEnds.length > 0) {
            const bossPos = deadEnds.pop();
            const bossData = MobLogic.createMob('SECTOR_GUARDIAN', floorLevel);
            if (bossData) newMobs.push({ ...bossData, instanceId: Math.random(), x: bossPos.x * 2, z: bossPos.z * 2 });
        }

        // 3. Populate Regular Mobs
        deadEnds.forEach(pos => {
            const rand = Math.random();
            if (rand < 0.3) {
                const count = Math.floor(Math.random() * 3) + 1;
                for (let i = 0; i < count; i++) {
                    const mobData = MobLogic.createMob('BIT_MITE', floorLevel || 1);
                    if (mobData) newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2 + (Math.random() - 0.5), z: pos.z * 2 + (Math.random() - 0.5) });
                }
            } else if (rand > 0.9) {
                const mobData = MobLogic.createMob('STATELESS_SENTRY', floorLevel || 1);
                if (mobData) newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
            }
        });

        console.log(`[SCHEDULER]: DEPLOYED ${newMobs.length} HOSTILES`);
        setMobs(newMobs);

    }, [maze, floorLevel]);

    // COMBAT, AI & RENDERING LOOP
    useFrame((state, delta) => {
        // SAFETY: Early exit if not ready
        if (mobs.length === 0 || !gameState.playerGridPos || !meshRef.current) return;

        let mobsDirty = false;

        // 1. UPDATE LOGIC & INSTANCES
        mobs.forEach((mob, i) => {
            const playerX = (gameState.playerGridPos?.x || 1) * 2;
            const playerZ = (gameState.playerGridPos?.y || 1) * 2;
            const dx = playerX - mob.x;
            const dz = playerZ - mob.z;
            const distSq = dx * dx + dz * dz;

            // AI CULLING (SLEEP MODE)
            if (distSq > 2500) {
                // RENDER IDLE & SKIP
                tempObject.position.set(mob.x, 1, mob.z);
                tempObject.lookAt(playerX, 1, playerZ);
                if (mob.id === 'SECTOR_GUARDIAN') tempObject.scale.setScalar(3.0);
                else tempObject.scale.setScalar(1.0);
                tempObject.updateMatrix();
                meshRef.current.setMatrixAt(i, tempObject.matrix);
                meshRef.current.setColorAt(i, tempColor.setHex(mob.id === 'SECTOR_GUARDIAN' ? 0xFFD700 : 0xFF0000));
                // Hide X-Ray too
                if (xrayMeshRef.current) {
                    tempObject.scale.setScalar(0);
                    tempObject.updateMatrix();
                    xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                }
                return;
            }

            // COLLISION HELPER
            const margin = 0.7; // 0.7m Margin
            const checkCollision = (cx, cz) => {
                const gx = Math.round(cx / 2);
                const gz = Math.round(cz / 2);
                if (gx >= 0 && gx < maze.width && gz >= 0 && gz < maze.height) {
                    return maze.grid[gz][gx] === 0;
                }
                return true;
            };

            // AI MOVEMENT (Bit Mites Only)
            if (distSq > 1 && mob.id === 'BIT_MITE') {
                const len = Math.sqrt(distSq);
                const moveX = (dx / len) * 2 * delta;
                const moveZ = (dz / len) * 2 * delta;
                const nextX = mob.x + moveX;
                const nextZ = mob.z + moveZ;

                if (!checkCollision(nextX, nextZ) && !checkCollision(nextX + margin, nextZ) && !checkCollision(nextX - margin, nextZ)) {
                    mob.x = nextX;
                    mob.z = nextZ;
                } else {
                    // Slide
                    if (!checkCollision(nextX, mob.z)) mob.x = nextX;
                    else if (!checkCollision(mob.x, nextZ)) mob.z = nextZ;
                }
            }

            // SEPARATION FORCE (All Mobs)
            let sepX = 0;
            let sepZ = 0;
            mobs.forEach((other, j) => {
                if (i === j) return;
                const sdx = mob.x - other.x;
                const sdz = mob.z - other.z;
                const sDistSq = sdx * sdx + sdz * sdz;

                // Allow closer pack (0.5m)
                if (sDistSq < 0.25) {
                    const sLen = Math.sqrt(sDistSq) || 0.1;
                    sepX += (sdx / sLen) / sDistSq;
                    sepZ += (sdz / sLen) / sDistSq;
                }
            });

            if (Math.abs(sepX) > 0.01 || Math.abs(sepZ) > 0.01) {
                const pushX = sepX * delta * 2;
                const pushZ = sepZ * delta * 2;
                const nextX = mob.x + pushX;
                const nextZ = mob.z + pushZ;

                // Apply Collision to Push
                if (!checkCollision(nextX, nextZ)) {
                    mob.x = nextX;
                    mob.z = nextZ;
                }
            }

            // HIT DETECTION
            if (projectilesRef && projectilesRef.current && !mob.isDead) {
                projectilesRef.current.forEach(proj => {
                    if (proj.life <= 0) return;
                    const pdx = mob.x - proj.position.x;
                    const pdz = mob.z - proj.position.z;
                    if (pdx * pdx + pdz * pdz < 0.6) {
                        mob.currentHp -= 10;
                        mob.lastHitTime = Date.now();
                        proj.life = 0;
                    }
                });
            }

            // DEATH CHECK
            if (mob.currentHp <= 0) {
                if (!mob.isDead) mob.isDead = true;
                mobsDirty = true;
            }

            // SCAN LOGIC (X-RAY)
            if (gameState.lastScanTime) {
                const scanAge = (Date.now() - gameState.lastScanTime) / 1000;
                if (scanAge < 2.5) {
                    const waveRadius = scanAge * 25;
                    const dist = Math.sqrt(distSq);
                    if (dist < waveRadius && dist > waveRadius - 5) {
                        mob.scanTimer = 10.0;
                    }
                }
            }
            if (mob.scanTimer > 0) mob.scanTimer -= delta;

            // RENDER MATRIX
            tempObject.position.set(mob.x, 1, mob.z);
            tempObject.lookAt(playerX, 1, playerZ);

            // Boss Scale
            if (mob.id === 'SECTOR_GUARDIAN') tempObject.scale.setScalar(3.0);
            else tempObject.scale.setScalar(1.0);

            tempObject.updateMatrix();
            meshRef.current.setMatrixAt(i, tempObject.matrix);

            // Render X-Ray Overlay
            if (xrayMeshRef.current) {
                if (mob.scanTimer > 0) {
                    xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                } else {
                    tempObject.scale.setScalar(0);
                    tempObject.updateMatrix();
                    xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                }
            }

            // Render Color
            const isHit = mob.lastHitTime && Date.now() - mob.lastHitTime < 100;
            if (isHit) tempColor.setHex(0xFFFFFF);
            else if (mob.id === 'SECTOR_GUARDIAN') tempColor.setHex(0xFFD700);
            else tempColor.setHex(0xFF0000);
            meshRef.current.setColorAt(i, tempColor);
        });

        // 2. COMMIT RENDERS
        meshRef.current.instanceMatrix.needsUpdate = true;
        if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
        if (xrayMeshRef.current) xrayMeshRef.current.instanceMatrix.needsUpdate = true;

        // 3. PROCESS DEATHS
        if (mobsDirty) {
            let totalXp = 0;
            let totalBits = 0;
            const survivingMobs = mobs.filter(m => {
                if (m.currentHp <= 0) {
                    totalXp += 10;
                    totalBits += Math.floor(Math.random() * 5) + 1;
                    return false;
                }
                return true;
            });

            if (survivingMobs.length < mobs.length) {
                setMobs(survivingMobs);
                if (totalXp > 0) {
                    addNotification(`THREAT_NEUTRALIZED: +${totalXp} XP`);
                    setGameState(prev => ({ ...prev, xp: (prev.xp || 0) + totalXp, eBits: (prev.eBits || 0) + totalBits }));
                }
            }
        }
    });

    return (
        <group>
            {/* MAIN PHYSICAL MESH (Occluded by walls) */}
            <instancedMesh ref={meshRef} args={[null, null, mobs.length]}>
                <coneGeometry args={[0.4, 0.8, 4]} />
                <meshStandardMaterial color="#FF0000" emissive="#550000" />
            </instancedMesh>

            {/* X-RAY OVERLAY (Visible through walls) */}
            <instancedMesh ref={xrayMeshRef} args={[null, null, mobs.length]} frustumCulled={false}>
                <coneGeometry args={[0.45, 0.85, 4]} /> {/* Slightly larger to overlay */}
                <meshBasicMaterial
                    color="#00FF00"
                    wireframe
                    transparent
                    opacity={0.5}
                    depthTest={false} // KEY: SEES THROUGH WALLS
                    depthWrite={false}
                />
            </instancedMesh>
        </group>
    );
}
