import React, { useMemo } from 'react';
import { InstancedRigidBodies } from '@react-three/rapier';

/**
 * IDENTITY: ARCH_SYS_01_SUB
 * DIRECTIVE: Instanced Wall Rendering
 */

export default function InstancedWalls({ maze, wallMaterial, cellSize, wallHeight }) {

    // Compute Instance Data
    const instances = useMemo(() => {
        const data = [];
        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell === 0) { // WALL
                    data.push({
                        key: `wall-${x}-${z}`,
                        position: [x * cellSize, wallHeight / 2, z * cellSize],
                        rotation: [0, 0, 0],
                        scale: [1, 1, 1]
                    });
                }
            });
        });
        return data;
    }, [maze, cellSize, wallHeight]);

    // Safety: If no walls, return null (prevents Rapier crash)
    if (instances.length === 0) return null;

    return (
        <InstancedRigidBodies
            instances={instances}
            type="fixed"
            colliders="cuboid"
        >
            <instancedMesh args={[null, null, instances.length]} count={instances.length} castShadow receiveShadow frustumCulled={false}>
                <boxGeometry args={[cellSize, wallHeight, cellSize]} />
                <primitive object={wallMaterial} attach="material" />
            </instancedMesh>
        </InstancedRigidBodies>
    );
}
