import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Physics } from '@react-three/rapier';
import { EffectComposer, Bloom, Noise, Vignette } from '@react-three/postprocessing';
import MazeRenderer from './MazeRenderer';
import Player from './Player'; // REVERTED TO LEGACY PLAYER
import ProjectileSystem from './ProjectileSystem';
import Shockwave from './Shockwave';
import { useGame } from '../../context/GameContext';

/**
 * IDENTITY: ARCH_SYS_01
 * DIRECTIVE: Main 3D Composition
 */

const CyberScene = () => {
    return (
        <>
            <color attach="background" args={['#000000']} />

            {/* AMBIENT GLOW */}
            <ambientLight intensity={0.2} color="#00FFFF" />
            <pointLight position={[10, 10, 10]} intensity={1} color="#EA00FF" />

            <Physics gravity={[0, -20, 0]}>
                <MazeRenderer />
                <Player />
            </Physics>

            <ProjectileSystem />
            <Shockwave />

            {/* POST PROCESSING (GRADIENT MORALS) */}
            <EffectComposer>
                <Bloom luminanceThreshold={0} luminanceSmoothing={0.9} height={300} intensity={0.5} />
                <Noise opacity={0.1} />
                <Vignette eskil={false} offset={0.1} darkness={1.1} />
            </EffectComposer>
        </>
    );
};

export default function Scene3D() {
    return (
        <div className="absolute inset-0 -z-10">
            <Canvas shadows camera={{ position: [0, 5, 0], fov: 60 }}>
                <Suspense fallback={null}>
                    <CyberScene />
                </Suspense>
            </Canvas>
        </div>
    );
}
