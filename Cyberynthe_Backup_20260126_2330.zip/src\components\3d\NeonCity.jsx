import React, { useMemo } from 'react';
import * as THREE from 'three';
import { RigidBody, CuboidCollider } from '@react-three/rapier';
import DilemmaOrb from './DilemmaOrb';

// Simple Depth-First Search Maze Generator
const generateMaze = (width, height) => {
    // Ensure odd dimensions for grid-based maze
    const w = width % 2 === 0 ? width + 1 : width;
    const h = height % 2 === 0 ? height + 1 : height;

    const maze = Array(h).fill().map(() => Array(w).fill(1)); // 1 = Wall, 0 = Path
    const stack = [];
    const start = { x: 1, y: 1 };

    maze[start.y][start.x] = 0;
    stack.push(start);

    while (stack.length > 0) {
        const current = stack[stack.length - 1];
        const neighbors = [];

        // Directions: Up, Right, Down, Left (jump 2)
        const dirs = [
            { x: 0, y: -2 },
            { x: 2, y: 0 },
            { x: 0, y: 2 },
            { x: -2, y: 0 }
        ];

        for (const dir of dirs) {
            const nx = current.x + dir.x;
            const ny = current.y + dir.y;

            if (nx > 0 && nx < w - 1 && ny > 0 && ny < h - 1 && maze[ny][nx] === 1) {
                neighbors.push({ x: nx, y: ny, dx: dir.x / 2, dy: dir.y / 2 });
            }
        }

        if (neighbors.length > 0) {
            const next = neighbors[Math.floor(Math.random() * neighbors.length)];
            maze[next.y][next.x] = 0;
            maze[current.y + next.dy][current.x + next.dx] = 0; // Knock down wall
            stack.push({ x: next.x, y: next.y });
        } else {
            stack.pop();
        }
    }

    // FORCE SAFE SPAWN AT CENTER
    const cx = Math.floor(w / 2);
    const cy = Math.floor(h / 2);
    // Ensure odd center for path alignment, adjust if needed
    const safeCx = cx % 2 === 0 ? cx + 1 : cx;
    const safeCy = cy % 2 === 0 ? cy + 1 : cy;

    // Clear a 3x3 area at center for spawn
    for (let y = -1; y <= 1; y++) {
        for (let x = -1; x <= 1; x++) {
            if (maze[safeCy + y] && maze[safeCy + y][safeCx + x] !== undefined) {
                maze[safeCy + y][safeCx + x] = 0;
            }
        }
    }

    return { maze, center: [safeCx, safeCy] };
};

const NeonCity = ({ level = 1 }) => {
    // Level 1 = 10x10 CELLS. 
    // Grid width = Cells * 2 + 1
    // Formula: (10 + (level - 1)) * 2 + 1
    const dimensionCells = 10 + (level - 1);
    const dimensionGrid = dimensionCells * 2 + 1;
    const CELL_SIZE = 4;
    const WALL_HEIGHT = 12;

    const { maze: mazeData, center: centerIndices } = useMemo(() => generateMaze(dimensionGrid, dimensionGrid), [level]);
    const [cx, cz] = centerIndices;

    // We need to shift everything so the Player (at 0,0,0) is at the Maze Center
    // Maze Center World Pos = cx * CELL_SIZE, cz * CELL_SIZE
    // Offset = -Maze Center
    const offsetX = -(cx * CELL_SIZE);
    const offsetZ = -(cz * CELL_SIZE);

    const { walls, floors, goalPos } = useMemo(() => {
        const walls = [];
        const floors = [];
        let possibleGoals = [];

        mazeData.forEach((row, z) => {
            row.forEach((cell, x) => {
                const posX = x * CELL_SIZE + offsetX;
                const posZ = z * CELL_SIZE + offsetZ;

                if (cell === 1) {
                    // Wall
                    walls.push(
                        <RigidBody key={`w-${x}-${z}`} type="fixed" colliders={false} position={[posX, WALL_HEIGHT / 2, posZ]}>
                            <CuboidCollider args={[CELL_SIZE / 2, WALL_HEIGHT / 2, CELL_SIZE / 2]} />
                            <mesh>
                                <boxGeometry args={[CELL_SIZE, WALL_HEIGHT, CELL_SIZE]} />
                                <meshBasicMaterial color="#4040ff" toneMapped={false} />
                            </mesh>
                            {/* Neon Trim Vert */}
                            <mesh position={[CELL_SIZE / 2 - 0.1, 0, CELL_SIZE / 2 - 0.1]}>
                                <boxGeometry args={[0.5, WALL_HEIGHT, 0.5]} />
                                <meshBasicMaterial color={Math.random() > 0.5 ? "#00ffff" : "#ff00ff"} toneMapped={false} />
                            </mesh>
                        </RigidBody>
                    );
                } else {
                    // Path (Floor)
                    floors.push(
                        <RigidBody key={`f-${x}-${z}`} type="fixed" colliders={false} position={[posX, 0, posZ]} rotation={[-Math.PI / 2, 0, 0]} friction={2}>
                            <CuboidCollider args={[CELL_SIZE / 2, CELL_SIZE / 2, 0.1]} /> {/* Thin floor collider */}
                            <planeGeometry args={[CELL_SIZE, CELL_SIZE]} />
                            <meshBasicMaterial color="lime" side={THREE.DoubleSide} />
                        </RigidBody>
                    );

                    // Candidate for goal if it's far from center
                    if (Math.abs(posX) > 20 || Math.abs(posZ) > 20) {
                        possibleGoals.push([posX, 2, posZ]);
                    }
                }
            });
        });

        // Fallback if small maze
        let goal = possibleGoals.length > 0
            ? possibleGoals[Math.floor(Math.random() * possibleGoals.length)]
            : [10, 2, 10]; // Fallback

        return { walls, floors, goalPos: goal };
    }, [mazeData, offsetX, offsetZ]);

    console.log("NeonCity Rendering. Maze Size:", mazeData.length, "Walls count:", walls.length);
    return (
        <group>


            {/* THICK BASE FLOOR - Prevents falling through */}
            <RigidBody type="fixed" colliders={false} position={[0, -5.1, 0]} friction={2}>
                <CuboidCollider args={[dimensionGrid * CELL_SIZE / 2, 5, dimensionGrid * CELL_SIZE / 2]} />
                <mesh>
                    <boxGeometry args={[dimensionGrid * CELL_SIZE, 10, dimensionGrid * CELL_SIZE]} />
                    <meshStandardMaterial color="#020205" roughness={0.1} metalness={0.5} />
                </mesh>
            </RigidBody>

            {/* PERIMETER WALLS - Keeps player in bounds */}
            {/* Using explicit colliders for these too just to be safe */}
            <RigidBody type="fixed" colliders={false} position={[dimensionGrid * CELL_SIZE / 2, WALL_HEIGHT / 2, 0]}>
                <CuboidCollider args={[0.5, WALL_HEIGHT, dimensionGrid * CELL_SIZE / 2]} />
                <mesh visible={false}><boxGeometry args={[1, WALL_HEIGHT * 2, dimensionGrid * CELL_SIZE]} /><meshBasicMaterial color="red" /></mesh>
            </RigidBody>
            <RigidBody type="fixed" colliders={false} position={[-dimensionGrid * CELL_SIZE / 2, WALL_HEIGHT / 2, 0]}>
                <CuboidCollider args={[0.5, WALL_HEIGHT, dimensionGrid * CELL_SIZE / 2]} />
                <mesh visible={false}><boxGeometry args={[1, WALL_HEIGHT * 2, dimensionGrid * CELL_SIZE]} /><meshBasicMaterial color="red" /></mesh>
            </RigidBody>
            <RigidBody type="fixed" colliders={false} position={[0, WALL_HEIGHT / 2, dimensionGrid * CELL_SIZE / 2]}>
                <CuboidCollider args={[dimensionGrid * CELL_SIZE / 2, WALL_HEIGHT, 0.5]} />
                <mesh visible={false}><boxGeometry args={[dimensionGrid * CELL_SIZE, WALL_HEIGHT * 2, 1]} /><meshBasicMaterial color="red" /></mesh>
            </RigidBody>
            <RigidBody type="fixed" colliders={false} position={[0, WALL_HEIGHT / 2, -dimensionGrid * CELL_SIZE / 2]}>
                <CuboidCollider args={[dimensionGrid * CELL_SIZE / 2, WALL_HEIGHT, 0.5]} />
                <mesh visible={false}><boxGeometry args={[dimensionGrid * CELL_SIZE, WALL_HEIGHT * 2, 1]} /><meshBasicMaterial color="red" /></mesh>
            </RigidBody>

            {walls}
            {floors}
            {/* Ceiling Grid */}
            <gridHelper position={[0, WALL_HEIGHT, 0]} args={[dimensionGrid * CELL_SIZE, dimensionCells, 0x333333, 0x111111]} />

            {/* Dynamic Dilemma Orb - Has its own RigidBody */}
            <DilemmaOrb
                position={goalPos}
                id={`level_${level}_node`}
                title={`! LEVEL ${level} ANOMALY !`}
            />
        </group>
    );
};

export default NeonCity;
