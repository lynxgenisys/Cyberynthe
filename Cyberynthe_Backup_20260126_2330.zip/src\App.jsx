import React, { useState, useEffect } from 'react';
import './index.css';
import { PlayerProvider, usePlayer } from './context/PlayerContext';
import { GameProvider, useGame } from './context/GameContext';
import { InventoryProvider, useInventory } from './context/InventoryContext';
import { CombatProvider } from './context/CombatContext';
import { DirectiveEngine } from './engine/DirectiveEngine';
import DebugMazeView from './components/debug/DebugMazeView';
import CyberdeckUI from './components/ui/CyberdeckUI';
import TrinityHUD from './components/ui/TrinityHUD';
import HUD from './components/ui/HUD'; // NEW
import Scene3D from './components/3d/Scene';

function CoreInterface() {
  const { state: playerState, lockResource } = usePlayer();
  const { gameState, advanceFloor } = useGame();
  const { state: invState, addItem } = useInventory();

  const [isDeckOpen, setIsDeckOpen] = useState(false);
  const [activeOffer, setActiveOffer] = useState(null);
  const [currentDirective, setCurrentDirective] = useState(null);
  const [showDebug, setShowDebug] = useState(false);

  // Keyboard Shortcuts (Deck & Map & Actions)
  useEffect(() => {
    const handleKey = (e) => {
      const k = e.key.toLowerCase();
      // UI TOGGLES
      if (k === 'i') {
        setIsDeckOpen(prev => !prev);
      }
      if (k === 'm') setShowDebug(prev => !prev);

      // ACTIONS
      if (k === 'e') handleScan();
      if (k === '1') handleNav(); // DEBUG: Advance Floor
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState]); // Need GameState dep for correct floor advance if referencing state? 
  // Wait, advanceFloor is stable from context? handleScan depends on lockResource?
  // Let's check dependencies. handleNav calls advanceFloor. handleScan calls lockResource.
  // Closures might track old state if we don't include deps, or safer to just rely on Context function stability.
  // Actually, standard `addEventListener` in `useEffect` needs dependencies if the callbacks use state.
  // `lockResource` and `advanceFloor` are likely stable refs from Context.
  // But let's add them to be safe.

  // Sync Pause State Effect
  const { setGameState } = useGame();
  useEffect(() => {
    setGameState(prev => ({ ...prev, isPaused: isDeckOpen }));
  }, [isDeckOpen]);

  // QUEST INPUT (Y/N)
  useEffect(() => {
    if (!activeOffer) return;

    const handleQuestInput = (e) => {
      if (e.key.toLowerCase() === 'y') acceptOffer();
      if (e.key.toLowerCase() === 'n') setActiveOffer(null);
    };
    window.addEventListener('keydown', handleQuestInput);
    return () => window.removeEventListener('keydown', handleQuestInput);
  }, [activeOffer]);

  // REACTIVE QUEST TRIGGER (Directly observes Floor Level)
  // This ensures BOTH the Test Button AND the 3D Portal trigger the roll.
  useEffect(() => {
    if (gameState.floorLevel > 1) { // Skip spawn on run start
      console.log(`[SYSTEM]: NEW_FLOOR_DETECTED (${gameState.floorLevel}) // ROLLING_DIRECTIVE`);
      const offer = DirectiveEngine.rollDirective(gameState.floorLevel, gameState.isElite);
      if (offer) {
        setActiveOffer(offer);
      }
    }
  }, [gameState.floorLevel]);

  const handleScan = () => lockResource(15);

  // HUD Trigger - Just calls context, Effect handles the rest
  const handleNav = () => {
    advanceFloor();
  };

  const acceptOffer = () => {
    setCurrentDirective(activeOffer);
    setActiveOffer(null);
    console.log(`[SYSTEM]: DIRECTIVE_ACCEPTED: ${activeOffer.id}`);
  };

  return (
    <div className="relative w-full h-screen flex flex-col justify-between z-10 overflow-hidden">

      {/* 3D SCENE BACKGROUND */}
      <Scene3D />

      {/* GLOBAL HUD LAYER (Pass-through clicks) */}
      <div className="absolute inset-0 pointer-events-none">

        {/* REPLACED TrinityHUD & Header with new HUD */}
        <HUD /> {/* MAIN HEADS UP DISPLAY */}

      </div>

      {/* DIRECTIVE OFFER MODAL */}
      {activeOffer && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm pointer-events-auto">
          <div className="border border-magenta bg-black p-6 w-[400px] text-center">
            <h2 className="text-xl text-magenta font-bold mb-4">[INPUT_REQUIRED]</h2>
            <div className="text-left text-sm space-y-2 mb-6 font-mono text-gray-300">
              <p><span className="text-cyan">TASK:</span> {activeOffer.description}</p>
              <p><span className="text-yellow-400">REWARD:</span> {JSON.stringify(activeOffer.reward)}</p>
            </div>
            <div className="flex justify-center gap-4">
              <button onClick={acceptOffer} className="border border-cyan text-cyan px-6 py-2 hover:bg-cyan/20">ACCEPT (Y)</button>
              <button onClick={() => setActiveOffer(null)} className="border border-gray-600 text-gray-600 px-6 py-2 hover:bg-gray-800">DECLINE (N)</button>
            </div>
          </div>
        </div>
      )}

      {/* ACTIVE DIRECTIVE HUD */}
      {currentDirective && (
        <div className="absolute top-32 left-6 border-l-2 border-magenta pl-2 pointer-events-auto bg-black/50 p-2">
          <p className="text-[10px] text-magenta">ACTIVE DIRECTIVE</p>
          <p className="text-xs text-white">{currentDirective.id}</p>
          <p className="text-[10px] text-gray-400">{currentDirective.description}</p>
        </div>
      )}

      {/* FOOTER CONTROLS */}
      <footer className="absolute bottom-6 left-1/2 -translate-x-1/2 pointer-events-auto flex gap-4">
        <button onClick={handleScan} className="bg-black/80 border border-cyan text-cyan px-4 py-2 hover:bg-cyan/10 text-sm">SCAN (E)</button>
        <button onClick={handleNav} className="bg-black/80 border border-magenta text-magenta px-4 py-2 hover:bg-magenta/10 text-sm">NEXT_FLOOR (1)</button>
        <button onClick={() => setIsDeckOpen(true)} className="bg-black/80 text-yellow-400 border border-yellow-400/50 px-2 py-1 text-xs">[OPEN_DECK (I)]</button>
      </footer>

      {/* LAYERS */}
      {showDebug && <DebugMazeView />}
      {isDeckOpen && <CyberdeckUI onClose={() => setIsDeckOpen(false)} />}

    </div>
  );
}

export default function App() {
  return (
    <div className="w-full h-screen bg-black overflow-hidden relative">
      <GameProvider>
        <PlayerProvider>
          <InventoryProvider>
            <CombatProvider>
              <CoreInterface />
            </CombatProvider>
          </InventoryProvider>
        </PlayerProvider>
      </GameProvider>
    </div>
  );
}
