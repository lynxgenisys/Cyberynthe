import React, { useMemo, useEffect, useState } from 'react';
import { useGame } from '../../context/GameContext';
import { generateMaze } from '../../engine/MazeGenerator';
import { RigidBody } from '@react-three/rapier';
import MobManager from './MobManager';
import LootManager from './LootManager';
import InstancedWalls from './InstancedWalls';
import * as THREE from 'three';

/**
 * IDENTITY: ARCH_SYS_01
 * DIRECTIVE: Render the 3D Labyrinth with HD Procedural Textures & Objectives
 * OPTIMIZATION: InstancedMesh for Walls (Draw Calls: ~1)
 */

// Advanced Procedural Texture Generator (Kept same)
const createProceduralTexture = (type) => {
    const size = 1024;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');

    if (type === 'WALL_GRID') {
        // 1. Base: Matte Black Metal
        ctx.fillStyle = '#050510';
        ctx.fillRect(0, 0, size, size);

        // 2. Scanline Noise (Subtle)
        ctx.fillStyle = '#0a0a20';
        for (let i = 0; i < size; i += 4) {
            if (Math.random() > 0.5) ctx.fillRect(0, i, size, 2);
        }

        // 3. The Grid (Cyan)
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 16;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#00FFFF';

        ctx.strokeRect(0, 0, size, size);

        // Cross-Section
        ctx.beginPath();
        ctx.moveTo(size / 2, 0); ctx.lineTo(size / 2, size);
        ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2);
        ctx.stroke();

        // 4. Emissive Nodes (Corners)
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowBlur = 40;
        ctx.fillRect(0, 0, 32, 32);
        ctx.fillRect(size - 32, 0, 32, 32);
        ctx.fillRect(0, size - 32, 32, 32);
        ctx.fillRect(size - 32, size - 32, 32, 32);
        ctx.fillRect(size / 2 - 16, size / 2 - 16, 32, 32);
    }
    else if (type === 'FLOOR_PLATE') {
        // 1. Base: Dark Obsidian
        ctx.fillStyle = '#020205';
        ctx.fillRect(0, 0, size, size);

        // 2. Hex Pattern (Subtle detail)
        ctx.strokeStyle = '#111122';
        ctx.lineWidth = 4;
        ctx.beginPath();
        const hexSize = size / 8;
        for (let y = 0; y < size; y += hexSize) {
            for (let x = 0; x < size; x += hexSize) {
                ctx.strokeRect(x + (y % 2 === 0 ? 0 : hexSize / 2), y, hexSize, hexSize);
            }
        }
        ctx.stroke();

        // 3. Data Streams (Blue Highlights)
        ctx.strokeStyle = '#0066ff';
        ctx.lineWidth = 6;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#0066ff';
        ctx.beginPath();
        for (let i = 1; i < 4; i++) {
            ctx.moveTo(0, i * (size / 4));
            ctx.lineTo(size, i * (size / 4));
        }
        ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
};

export default function MazeRenderer() {
    const { gameState, advanceFloor, setGameState } = useGame();

    // HARD UNMOUNT DURING TRANSITION
    if (gameState.isTransitioning) return null;

    const maze = useMemo(() => {
        return generateMaze(gameState.seed, gameState.floorLevel);
    }, [gameState.seed, gameState.floorLevel]);

    // SYNC SPAWN POINT
    useEffect(() => {
        if (maze && maze.metadata.start) {
            console.log("[MAZE]: SYNCING_SPAWN ->", maze.metadata.start);
            setGameState(prev => ({ ...prev, spawnPoint: maze.metadata.start }));
        }
    }, [maze]);

    // LIFECYCLE DEBUG
    useEffect(() => {
        console.log(`[MAZE_RENDERER]: MOUNTED // FLOOR ${gameState.floorLevel}`);
        return () => console.log(`[MAZE_RENDERER]: UNMOUNTED // FLOOR ${gameState.floorLevel}`);
    }, [gameState.floorLevel]);

    // Generate HD Textures
    const wallTexture = useMemo(() => createProceduralTexture('WALL_GRID'), []);
    const floorTexture = useMemo(() => {
        const tex = createProceduralTexture('FLOOR_PLATE');
        tex.repeat.set(maze.width / 2, maze.height / 2);
        return tex;
    }, [maze.width, maze.height]);

    const WALL_HEIGHT = 4;
    const CELL_SIZE = 2;

    // Optimized Materials
    const wallMaterial = useMemo(() => new THREE.MeshStandardMaterial({
        map: wallTexture,
        color: '#ffffff',
        roughness: 0.2,
        metalness: 0.8,
        emissive: '#00FFFF',
        emissiveMap: wallTexture,
        emissiveIntensity: 0.8
    }), [wallTexture]);

    const floorMaterial = useMemo(() => new THREE.MeshStandardMaterial({
        map: floorTexture,
        color: '#8888aa',
        roughness: 0.1,
        metalness: 0.5,
    }), [floorTexture]);

    // INSTANCING LOGIC (Disabled for stability)
    // const wallInstances = ...

    // Cleanup: Explicitly dispose geometry on unmount to clear memory
    useEffect(() => {
        return () => {
            console.log("[ARCH_SYS]: FLUSHING_GEOMETRY");
            wallTexture.dispose();
            floorTexture.dispose();
            wallMaterial.dispose();
            floorMaterial.dispose();
        };
    }, [wallTexture, floorTexture, wallMaterial, floorMaterial]);


    return (
        <group>
            {/* FLOOR (Keep as one big RigidBody for smoothness) */}
            <RigidBody type="fixed" friction={2} position={[maze.width, -2.5, maze.height]}>
                <mesh receiveShadow>
                    {/* Scale the box slightly to cover edges */}
                    <boxGeometry args={[maze.width * CELL_SIZE * 2, 5, maze.height * CELL_SIZE * 2]} />
                    <meshStandardMaterial
                        map={floorTexture}
                        color="#ffffff"
                        metalness={0.8}
                        roughness={0.2}
                    />
                </mesh>
            </RigidBody>

            {/* OPTIMIZED INSTANCED WALLS */}
            <InstancedWalls
                maze={maze}
                wallMaterial={wallMaterial}
                cellSize={CELL_SIZE}
                wallHeight={WALL_HEIGHT}
            />

            {/* EXIT & START & CACHE (Dynamic items, keep separate) */}
            {maze.grid.flatMap((row, y) =>
                row.map((cell, x) => {
                    const xPos = x * CELL_SIZE;
                    const zPos = y * CELL_SIZE;

                    if (cell === 3) {
                        // EXIT
                        return (
                            <RigidBody
                                key={`exit-${x}-${y}`}
                                type="fixed"
                                sensor
                                onIntersectionEnter={() => {
                                    console.log("[SYSTEM]: PORTAL_BREACH // ADVANCING_FLOOR");
                                    advanceFloor();
                                }}
                                position={[xPos, 0, zPos]}
                            >
                                <group>
                                    <pointLight color="#EA00FF" intensity={2} distance={5} position={[0, 2, 0]} />
                                    <mesh position={[0, WALL_HEIGHT / 2, 0]}>
                                        <torusGeometry args={[1, 0.2, 16, 32]} />
                                        <meshStandardMaterial color="#EA00FF" emissive="#EA00FF" emissiveIntensity={2} />
                                    </mesh>
                                </group>
                            </RigidBody>
                        );
                    } else if (cell === 2) {
                        // START (Cyan Marker) - Just visual
                        return (
                            <group key={`start-${x}-${y}`} position={[xPos, 0.1, zPos]}>
                                <mesh rotation={[-Math.PI / 2, 0, 0]}>
                                    <ringGeometry args={[0.5, 0.8, 32]} />
                                    <meshStandardMaterial color="#00FFFF" emissive="#00FFFF" emissiveIntensity={1} />
                                </mesh>
                            </group>
                        );
                    }
                    return null;
                })
            )}

            {/* MOBS */}
            <MobManager maze={maze} floorLevel={gameState.floorLevel} />

            {/* LOOT */}
            <LootManager maze={maze} floorLevel={gameState.floorLevel} />
        </group>
    );
}
