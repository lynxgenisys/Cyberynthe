import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { useGame } from './GameContext';

/**
 * IDENTITY: LOGIC_BREACH_02 (The Engineer)
 * DIRECTIVE: Implement Hardware Resource System
 * CONSTRAINTS:
 * - Integrity Base: 100
 * - M-RAM Base: 110
 * - Clock Speed Base: 22 (11% Bonus)
 * - Anti-Fantasy: No "Mana" or "Regen" terms in UI. Use "Scrubbing".
 */

const PlayerContext = createContext();

const initialState = {
    stats: {
        integrity: 100,      // Max HP
        currentIntegrity: 100,
        mRamMax: 110,        // Max Resource
        mRamCurrent: 110,
        clockSpeed: 22,      // Speed/Cooldown Stat
        mRamRegenBase: 1.7,  // Per Second
    },
    systemState: {
        isScrubbing: false,  // If true, M-RAM is recovering from a lock
        scrubEfficiency: 1.0 // Multiplier derived from Clock Speed
    }
};

const ACTIONS = {
    INIT_SYSTEM: 'INIT_SYSTEM',
    LOCK_RESOURCE: 'LOCK_RESOURCE',
    TICK_SCRUB: 'TICK_SCRUB',
    TAKE_DAMAGE: 'TAKE_DAMAGE',
    MODIFY_CLOCK: 'MODIFY_CLOCK'
};

function playerReducer(state, action) {
    switch (action.type) {
        case ACTIONS.INIT_SYSTEM:
            return initialState;

        case ACTIONS.LOCK_RESOURCE: {
            // "Spending" M-RAM locks it.
            const { cost } = action.payload;
            if (state.stats.mRamCurrent < cost) return state; // Should be checked before dispatch
            return {
                ...state,
                stats: {
                    ...state.stats,
                    mRamCurrent: state.stats.mRamCurrent - cost
                },
                systemState: {
                    ...state.systemState,
                    isScrubbing: true
                }
            };
        }

        case ACTIONS.TICK_SCRUB: {
            // Regenerate M-RAM based on Clock Speed Logic
            // Scrub_Rate = Base_Rate * (1 + (Clock_Speed / 100))
            const { delta } = action.payload; // Time passed in seconds
            const speedBonus = state.stats.clockSpeed / 100;
            const scrubRate = state.stats.mRamRegenBase * (1 + speedBonus);

            const recovered = scrubRate * delta;
            const newCurrent = Math.min(state.stats.mRamCurrent + recovered, state.stats.mRamMax);

            return {
                ...state,
                stats: { ...state.stats, mRamCurrent: newCurrent },
                systemState: {
                    ...state.systemState,
                    isScrubbing: newCurrent < state.stats.mRamMax
                }
            };
        }

        case ACTIONS.TAKE_DAMAGE: {
            const { amount } = action.payload;
            const newIntegrity = Math.max(0, state.stats.currentIntegrity - amount);
            return {
                ...state,
                stats: { ...state.stats, currentIntegrity: newIntegrity }
            };
        }

        default:
            return state;
    }
}

export const PlayerProvider = ({ children }) => {
    const [state, dispatch] = useReducer(playerReducer, initialState);

    // The System Scrub Ticker
    useEffect(() => {
        const ticker = setInterval(() => {
            if (state.stats.mRamCurrent < state.stats.mRamMax) {
                dispatch({ type: ACTIONS.TICK_SCRUB, payload: { delta: 0.1 } }); // 100ms Tick
            }
        }, 100);
        return () => clearInterval(ticker);
    }, [state.stats.mRamCurrent, state.stats.mRamMax]);

    const lockResource = (cost) => {
        if (state.stats.mRamCurrent >= cost) {
            dispatch({ type: ACTIONS.LOCK_RESOURCE, payload: { cost } });
            return true;
        }
        return false;
    };

    const { checkPersistence } = useGame(); // Import Game Logic

    const damageKernel = (amount) => {
        dispatch({ type: ACTIONS.TAKE_DAMAGE, payload: { amount } });

        // Check Death (Post-Dispatch State isn't immediate here, so calculate manually)
        const resultingIntegrity = state.stats.currentIntegrity - amount;
        if (resultingIntegrity <= 0) {
            checkPersistence(resultingIntegrity);
            // If wiped, we should also reset Player State? 
            // checkPersistence handles GameState. Player state needs reset too.
            // Dispatch INIT_SYSTEM
            dispatch({ type: ACTIONS.INIT_SYSTEM });
        }
    };

    return (
        <PlayerContext.Provider value={{ state, lockResource, damageKernel }}>
            {children}
        </PlayerContext.Provider>
    );
};

export const usePlayer = () => useContext(PlayerContext);
