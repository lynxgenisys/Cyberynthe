import React, { useRef, useMemo, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useCombat } from '../../context/CombatContext';
import * as THREE from 'three';

/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Render Active Projectiles (OPTIMIZED)
 * MECHANIC: InstancedMesh for <1 draw call per frame
 */

const MAX_PROJECTILES = 200;

export default function ProjectileSystem() {
    const { projectilesRef } = useCombat();
    const meshRef = useRef();

    // Reusable Temporary Objects (Avoid GC)
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // Initialize Color Buffer
    useLayoutEffect(() => {
        if (meshRef.current) {
            const count = MAX_PROJECTILES;
            // Create buffer for colors (RGB * count)
            meshRef.current.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(count * 3), 3);
        }
    }, []);

    useFrame((state, delta) => {
        const mesh = meshRef.current;
        if (!mesh) return;

        // ... (rest of loop is fine, just ensure we use 'mesh' consistently)

        const projectiles = projectilesRef.current;
        let activeCount = 0;

        // Iterate backwards to allow safe removal? 
        // Actually CombatContext handles removal usually, but here we do logic too?
        // Context says: "ProjectileSystem should handle the loop."

        // We filter in place or create a new array. Mutating ref array in frame loop is risky if logic isn't careful.
        // Let's filter first since we need compact array for instancing (indices 0..N).

        // 1. UPDATE PHYSICS
        for (let i = 0; i < projectiles.length; i++) {
            const p = projectiles[i];
            p.life -= delta;

            if (p.life > 0) {
                p.position.addScaledVector(p.velocity, delta);

                // Void/Sky Clean up
                if (p.position.y < -10 || p.position.y > 20) p.life = 0;
            }
        }

        // 2. COMPACT & RENDER
        // We only render living projectiles.
        // We also need to clean up the ref array periodically so it doesn't grow infinitely with dead objects.
        // Doing filter() every frame creates garbage.
        // Better: Swap-remove dead ones? 
        // For simplicity/safety on "Phase 4", let's use a robust filter every frame for now. 
        // It's cheaper than 50 Draw calls.

        // Cleanup Dead
        if (projectiles.some(p => p.life <= 0)) {
            projectilesRef.current = projectiles.filter(p => p.life > 0);
        }

        const activeProjs = projectilesRef.current; // Refreshed list
        activeCount = Math.min(activeProjs.length, MAX_PROJECTILES);
        mesh.count = activeCount; // Update draw count

        for (let i = 0; i < activeCount; i++) {
            const p = activeProjs[i];

            // Position & Rotation
            tempObject.position.copy(p.position);

            // ALIGN TO VELOCITY (Look where you're going)
            // We need a target point in front of the projectile
            const target = p.position.clone().add(p.velocity);
            tempObject.lookAt(target);

            tempObject.updateMatrix();

            mesh.setMatrixAt(i, tempObject.matrix);

            // Color - INTENSE BLOOM
            const isPing = p.type === 'PING';
            // PING = Cyan/Yellow mix? User said Snippets. Let's stick to Yellow/Magenta for now but BRIGHT.
            tempColor.set(isPing ? '#FFFF00' : '#FF00FF');
            tempColor.multiplyScalar(10); // HDR Intensity for Bloom

            if (p.life < 0.1) {
                // Quick shrink pop
                tempObject.scale.setScalar(p.life * 10);
                tempObject.updateMatrix();
                mesh.setMatrixAt(i, tempObject.matrix);
            } else {
                tempObject.scale.setScalar(1);
            }

            mesh.setColorAt(i, tempColor);
        }

        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    });

    return (
        <instancedMesh ref={meshRef} args={[null, null, MAX_PROJECTILES]} frustumCulled={false}>
            {/* flattened cube for "Data Strip" look - Thinner */}
            <boxGeometry args={[0.6, 0.02, 0.02]} />
            <meshBasicMaterial
                toneMapped={false}
                color="#FFFFFF" // Tinted by instanceColor
            />
        </instancedMesh>
    );
}
