import React, { useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, CapsuleCollider, useRapier } from '@react-three/rapier';
import { KeyboardControls, PointerLockControls, useKeyboardControls } from '@react-three/drei';
import { useGame } from '../../context/GameContext'; // Import Logic Breach Link
import { useCombat } from '../../context/CombatContext';
import { usePlayer } from '../../context/PlayerContext';
import * as THREE from 'three';

const SPEED = 5;
const JUMP_FORCE = 5;
const CELL_SIZE = 2; // Must match MazeRenderer

const PlayerController = () => {
    const body = useRef();
    const [subscribeKeys, getKeys] = useKeyboardControls();
    const { camera } = useThree();
    const { updatePlayerPos, triggerScan } = useGame(); // Link to MapContext & Scan Trigger

    // Raycaster for ground check
    const rapier = useRapier();

    // Force Camera to look forward on spawn
    React.useEffect(() => {
        camera.rotation.set(0, 0, 0); // Reset rotation
        camera.lookAt(new THREE.Vector3(0, 5, -100)); // Look at horizon
    }, [camera]);

    // Combat & Resources
    const { fireProjectile } = useCombat();
    const { lockResource } = usePlayer();

    // RESET POSITION ON FLOOR CHANGE (Dynamic Spawn)
    const { gameState } = useGame();
    React.useEffect(() => {
        if (body.current && gameState.spawnPoint) {
            const { x, y } = gameState.spawnPoint;
            // Convert Grid to World (Cell Size 2)
            // Spawn height 2.5
            const worldX = x * 2;
            const worldZ = y * 2;

            body.current.setTranslation({ x: worldX, y: 2.5, z: worldZ }, true);
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
            console.log(`[PLAYER]: SPAWN_RESET // FLOOR_${gameState.floorLevel} // POS [${worldX}, ${worldZ}]`);
        }
    }, [gameState.floorLevel, gameState.spawnPoint]);

    // COMBAT INPUT
    React.useEffect(() => {
        if (gameState.isPaused) return;

        const handleMouseDown = (e) => {
            if (!document.pointerLockElement) return; // Only fire if locked

            // Calulate Direction
            const direction = new THREE.Vector3();
            camera.getWorldDirection(direction);
            const startPos = body.current.translation();
            // Start directly in front of camera (Eye Level) for "ADS" feel
            // Eye level ~1.5. Distance 0.2 (Very close).
            const spawnPos = new THREE.Vector3(startPos.x, startPos.y + 1.5, startPos.z).add(direction.clone().multiplyScalar(0.2));

            // LEFT CLICK (0) -> PING (Yellow, 2 M-RAM)
            if (e.button === 0) {
                if (lockResource(2)) {
                    fireProjectile(spawnPos, direction, 'PING');
                    // Recoil could go here
                } else {
                    console.log("[SYSTEM]: RESOURCES_EXHAUSTED // UNABLE_TO_COMPILE_PING");
                }
            }

            // RIGHT CLICK (2) -> BIT_FLIP (Magenta, 5 M-RAM)
            if (e.button === 2) {
                if (lockResource(5)) {
                    fireProjectile(spawnPos, direction, 'SHRED');
                }
            }
        };

        const handleKeyDown = (e) => {
            if (!document.pointerLockElement) return;

            // 'E' -> SCAN PULSE (Green, 10 M-RAM)
            if (e.code === 'KeyE') {
                if (lockResource(10)) {
                    console.log("[PLAYER]: SCAN_INITIATED");
                    triggerScan(); // Updates Global State -> Triggers Shockwave & HUD
                } else {
                    console.log("[SYSTEM]: INSUFFICIENT_RAM // UNABLE_TO_SCAN");
                }
            }
        };

        window.addEventListener('mousedown', handleMouseDown);
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('mousedown', handleMouseDown);
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [gameState.isPaused, camera, fireProjectile, lockResource, triggerScan]);

    useFrame((state, delta) => {
        if (!body.current) return;

        // FREEZE PHYSICS DURING TRANSITION (Prevents falling into void when map unloads)
        if (gameState.isTransitioning) {
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
            body.current.setAngvel({ x: 0, y: 0, z: 0 }, true); // Also freeze rotation just in case
            return;
        }

        // Get Input
        const { forward, backward, leftward, rightward, jump } = getKeys();

        // Get Velocity
        const linvel = body.current.linvel();

        // Calculate Movement Vector relative to Camera
        const forwardDir = new THREE.Vector3();
        camera.getWorldDirection(forwardDir);
        forwardDir.y = 0; // Flatten
        forwardDir.normalize();

        const rightDir = new THREE.Vector3();
        rightDir.crossVectors(forwardDir, new THREE.Vector3(0, 1, 0)); // Right is Forward x Up

        const direction = new THREE.Vector3();

        if (forward) direction.add(forwardDir);
        if (backward) direction.sub(forwardDir);
        if (rightward) direction.add(rightDir);
        if (leftward) direction.sub(rightDir);

        if (direction.lengthSq() > 0) {
            const currentSpeed = getKeys().run ? SPEED * 1.6 : SPEED;
            direction.normalize().multiplyScalar(currentSpeed);
        }

        // Apply Velocity (preserve vertical velocity for gravity)
        body.current.setLinvel({ x: direction.x, y: linvel.y, z: direction.z }, true);

        // Jump
        if (jump && Math.abs(linvel.y) < 0.1) {
            body.current.applyImpulse({ x: 0, y: JUMP_FORCE, z: 0 }, true);
        }

        // SYNC CAMERA
        const translation = body.current.translation();
        camera.position.set(translation.x, translation.y + 1.5, translation.z);

        // SYNC MAP (Throttle this in production, but okay for prototype)
        const gridX = Math.round(translation.x / CELL_SIZE);
        const gridY = Math.round(translation.z / CELL_SIZE);
        updatePlayerPos(gridX, gridY);

        // VOID CATCH PROTOCOL (Bug -> Feature)
        if (translation.y < -10) {
            console.warn("[SYSTEM]: ANOMALY_DETECTED // PLAYER_FELL_INTO_VOID");
            // Respawn at Start
            body.current.setTranslation({ x: 2, y: 3, z: 2 }, true); // Drop from slight height
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
            // Optional: Deduct HP here call a hit function
        }
    });

    return (
        <group>
            <RigidBody
                ref={body}
                colliders={false}
                position={[2, 2, 2]} // Lowered spawn
                enabledRotations={[false, false, false]}
                friction={0}
            >
                <CapsuleCollider args={[0.5, 0.5]} />
                <mesh visible={false}>
                    <capsuleGeometry args={[0.5, 1]} />
                    <meshStandardMaterial color="cyan" />
                </mesh>
            </RigidBody>

            {/* Only lock pointer if game is NOT paused */}
            {!gameState.isPaused && <PointerLockControls />}
        </group>
    );
};

const Player = () => {
    const keyboardMap = [
        { name: 'forward', keys: ['ArrowUp', 'KeyW'] },
        { name: 'backward', keys: ['ArrowDown', 'KeyS'] },
        { name: 'leftward', keys: ['ArrowLeft', 'KeyA'] },
        { name: 'rightward', keys: ['ArrowRight', 'KeyD'] },
        { name: 'jump', keys: ['Space'] },
        { name: 'run', keys: ['Shift'] },
    ];

    return (
        <KeyboardControls map={keyboardMap}>
            <PlayerController />
        </KeyboardControls>
    );
};

export default Player;
