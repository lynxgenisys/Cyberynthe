import React from 'react';
import { useInventory } from '../../context/InventoryContext';
import { useGame } from '../../context/GameContext';
import ChromaticContainer from './ChromaticContainer';

/**
 * IDENTITY: GRADIENT_MORALS_04
 * DIRECTIVE: Render the Cyberdeck Interface
 */

export default function CyberdeckUI({ onClose }) {
    const { state, equipItem } = useInventory();
    const { gameState } = useGame();

    const handleEquip = (item, type, index) => {
        equipItem(item, type, index);
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-8 backdrop-blur-sm">
            <ChromaticContainer className="w-full max-w-4xl h-[80vh] flex flex-col pointer-events-auto">

                {/* HEADER */}
                <div className="flex justify-between items-center border-b border-cyan/30 pb-4 mb-4">
                    <h2 className="text-xl text-cyan-glow font-bold">CYBERDECK_V1.0 // {gameState.playerName}</h2>
                    <button onClick={onClose} className="text-magenta hover:text-white font-mono">[CLOSE_DECK]</button>
                </div>

                <div className="flex flex-1 gap-6 overflow-hidden">

                    {/* LEFT: HARDWARE PORTS */}
                    <div className="w-1/4 flex flex-col gap-4 border-r border-gray-800 pr-4">
                        <h3 className="text-xs text-gray-500 mb-2">HARDWARE_PORTS</h3>

                        {/* BUS PORT */}
                        <div className="border border-cyan/20 p-2 min-h-[80px]">
                            <span className="text-[10px] text-cyan block mb-1">BUS_PORT</span>
                            {state.hardware.bus ? (
                                <div className="text-sm text-white">{state.hardware.bus.name}</div>
                            ) : <div className="text-xs text-gray-600">[EMPTY_SLOT]</div>}
                        </div>

                        {/* CORE SOCKET */}
                        <div className="border border-cyan/20 p-2 min-h-[80px]">
                            <span className="text-[10px] text-cyan block mb-1">CORE_SOCKET</span>
                            {state.hardware.core ? (
                                <div className="text-sm text-white">{state.hardware.core.name}</div>
                            ) : <div className="text-xs text-gray-600">[EMPTY_SLOT]</div>}
                        </div>

                        {/* I/O PORT */}
                        <div className="border border-cyan/20 p-2 min-h-[80px]">
                            <span className="text-[10px] text-cyan block mb-1">I/O_PORT</span>
                            {state.hardware.io ? (
                                <div className="text-sm text-white">{state.hardware.io.name}</div>
                            ) : <div className="text-xs text-gray-600">[EMPTY_SLOT]</div>}
                        </div>
                    </div>

                    {/* CENTER: ACTIVE MEMORY */}
                    <div className="flex-1 flex flex-col items-center justify-center gap-8">
                        {/* ACTIVE THREADS */}
                        <div className="flex gap-4">
                            {state.slots.active.map((slot, i) => (
                                <div key={`active-${i}`} className="w-24 h-24 border-2 border-magenta/50 flex flex-col items-center justify-center p-2 text-center hover:bg-magenta/10 cursor-pointer">
                                    <span className="text-[10px] text-magenta mb-1">THREAD_{i}</span>
                                    {slot ? <span className="text-xs">{slot.name}</span> : <span className="text-[10px] text-gray-600">NULL</span>}
                                </div>
                            ))}
                        </div>

                        {/* PASSIVE DAEMONS */}
                        <div className="flex gap-4">
                            {state.slots.passive.map((slot, i) => (
                                <div key={`passive-${i}`} className="w-20 h-20 border border-blue-500/30 flex flex-col items-center justify-center p-2 text-center hover:bg-blue-500/10 cursor-pointer">
                                    <span className="text-[10px] text-blue-400 mb-1">DAEMON_{i}</span>
                                    {slot ? <span className="text-xs">{slot.name}</span> : <span className="text-[10px] text-gray-600">NULL</span>}
                                </div>
                            ))}
                        </div>

                        {/* RELAY SLOT */}
                        <div className="w-16 h-16 border border-gray-600 rounded-full flex items-center justify-center">
                            <span className="text-[10px] text-gray-500">RELAY</span>
                        </div>
                    </div>

                    {/* RIGHT: BACKPACK (GRID) */}
                    <div className="w-1/3 flex flex-col gap-2 pl-4 border-l border-gray-800">
                        <div className="flex justify-between items-end mb-2">
                            <h3 className="text-xs text-gray-500">STORAGE_PARTITION</h3>
                            <span className={`text-xs ${state.overhead > 10 ? 'text-magenta animate-pulse' : 'text-gray-400'}`}>
                                SYS_OVERHEAD: {state.overhead}%
                            </span>
                        </div>

                        <div className="grid grid-cols-3 gap-2 overflow-y-auto max-h-[400px]">
                            {state.backpack.map((item, i) => (
                                <div
                                    key={i}
                                    onClick={() => handleEquip(item, 'active', 0)} // Debug: Quick Equip to Slot 0
                                    className="aspect-square border border-gray-700 bg-gray-900/50 p-1 flex items-center justify-center text-center cursor-pointer hover:border-white transition-colors"
                                    title={item.description}
                                >
                                    <span className="text-[10px] break-words leading-tight">{item.name}</span>
                                </div>
                            ))}
                            {/* Empty Slots Filler */}
                            {Array(12 - state.backpack.length).fill(0).map((_, i) => (
                                <div key={`empty-${i}`} className="aspect-square border border-gray-800/30"></div>
                            ))}
                        </div>
                    </div>

                </div>
            </ChromaticContainer>
        </div>
    );
}
