import React, { createContext, useContext, useState, useRef, useCallback } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Manage Combat State (Projectiles & Hit Registration)
 */

const CombatContext = createContext();

export const CombatProvider = ({ children }) => {
    // We use a Ref for projectiles to avoid React Render Cycle Thrashing on every frame update
    // We only trigger re-renders when adding/removing, but the movement is ref-based
    const projectilesRef = useRef([]);
    const [projectileCount, setProjectileCount] = useState(0); // Force render on spawn

    const fireProjectile = useCallback((startPos, direction, type) => {
        const id = Date.now() + Math.random();
        projectilesRef.current.push({
            id,
            position: startPos.clone(),
            velocity: direction.clone().multiplyScalar(type === 'PING' ? 40 : 25), // PING is fast, SHRED is slow
            type, // 'PING' (Yellow) or 'SHRED' (Magenta)
            life: 2.0 // Seconds
        });
        setProjectileCount(prev => prev + 1);
    }, []);

    // Frame Loop Logic will be handled in a helper hook or component
    // But the Context provides the API

    const updateProjectiles = (delta) => {
        let dirty = false;
        projectilesRef.current = projectilesRef.current.filter(p => {
            p.life -= delta;

            // Move
            p.position.addScaledVector(p.velocity, delta);

            // Simple Floor/Ceiling collision (Ground is 0, Ceiling is 4)
            if (p.position.y < 0 || p.position.y > 4) return false;

            // TODO: Wall Collision (Raycast needed)

            return p.life > 0;
        });

        // Optimization: Don't trigger state update on simple movement, only if count changes
        // But React needs to know to re-render the mesh positions...
        // Actually, ProjectileSystem should handle the loop.
    };

    return (
        <CombatContext.Provider value={{ projectilesRef, fireProjectile, projectileCount }}>
            {children}
        </CombatContext.Provider>
    );
};

export const useCombat = () => useContext(CombatContext);
