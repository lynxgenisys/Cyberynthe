import React, { createContext, useContext, useState, useEffect } from 'react';

/**
 * IDENTITY: LOGIC_BREACH_02 (The Engineer)
 * DIRECTIVE: Implement Meta-Game State (Seeds & Levels)
 * CONSTRAINTS:
 * - Seed: Derived from Date().toDateString() (Daily Run)
 * - Sector Logic: Level / 25
 */

const GameContext = createContext();

export const GameProvider = ({ children }) => {
    const [gameState, setGameState] = useState({
        seed: '',
        floorLevel: 1,
        sectorId: 1,
        playerName: 'GHOST_USER',
        isPaused: false,
        isElite: false, // Permadeath Mode
        activePenalties: [],
        activePenalties: [],
        playerGridPos: { x: 1, y: 1 }, // Track player for Map
        spawnPoint: null, // Dynamic Spawn Point (Grid Coords)
        ethicsScore: 0.5, // 0.0 (Cyan) to 1.0 (Magenta)
        eBits: 0, // Currency
        isTransitioning: false, // Floor Loading State
        lootedCaches: [], // Array of IDs "x,y"
        notifications: [], // Array of {id, msg, time}
        xp: 0, // Experience Points
        scanningState: { active: false, progress: 0 } // For HUD UI
    });

    const addNotification = (msg) => {
        const id = Date.now();
        setGameState(prev => ({
            ...prev,
            notifications: [...prev.notifications, { id, msg, time: Date.now() }].slice(-5) // Keep last 5
        }));
        // Auto-dismiss logic handled in UI or just keep internal log
    };

    const markCacheLooted = (x, y) => {
        const id = `${x},${y}`;
        setGameState(prev => ({
            ...prev,
            lootedCaches: [...prev.lootedCaches, id]
        }));
    };

    // PERSISTENCE PROTOCOL
    const checkPersistence = (currentIntegrity) => {
        if (currentIntegrity <= 0) {
            if (gameState.isElite) {
                console.warn("[SYSTEM]: ELITE_MODE_DEATH // WIPING_SESSION");
                // Reset to Floor 1, Seed Reset
                setGameState(prev => ({
                    ...prev,
                    floorLevel: 1,
                    sectorId: 1,
                    seed: btoa(Date.now().toString()).substring(0, 16)
                }));
                return 'WIPED';
            } else {
                console.log("[SYSTEM]: STANDARD_DEATH // RESPAWNING");
                // In standard, we would decrease loot, etc.
                return 'RESPAWNED';
            }
        }
    };

    // Initialize Session Seed
    useEffect(() => {
        const timestamp = Date.now().toString();
        // Uses current milliseconds for a truly unique session seed
        const seedHash = btoa(timestamp + "_CYBERYNTHE_SESSION").substring(0, 16);

        setGameState(prev => ({
            ...prev,
            seed: seedHash
        }));

        console.log(`[SYSTEM]: DAILY_SEED_INITIATED: ${seedHash}`);
    }, []);

    const advanceFloor = () => {
        // 1. SIGNAL TRANSITION START (Unmounts Maze)
        setGameState(prev => ({ ...prev, isTransitioning: true }));

        // 2. DELAY & UPDATE FLOOR
        setTimeout(() => {
            setGameState(prev => {
                const nextFloor = prev.floorLevel + 1;

                // ASCENSION CHECK REMOVED -> ENDLESS MODE
                if (nextFloor === 100) {
                    console.log("[SYSTEM]: CLASS_CHOICE_MILESTONE_REACHED");
                    // TODO: Trigger Class Selection UI
                }

                const nextSector = Math.ceil(nextFloor / 25);
                return {
                    ...prev,
                    floorLevel: nextFloor,
                    sectorId: nextSector,
                    spawnPoint: null,
                    scanningState: { active: false, progress: 0 }, // FORCE RESET UI
                    // Keep transitioning true until fully loaded
                    isTransitioning: true
                };
            });

            // 3. FINISH TRANSITION (Remounts Maze)
            // Giving Rapier 500ms to fully flush physics world
            setTimeout(() => {
                setGameState(prev => ({ ...prev, isTransitioning: false }));
                console.log("[SYSTEM]: TRANSITION_COMPLETE // SIMULATION_RESUMED");
            }, 500);

        }, 100);
    };

    const updatePlayerPos = (x, y) => {
        // Only update if changed to avoid render thrashing
        if (x !== gameState.playerGridPos.x || y !== gameState.playerGridPos.y) {
            setGameState(prev => ({ ...prev, playerGridPos: { x, y } }));
        }
    };

    const updateScanningState = (active, progress) => {
        setGameState(prev => ({ ...prev, scanningState: { active, progress } }));
    };

    const triggerScan = () => {
        setGameState(prev => ({ ...prev, lastScanTime: Date.now() }));
    };

    return (
        <GameContext.Provider value={{
            gameState,
            advanceFloor,
            updatePlayerPos,
            setGameState,
            checkPersistence,
            addNotification,
            markCacheLooted,
            updateScanningState,
            triggerScan
        }}> {/* Exposing setGameState for Pause */}
            {children}
        </GameContext.Provider>
    );
};

export const useGame = () => useContext(GameContext);
