/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Advanced Mob Behaviors
 */

export const BESTIARY = {
    BIT_MITE: {
        id: 'BIT_MITE',
        name: 'Bit Mite',
        hp: 20,
        dmg: 5,
        telegraph: null // Simple melee
    },
    STATELESS_SENTRY: {
        id: 'STATELESS_SENTRY',
        name: 'Stateless Sentry',
        hp: 50,
        dmg: 10,
        telegraph: {
            color: '#00FFFF', // Cyan
            duration: 1000,
            msg: 'DATA_STREAM_CHARGING'
        }
    },
    STATEFUL_TRACKER: {
        id: 'STATEFUL_TRACKER',
        name: 'Stateful Tracker',
        hp: 120,
        dmg: 15,
        telegraph: {
            color: '#EA00FF', // Magenta
            duration: 1500,
            msg: 'MEMORY_LEAK_SPOOLING'
        },
        special: 'PHASE_LOCK'
    },
    SECTOR_GUARDIAN: {
        id: 'SECTOR_GUARDIAN',
        name: 'Sector Guardian',
        hp: 500,
        dmg: 50,
        telegraph: {
            color: '#FFFFFF', // White Hot
            duration: 3000,
            msg: 'FIREWALL_PURGE_INITIATED'
        },
        special: 'BOSS'
    }
};

export const MobLogic = {
    createMob: (type, floorLevel) => {
        const base = BESTIARY[type];
        if (!base) return null;

        // Scaling Logic: +10% stats per 10 floors
        const scale = 1 + Math.floor(floorLevel / 10) * 0.1;

        return {
            ...base,
            maxHp: Math.floor(base.hp * scale),
            currentHp: Math.floor(base.hp * scale),
            damage: Math.floor(base.dmg * scale),
            isTelegraphing: false,
            telegraphTimer: 0
        };
    }
};
