import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGame } from '../../context/GameContext';
import { useInventory } from '../../context/InventoryContext';


/**
 * IDENTITY: GRADIENT_MORALS_04
 * DIRECTIVE: Manage Loot Cache Interaction
 * MECHANIC: Proximity -> Scrubbing Bar (2s) -> Loot
 */

const LootCache = ({ cache, onLoot }) => {
    const [scrubProgress, setScrubProgress] = useState(0); // 0 to 1
    const { gameState, updateScanningState } = useGame();
    const isActive = useRef(false);
    const isLooted = cache.isLooted;

    // Cleanup on unmount (e.g., walking far away if culling happened, or level unload)
    useEffect(() => {
        return () => {
            if (isActive.current) {
                updateScanningState(false, 0);
            }
        };
    }, []);

    // Force Reset UI if looted (while we were scanning)
    useEffect(() => {
        if (isLooted && isActive.current) {
            updateScanningState(false, 0);
            isActive.current = false;
        }
    }, [isLooted]);

    useFrame((state, delta) => {
        if (isLooted) return;

        // Proximity Check
        const playerX = gameState.playerGridPos.x * 2;
        const playerZ = gameState.playerGridPos.y * 2;
        const dx = playerX - cache.x;
        const dz = playerZ - cache.z;
        const distSq = dx * dx + dz * dz;

        // Radius: 2 units (1 Cell)
        if (distSq < 4) {
            // Scrubbing
            setScrubProgress(prev => {
                const next = Math.min(prev + delta / 2, 1);
                // Sync to Global UI
                updateScanningState(true, next);
                isActive.current = true;
                return next;
            });

            if (scrubProgress >= 1) {
                onLoot(cache.id);
                updateScanningState(false, 0); // Reset UI
            }
        } else {
            // Decay
            if (scrubProgress > 0) {
                setScrubProgress(prev => {
                    const next = Math.max(prev - delta, 0);
                    // Only update UI if we were the one scanning
                    if (isActive.current) {
                        updateScanningState(next > 0, next);
                        if (next === 0) isActive.current = false;
                    }
                    return next;
                });
            }
        }
    });

    if (isLooted) {
        return null;
    }

    return (
        <group position={[cache.x, 0.5, cache.z]}>
            {/* The Box */}
            <mesh position={[0, 0.5, 0]}>
                <boxGeometry args={[1, 1, 1]} />
                <meshStandardMaterial
                    color="#FFFF00"
                    emissive="#FFAA00"
                    emissiveIntensity={scrubProgress > 0 ? 0.5 + scrubProgress : 0.5}
                />
            </mesh>
        </group>
    );
};

export default function LootManager({ maze, floorLevel }) {
    // We no longer need local 'caches' state for isLooted, but we need the list of caches.
    // Memoizing the list of caches based on the maze is still correct.
    const [caches, setCaches] = useState([]);
    const { addItem } = useInventory();
    const { gameState, setGameState, addNotification, markCacheLooted } = useGame();

    // INITIAL SPAWN
    useMemo(() => {
        const newCaches = [];
        if (!maze || !maze.grid) return;

        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell === 9) { // TILE.CACHE
                    newCaches.push({
                        id: `${x},${z}`, // DETERMINISTIC ID
                        x: x * 2,
                        z: z * 2
                    });
                }
            });
        });
        setCaches(newCaches);
    }, [maze]);

    const handleLoot = (cacheId) => {
        // 1. Mark Looted in Global State
        const [cx, cz] = cacheId.split(',').map(Number);
        markCacheLooted(cx, cz);

        // 2. Reward
        const dropAmount = Math.floor(Math.random() * 10) + 5; // 5-15 eBits
        console.log(`[LOOT]: CACHE_DECOMPILED // +${dropAmount} eBITS`);

        addNotification(`CACHE_DECRYPTED: +${dropAmount} eBITS`);

        // Update Game State (eBits)
        setGameState(prev => ({
            ...prev,
            eBits: (prev.eBits || 0) + dropAmount
        }));

        // 10% Chance for Consumable
        if (Math.random() < 0.1) {
            addItem('BUFFER_REFRESH'); // ID from Registry?
            addNotification(`BOOT_SECTOR_FOUND: BUFFER_REFRESH`);
            console.log("[LOOT]: RARE_ITEM_FOUND");
        }
    };

    return (
        <group>
            {caches.map(cache => {
                // Check Global State
                const isLooted = gameState.lootedCaches.includes(cache.id);
                return (
                    <LootCache
                        key={cache.id}
                        cache={{ ...cache, isLooted }}
                        onLoot={handleLoot}
                    />
                );
            })}
        </group>
    );
}
