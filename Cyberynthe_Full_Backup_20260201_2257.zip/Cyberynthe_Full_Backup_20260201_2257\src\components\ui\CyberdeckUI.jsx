import React, { useState } from 'react';
import { useInventory } from '../../context/InventoryContext';
import { useGame } from '../../context/GameContext';
import { usePlayer } from '../../context/PlayerContext'; // Import Player Context
import ChromaticContainer from './ChromaticContainer';

/**
 * IDENTITY: GRADIENT_MORALS_04
 * DIRECTIVE: Render the Cyberdeck Interface
 */

const StatRow = ({ label, value, alloc, canUpgrade, onUpgrade, color }) => (
    <div className={`border border-${color} bg-black/40 p-2 flex justify-between items-center`}>
        <div>
            <div className={`text-[10px] text-${color} font-bold`}>{label}</div>
            <div className="text-sm text-white font-mono">{value}</div>
        </div>
        <div className="flex flex-col items-end gap-1">
            <div className="text-[10px] text-gray-500">+{alloc} PTS</div>
            {canUpgrade && (
                <button
                    onClick={onUpgrade}
                    className="bg-yellow-500 text-black text-[10px] px-2 py-0.5 hover:bg-yellow-400 font-bold"
                >
                    [+]
                </button>
            )}
        </div>
    </div>
);

export default function CyberdeckUI({ onClose }) {
    const { state, equipItem, unequipItem } = useInventory();
    const { gameState, getLevelFromXP, getNextLevelXP, cycleNavMode } = useGame();
    const { state: playerState, upgradeStat } = usePlayer();

    // UI Local State
    const [selectedItem, setSelectedItem] = useState(null);

    // FORCE UNLOCK POINTER ON OPEN
    React.useEffect(() => {
        document.exitPointerLock();
    }, []);

    // LEVELING MATH
    const level = getLevelFromXP(gameState.xp || 0);
    const totalPoints = (level - 1) * 2;
    // Defensive check for allocations
    const spentPoints = Object.values(playerState.allocations || { integrity: 0, mRam: 0, clock: 0, regen: 0 }).reduce((a, b) => a + b, 0);
    const availablePoints = totalPoints - spentPoints;

    // HANDLERS
    const handleBackpackClick = (item) => {
        if (selectedItem && selectedItem.id === item.id) {
            setSelectedItem(null); // Deselect
        } else {
            setSelectedItem(item);
        }
    };

    const handleSlotClick = (index) => {
        const slotItem = gameState.inventorySlots[index];

        if (selectedItem) {
            // Equip selected item to this slot
            equipItem(selectedItem, 'active', index);
            setSelectedItem(null);
        } else if (slotItem) {
            // Unequip item from this slot
            unequipItem(index);
        }
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-8 backdrop-blur-sm">
            <ChromaticContainer className="w-full max-w-4xl h-[80vh] flex flex-col pointer-events-auto">

                {/* HEADER */}
                <div className="flex justify-between items-center border-b border-cyan/30 pb-4 mb-4">
                    <h2 className="text-xl text-cyan-glow font-bold">CYBERDECK_V1.0 // {gameState.playerName}</h2>
                    <button onClick={onClose} className="text-magenta hover:text-white font-mono">[CLOSE_DECK]</button>
                </div>

                <div className="flex flex-1 gap-6 overflow-hidden">

                    {/* LEFT: KERNEL ARCHITECTURE (Stats) */}
                    <div className="w-1/4 flex flex-col gap-4 border-r border-gray-800 pr-4">
                        <div className="mb-2">
                            <h3 className="text-sm text-cyan font-bold tracking-widest">KERNEL_ARCH</h3>
                            <div className="text-xs text-gray-500 font-mono">LEVEL {level} // {gameState.xp} XP</div>

                            {/* XP PROGRESS BAR */}
                            <div className="w-full h-1 bg-gray-800 mt-1 relative">
                                <div
                                    className="h-full bg-cyan-500 shadow-[0_0_5px_#00FFFF]"
                                    style={{ width: `${Math.min(100, Math.max(0, ((gameState.xp - getNextLevelXP(level - 1)) / (getNextLevelXP(level) - getNextLevelXP(level - 1))) * 100))}%` }}
                                />
                            </div>


                        </div>

                        {/* NAV MODE TOGGLE */}
                        <div className="border border-cyan bg-black/40 p-2 flex justify-between items-center mb-2">
                            <div>
                                <div className="text-[10px] text-cyan font-bold">NAV_SYSTEM</div>
                                <div className="text-xs text-white font-mono">{gameState.navSettings.mode}</div>
                            </div>
                            <button
                                onClick={cycleNavMode}
                                className="bg-cyan/20 text-cyan text-[10px] px-2 py-1 hover:bg-cyan hover:text-black font-bold border border-cyan"
                            >
                                [CYCLE]
                            </button>
                        </div>

                        {/* POINTS DISPLAY */}
                        <div className={`text-xs font-mono border border-gray-700 p-2 text-center ${availablePoints > 0 ? 'text-yellow-500 border-yellow-500 animate-pulse' : 'text-gray-600'}`}>
                            UNALLOCATED_POINTS: {availablePoints}
                        </div>

                        <div className="flex flex-col gap-3 mt-2 overflow-y-auto">
                            {/* INTEGRITY */}
                            <StatRow
                                label="INTEGRITY"
                                value={playerState.stats.integrity}
                                alloc={(playerState.allocations?.integrity || 0) + (playerState.bonuses?.integrity || 0)}
                                canUpgrade={availablePoints > 0}
                                onUpgrade={() => upgradeStat('integrity')}
                                color="cyan"
                            />
                            {/* M-RAM */}
                            <StatRow
                                label="M-RAM_CAP"
                                value={playerState.stats.mRamMax}
                                alloc={(playerState.allocations?.mRam || 0) + (playerState.bonuses?.mRam || 0)}
                                canUpgrade={availablePoints > 0}
                                onUpgrade={() => upgradeStat('mRam')}
                                color="magenta"
                            />
                            {/* CLOCK SPEED */}
                            <StatRow
                                label="CLOCK_SPD"
                                value={playerState.stats.clockSpeed + '%'}
                                alloc={(playerState.allocations?.clock || 0) + (playerState.bonuses?.clock || 0)}
                                canUpgrade={availablePoints > 0}
                                onUpgrade={() => upgradeStat('clock')}
                                color="green-500"
                            />
                            {/* REGEN */}
                            <StatRow
                                label="SCRUB_RATE"
                                value={playerState.stats.mRamRegenBase.toFixed(1) + '/s'}
                                alloc={(playerState.allocations?.regen || 0) + (playerState.bonuses?.regen || 0)}
                                canUpgrade={availablePoints > 0}
                                onUpgrade={() => upgradeStat('regen')}
                                color="blue-500"
                            />
                        </div>
                    </div>

                    {/* CENTER: ACTIVE MEMORY */}
                    <div className="flex-1 flex flex-col items-center justify-center gap-8">
                        {/* ACTIVE THREADS (HOTKEYS) */}
                        <div>
                            <h3 className="text-xs text-center text-magenta font-mono mb-2 tracking-widest">[ACTIVE_THREADS // HOTKEYS]</h3>
                            <div className="flex gap-4">
                                {gameState.inventorySlots.map((slot, i) => (
                                    <div
                                        key={`active-${i}`}
                                        onClick={() => handleSlotClick(i)}
                                        className={`w-24 h-24 border-2 flex flex-col items-center justify-center p-2 text-center cursor-pointer transition-all duration-200
                                            ${selectedItem ? 'border-yellow-500 animate-pulse bg-yellow-900/20' : 'border-magenta/50 hover:bg-magenta/10'}
                                            ${slot ? 'bg-magenta/5' : ''}
                                        `}
                                    >
                                        <span className="text-[10px] text-magenta mb-1 font-bold">KEY_{i + 1}</span>
                                        {slot ? (
                                            <>
                                                <div className="w-8 h-8 bg-magenta mb-1 rounded-sm shadow-[0_0_10px_#EA00FF]"></div>
                                                <span className="text-xs font-mono">{slot.name}</span>
                                            </>
                                        ) : (
                                            <span className="text-[10px] text-gray-600 font-mono">EMPTY</span>
                                        )}
                                    </div>
                                ))}
                            </div>
                            <div className="text-[10px] text-gray-500 text-center mt-2 font-mono">
                                {selectedItem ? "SELECT SLOT TO EQUIP" : "CLICK SLOT TO UNEQUIP"}
                            </div>
                        </div>

                        {/* PASSIVE DAEMONS */}
                        <div className="flex gap-4 opacity-50 pointer-events-none">
                            {state.slots.passive.map((slot, i) => (
                                <div key={`passive-${i}`} className="w-20 h-20 border border-blue-500/30 flex flex-col items-center justify-center p-2 text-center hover:bg-blue-500/10 cursor-pointer">
                                    <span className="text-[10px] text-blue-400 mb-1">DAEMON_{i}</span>
                                    {slot ? <span className="text-xs">{slot.name}</span> : <span className="text-[10px] text-gray-600">NULL</span>}
                                </div>
                            ))}
                        </div>

                        {/* RELAY SLOT */}
                        <div className="w-16 h-16 border border-gray-600 rounded-full flex items-center justify-center opacity-50">
                            <span className="text-[10px] text-gray-500">RELAY</span>
                        </div>
                    </div>

                    {/* RIGHT: BACKPACK (GRID) */}
                    <div className="w-1/3 flex flex-col gap-2 pl-4 border-l border-gray-800">
                        <div className="flex justify-between items-end mb-2">
                            <h3 className="text-xs text-gray-500">STORAGE_PARTITION</h3>
                            <span className={`text-xs ${state.overhead > 10 ? 'text-magenta animate-pulse' : 'text-gray-400'}`}>
                                SYS_OVERHEAD: {state.overhead}%
                            </span>
                        </div>

                        <div className="grid grid-cols-3 gap-2 overflow-y-auto max-h-[400px] pr-2">
                            {state.backpack.map((item, i) => (
                                <div
                                    key={i}
                                    onClick={() => handleBackpackClick(item)}
                                    className={`aspect-square border p-1 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-150 relative
                                        ${selectedItem && selectedItem.id === item.id
                                            ? 'border-yellow-500 bg-yellow-500/20 shadow-[0_0_15px_#FFD700]'
                                            : 'border-gray-700 bg-gray-900/50 hover:border-white hover:bg-gray-800'}
                                    `}
                                    title={item.description}
                                >
                                    <div className="w-4 h-4 bg-gray-500 mb-1 rounded-sm"></div>
                                    <span className="text-[9px] break-words leading-tight">{item.name}</span>
                                </div>
                            ))}
                            {/* Empty Slots Filler */}
                            {Array(18 - state.backpack.length).fill(0).map((_, i) => (
                                <div key={`empty-${i}`} className="aspect-square border border-gray-800/30"></div>
                            ))}
                        </div>
                    </div>

                </div>
            </ChromaticContainer>
        </div>
    );
}
