# Remaining Mob System Implementation

Final phase of mob system overhaul including bestiary mechanics, combat systems, boss rendering, and Hunter stealth mechanics.

## User Review Required

> [!IMPORTANT]
> Hunter stealth mechanics fundamentally change its behavior - it will stay invisible until scanned or attacking.

## Proposed Changes

### Bestiary Respawn System

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

- Add `bestiaryDeadMobs` ref to track killed mobs with respawn timers
- In useFrame, check `floorLevel === 999` and decrement respawn timers
- Respawn mobs after 5 seconds at their original positions
- Override `addXP` calls in Bestiary: calculate XP needed for next level and grant that amount

---

### Sentry Hitbox Fix

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

**Current Issue**: Combat buffer only receives single position per mob

**Solution**: For sentries, write 3 positions to buffer (top, mid, bottom segment positions) with same mob index

- Expand sentry position writes in useFrame to include all 3 Y positions
- Collision detection will check against all 3 cylinder positions

---

### Sentry AI: Stationary Guard

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

- Add `isStationary` property to sentry mobs on spawn
- Skip position updates for stationary sentries (only rotate segments)
- Add telegraph/charge attack logic when player in range
- Expansion animation triggers during charge (already have expansion var)

---

### Boss Rendering Overhaul

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

**Replace BossFX Component**:
- Remove `BossFX` component usage
- Add boss-specific instanced meshes:
  - `bossCore` - sphere with `bossCoreTex`
  - `bossRing1` - torus with `bossRingsTex`, rotation on X axis
  - `bossRing2` - torus with `bossRingsTex`, rotation on Y axis
  - `bossRing3` - torus with `bossRingsTex`, rotation on Z axis

**Position Logic**:
- Only write boss core position to combat buffer
- Rings positioned at same XZ but rotate independently

**Scan Detection**:
- Add boss to scan radius check (currently missing)
- Set `scanTimer` on boss when player scans

---

### Hunter Stealth Mechanics

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

**New Behavior**:
- Hunter stays invisible by default (opacity = 0)
- Two ways to reveal:
  1. **Scan**: When scanned, force opacity = 1 for `scanTimer * 2` duration
  2. **Attack Telegraph**: Before attacking, hunter must telegraph (opacity fade to 1 over 1s)

**Implementation**:
- Add `isRevealed` and `attackTelegraph` state to hunter mobs
- In useFrame animation section, override opacity based on these states
- Modify attack logic to add telegraph phase before damage

**Attack Flow**:
1. Invisible hunter approaches player
2. At attack range, set `attackTelegraph = true`, fade to solid over 1s
3. Attack executes when fully solid
4. After attack, fade back to invisible over 0.5s

---

### Combat Buffer Updates

#### [MODIFY] [MobManager.jsx](file:///c:/Users/lynxg/Documents/Cyberynthe/src/components/3d/MobManager.jsx)

- Ensure boss core position is buffered
- Ensure all 3 sentry segment positions are buffered (or use radius check)
- Verify projectile collision logic handles these correctly

## Verification Plan

### Manual Testing
1. **Bestiary**: Floor 999, kill each mob, verify 5s respawn and level-up XP
2. **Sentry Hitbox**: Shoot all 3 segments, confirm hits register
3. **Sentry AI**: Verify they don't chase, only rotate and charge when player approaches
4. **Boss Rendering**: Check separate core/ring rendering with proper textures
5. **Boss Hitbox**: Verify projectiles only damage core, pass through rings
6. **Boss Scan**: Use scan near boss, verify detection
7. **Hunter Stealth**: 
   - Verify hunter stays invisible normally
   - Scan hunter, verify 2x duration visibility
   - Let hunter attack, verify telegraph reveal before damage
