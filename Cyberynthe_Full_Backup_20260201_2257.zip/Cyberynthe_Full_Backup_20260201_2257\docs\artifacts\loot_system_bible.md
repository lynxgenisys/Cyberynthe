# Cyberynthe Loot System Bible

> **Design Philosophy**: In the Gradient Morals universe, data isn't stored in crates—it's suspended in **L1_CACHE Nodes**. Looting becomes an act of *Interfacing*. You aren't a warrior picking up gold; you are a **Ghost extracting secrets from a dying machine**.

---

## Part I: The Data Node (Cache Geometry)

### Visual Design: Trinity Data Node

Replace the placeholder "yellow box" with a **Geometric Construct** mirroring brand symbols.

| Component | Geometry | Description |
|-----------|----------|-------------|
| **Core** | `OctahedronGeometry` | Two pyramids joined at base, floating |
| **Shell** | `SphereGeometry` (wireframe) | Semi-transparent, larger than core |
| **Center Bead** | Metallic sphere | Pulsing with light at the very center |

### Animation States

| State | Visual Behavior |
|-------|-----------------|
| **Locked** | Sphere rotates slowly. Octahedron is solid Cyan. |
| **Interact (Proximity)** | Wireframe sphere expands/contracts. HUD shows `[INITIALIZING_HANDSHAKE]` |
| **Opened (De-fragmented)** | Octahedron "shatters" into digital dust, leaving only the glowing item |

### Shader Specifications

- **Texture**: `cache_node_skin.webp`
- **Alpha Clipping**: Discard black pixels → flickering "holey" data effect
- **Glow**: `emissiveIntensity` linked to `sin(uTime)` pulse
- **Rotation**: Sphere and Octahedron rotate in **opposite directions**

---

## Part II: The Handshake (Extraction Animation)

The interaction must feel like a **hack**, not just a click.

### Phase 1: Proximity (3 units)
```
HUD Display: [E] INITIALIZE_HANDSHAKE
```

### Phase 2: Interaction (E pressed)
1. Octahedron spins at **5x speed** for 0.5s
2. Sound: "High-Speed Data Scrubbing"
3. Node **bursts** into Cyan/Magenta particle cloud

### Phase 3: Notification
```
HUD Display: [DE-FRAGMENTED]: {ITEM_NAME} ACQUIRED
```
- Font: Monospaced
- Duration: 2-3 seconds
- Color: Item-specific (see visual indicators below)

---

## Part III: Master Loot Table (v2.0)

### Drop Weights

| Category | Item Name | % Chance | Visual Color | Key Effect |
|----------|-----------|----------|--------------|------------|
| **Currency** | eBit Cluster | 50% | Gold/Yellow | Standard currency (10–50) |
| **Vitality** | M-RAM Injector | 15% | Cyan/Blue | Restores 40% Integrity & M-RAM |
| **Lore** | Logic Fragment | 8% | Magenta/Purple | Unlocks story entry + 100 eBits |
| **Buff** | Buffer Overclocker | 7% | White/Flicker | +25% Speed & Dodge for 2 floors |
| **Buff** | Clock-Cycle Boost | 5% | Blue Battery | -15% all cooldowns for 3 floors |
| **Utility** | Ghost Protocol (Cloak) | 5% | Wireframe Ghost | Invisible to mobs for 10s (single use) |
| **Utility** | System Ping | 4% | Purple Radar | Reveals entire map & exits (single use) |
| **Hardware** | Kernel Spike | 3% | Red Dagger | Instantly kills one non-boss mob |
| **Anomaly** | Sector Breach | 2% | Glitching Box | Teleport: Skip current floor immediately |
| **Anomaly** | Cyan/Magenta Core | 1% | Pulsing Orb | Stat Swap: Re-rolls current Resonance |

### Visual Indicators on Pickup

| Item | Pickup VFX |
|------|------------|
| eBit Cluster | Gold glitch particles |
| M-RAM Injector | Cyan pulse on HUD |
| Logic Fragment | Magenta terminal overlay |
| Buffer Overclocker | Screen-edge motion blur |
| Ghost Protocol | Wireframe ripple effect |
| System Ping | Radar sweep animation |
| Kernel Spike | Red slash effect |
| Sector Breach | Screen glitch/tear |
| Cyan/Magenta Core | Color shift wave |

---

## Part IV: The Corrupted Node (Risk vs. Reward)

### Spawn Rate
- **5% chance** to spawn instead of normal Data Node

### Appearance
- Flickers violently between Cyan and Magenta
- Static sparks around the geometry
- Red-tinted shader overlay

### Gamble Mechanics

| Outcome | Chance | Result |
|---------|--------|--------|
| **Success** | 80% | Drops **TWO** items from Rare/Ultra-Rare tier |
| **Failure** | 20% | Spawns "Zero-Day Stalker" elite mob **OR** deals 25% Integrity damage |

---

## Part V: Quick-Slot Inventory System

### UI Placement
- Two slots on HUD (Keys **1** and **2**)
- Located near the existing Trinity bars

### Stacking Rules
| Item Type | Stack Limit |
|-----------|-------------|
| M-RAM Injector | 3 |
| Ghost Protocol | 1 (full slot) |
| System Ping | 1 (full slot) |
| Kernel Spike | 1 (full slot) |
| Sector Breach | 1 (full slot) |
| Cyan/Magenta Core | 1 (full slot) |

### Activation
- Press **1** or **2** to use the item in that slot
- Display cooldown indicator if applicable

---

## Part VI: Buff Duration Tracking

### Floor-Based Buffs
| Buff | Duration | Tracking Method |
|------|----------|-----------------|
| Buffer Overclocker | 2 Floors | `floorCounter` decrements on portal entry |
| Clock-Cycle Boost | 3 Floors | `floorCounter` decrements on portal entry |

### Implementation Notes
- Store `activeBuffs[]` array in GameState
- Each buff object: `{ type, floorsRemaining, effect }`
- On `advanceFloor()`: Decrement all buff counters, remove expired

---

## Part VII: Data Persistence

### LocalStorage Keys
```javascript
{
  collected_fragments: [0, 1, 2],  // Fragment indices already collected
  active_buffs: [{ type: 'OVERCLOCKER', floorsRemaining: 1 }],
  inventory_slots: [
    { item: 'M-RAM_INJECTOR', count: 2 },
    { item: 'GHOST_PROTOCOL', count: 1 }
  ]
}
```

### Fragment Duplication Prevention
- Before dropping Logic Fragment, check `collected_fragments` array
- If all fragments collected, replace with 200 eBits instead

---

## Part VIII: Implementation Components

### New Files Required
1. `DataNode.jsx` - The cache geometry component
2. `LootTable.js` - Weighted random drop logic
3. `LoreManager.js` - Fragment registry and tracking
4. `QuickSlots.jsx` - Inventory UI component
5. `LoreOverlay.jsx` - Fragment reading UI

### Modified Files
1. `LootManager.jsx` - Replace yellow boxes with DataNodes
2. `GameContext.jsx` - Add buff tracking, inventory state
3. `HUD.jsx` - Add QuickSlot UI, lore overlay
4. `InventoryContext.jsx` - Extend for new item types

---

## Appendix: Visual Reference Colors

| Element | Hex Code | Usage |
|---------|----------|-------|
| Cyan (Primary) | `#00FFFF` | Health, positive effects |
| Magenta (Primary) | `#FF00FF` | Lore, story elements |
| Gold (Currency) | `#FFD700` | eBits, wealth |
| White (Buff) | `#FFFFFF` | Speed boosts |
| Blue (Cooldown) | `#0088FF` | Cooldown reduction |
| Red (Damage) | `#FF0000` | Weapons, danger |
| Purple (Utility) | `#8800FF` | Map reveals, scanning |
