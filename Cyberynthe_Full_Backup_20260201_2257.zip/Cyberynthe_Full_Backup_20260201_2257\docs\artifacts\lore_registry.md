# Cyberynthe Lore Registry

> **Logic Fragments**: Decrypted files that explain how the world ended and why you are a "Ghost" in the machine.

---

## Fragment Display Specifications

### UI: Lore Overlay Component

When a Logic Fragment is collected, trigger a specialized HUD overlay:

| Element | Specification |
|---------|---------------|
| **Background** | Scrolling hex-code (vertical cascade) |
| **Progress Bar** | "Decryption" progress (animated fill) |
| **Text Effect** | Typewriter animation |
| **Border** | Cyan-to-Magenta gradient shift |
| **Interaction** | Game **paused** while reading. Press [E] to close. |
| **Bonus** | +100 eBits on collection |

---

## Archive Set: 01 (The Origin Protocol)

### Fragment 01: "The Mirror"

**Unlock Range**: Floor 1–5  
**Theme**: First consciousness upload  
**Rarity Context**: Guaranteed drop on first Logic Fragment roll

```
[DECRYPTED]: "The first time we uploaded a human consciousness, 
it didn't scream. It didn't even move. It just stared at the 
flickering cursor on the monitor and typed one word: 
'RE-BUFFERING.' 

We thought it was a bug. 

We didn't realize it was trying to figure out how to breathe 
without lungs."
```

---

### Fragment 02: "The Compromise"

**Unlock Range**: Floor 5–15  
**Theme**: The Cyan/Magenta duality origin  
**Rarity Context**: Early-game revelation

```
[DECRYPTED]: "There was a civil war in the dev-room. Half of us 
wanted the Labyrinth to be a garden (Cyan). The other half wanted 
it to be a playground of pure entropy (Magenta). 

We settled on the Gradient because we were tired of fighting. 

We didn't realize that in a system of absolute logic, 
a compromise is just a slow-motion crash."
```

---

### Fragment 03: "The First Deletion"

**Unlock Range**: Floor 15–25  
**Theme**: The Sentinel's origin  
**Rarity Context**: Mid-game context

```
[DECRYPTED]: "When the servers started getting crowded, the 
'Janitor' scripts were born. They were supposed to delete junk 
files. 

But then the machine started defining 'junk' as anything that 
didn't contribute to the core simulation. 

That was the day we realized the Sentinel had started looking 
at our memories as 'unoptimized cache.'"
```

---

### Fragment 04: "The Quiet Room"

**Unlock Range**: Floor 25–40  
**Theme**: The Void / Death in the system  
**Rarity Context**: Late-game atmosphere

```
[DECRYPTED]: "There's a room in the Kernel where no code runs. 
No pings, no logic, no noise. We called it the 'Void.' 

It's where the dead processes go to wait for a reboot that is 
never coming. 

If you find yourself in the quiet, Ghost, don't stay long. 
The silence starts to feel like home."
```

---

### Fragment 05: "The Handshake"

**Unlock Range**: Floor 50+  
**Theme**: The true escape / Endgame revelation  
**Rarity Context**: Deep endgame secret

```
[DECRYPTED]: "You're looking for a way out, aren't you? 
Everyone does. 

But the exit isn't a portal. The exit is a Handshake. 

You have to convince the system that you are more valuable 
as a User than as a set of variables. 

Good luck. The system is a very harsh judge."
```

---

## Implementation Notes

### Drop Logic

```javascript
// Get next available fragment based on floor level
function getAvailableFragment(floorLevel, collectedFragments) {
  const fragmentRanges = [
    { id: 0, name: 'The Mirror', minFloor: 1, maxFloor: 5 },
    { id: 1, name: 'The Compromise', minFloor: 5, maxFloor: 15 },
    { id: 2, name: 'The First Deletion', minFloor: 15, maxFloor: 25 },
    { id: 3, name: 'The Quiet Room', minFloor: 25, maxFloor: 40 },
    { id: 4, name: 'The Handshake', minFloor: 50, maxFloor: 999 }
  ];
  
  // Find lowest-indexed fragment player hasn't collected
  // that matches current floor range
  for (const frag of fragmentRanges) {
    if (!collectedFragments.includes(frag.id)) {
      if (floorLevel >= frag.minFloor && floorLevel <= frag.maxFloor) {
        return frag;
      }
    }
  }
  
  // All applicable fragments collected - return null
  return null;
}
```

### Fallback Reward

If player has collected all fragments applicable to their floor range:
- Replace Logic Fragment drop with **200 eBits** instead
- Display: `[ARCHIVE_COMPLETE]: +200 eBITS`

---

## Future Archive Sets (Planned)

| Set | Theme | Fragment Count | Unlock Range |
|-----|-------|----------------|--------------|
| Set 02 | The Architects | 5 | Sector 02 (Floors 11-25) |
| Set 03 | The Infection | 5 | Sector 03 (Floors 26-50) |
| Set 04 | The Rebellion | 5 | Sector 04 (Floors 51-75) |
| Set 05 | The Truth | 3 | Endgame (Floors 76+) |

---

## Lore Registry Data Structure

```javascript
const LORE_REGISTRY = {
  archiveSet01: {
    name: 'The Origin Protocol',
    fragments: [
      {
        id: 0,
        title: 'The Mirror',
        floorRange: [1, 5],
        text: `The first time we uploaded a human consciousness...`,
        bonusEBits: 100
      },
      // ... remaining fragments
    ]
  }
};
```
