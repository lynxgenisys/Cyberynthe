import React, { useEffect, useState } from 'react';
import { useGame } from '../../context/GameContext';
import { usePlayer } from '../../context/PlayerContext';

// COMPASS COMPONENT (Fixed)
const CompassStrip = () => {
    const { playerRotationRef } = useGame();
    const stripRef = React.useRef();

    React.useEffect(() => {
        let frameId;
        const update = () => {
            if (playerRotationRef && stripRef.current) {
                const rot = playerRotationRef.current;

                // 1. Convert Radians to Degrees
                let deg = (rot * 180) / Math.PI;

                // 2. Infinite Scroll Math
                // We shift the strip by 2 pixels per degree.
                // We modulo by 720 (360 degrees * 2) so the offset loops.
                // We add 72000 before modulo to handle negative rotations cleanly.
                const pxPerDeg = 2;
                const totalWidth = 720;

                // Ensure positive modulo for clean looping
                const offset = ((deg * pxPerDeg) % totalWidth + totalWidth) % totalWidth;

                // 3. Apply Transform
                // Moving Left (+Deg) slides the strip Right (+Offset)
                stripRef.current.style.transform = `translateX(${offset}px)`;
            }
            frameId = requestAnimationFrame(update);
        };
        update();
        return () => cancelAnimationFrame(frameId);
    }, [playerRotationRef]);

    return (
        <div className="relative w-[600px] h-8 overflow-hidden border-x-2 border-cyan-500/50 bg-black/80 backdrop-blur mx-auto mt-2 rounded-lg mask-gradient-x flex items-center shadow-lg shadow-cyan-500/10">
            {/* CENTER MARKER */}
            <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-magenta z-10 shadow-[0_0_10px_#EA00FF]"></div>

            {/* SCROLLING STRIP */}
            <div ref={stripRef} className="absolute top-0 bottom-0 left-1/2 flex items-center justify-center will-change-transform">
                {/* 3 Strips: [-1 (Left), 0 (Center), 1 (Right)] */}
                {/* Visual Range: -720px to +1440px coverage */}
                {[-1, 0, 1].map(offset => (
                    <div key={offset} className="absolute h-full w-[720px]" style={{ left: `${offset * -720}px` }}>
                        {/* CARDINALS */}
                        {['N', 'W', 'S', 'E'].map((dir, i) => (
                            <div key={dir} className="absolute top-1 w-12 -ml-6 text-center text-cyan-400 font-bold text-sm drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]" style={{ left: `${i * 180}px` }}>
                                {dir}
                            </div>
                        ))}
                        {/* TICKS (Every 15 deg = 30px) */}
                        {Array.from({ length: 24 }).map((_, i) => (
                            <div key={i} className={`absolute bottom-0 w-0.5 bg-cyan-700 ${i % 3 === 0 ? 'h-3 bg-cyan-500' : 'h-1.5'}`} style={{ left: `${i * 30}px` }} />
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default function HUD() {
    const { gameState } = useGame();
    const { state: playerState } = usePlayer();

    // Derived Stats
    const hp = playerState.stats.currentIntegrity;
    const maxHp = playerState.stats.integrity;
    const ram = playerState.stats.mRamCurrent;
    const maxRam = playerState.stats.mRamMax;

    // Notifications (Last 5)
    const logs = [...gameState.notifications].reverse();

    // LEVEL UP DETECTION
    const { getLevelFromXP } = useGame();
    const currentLevel = getLevelFromXP(gameState.xp || 0);
    const [levelUpActive, setLevelUpActive] = useState(false);
    const prevLevelRef = React.useRef(currentLevel);

    useEffect(() => {
        if (currentLevel > prevLevelRef.current) {
            // Level Increased
            setLevelUpActive(true);
            setTimeout(() => setLevelUpActive(false), 5000); // Hide after 5s
            prevLevelRef.current = currentLevel;
        }
    }, [currentLevel]);

    return (
        <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">

            {/* TOP BAR CONTAINER (Absolute Layout) */}
            <div className="relative w-full h-24 flex justify-center pointer-events-auto">
                {/* COMPASS */}
                <div className="absolute top-6 z-20">
                    <CompassStrip />
                </div>

                {/* BOSS HEALTH BAR (Relocated Center) */}
                {gameState.bossEncounter?.active && (
                    <div className="absolute top-16 z-20 w-[500px] animate-fade-in-down flex flex-col items-center">
                        <div className="flex justify-between w-full text-cyan font-bold text-xs mb-1 tracking-widest drop-shadow-[0_0_5px_#00FFFF]">
                            <span>{gameState.bossEncounter.name}</span>
                            <span>{(gameState.bossEncounter.hp / gameState.bossEncounter.maxHp * 100).toFixed(0)}%</span>
                        </div>
                        <div className="h-2 w-full bg-black/80 border border-cyan/50 skew-x-[-10deg] p-[1px]">
                            <div
                                className="h-full bg-cyan transition-all duration-200 ease-out shadow-[0_0_15px_#00FFFF]"
                                style={{ width: `${Math.max(0, (gameState.bossEncounter.hp / gameState.bossEncounter.maxHp) * 100)}%` }}
                            />
                        </div>
                    </div>
                )}

                {/* BOSS SUBTITLES */}
                {gameState.bossSubtitle && (Date.now() - gameState.bossSubtitle.timestamp < gameState.bossSubtitle.duration) && (
                    <div className="absolute top-32 left-1/2 -translate-x-1/2 z-50 w-full max-w-4xl text-center pointer-events-none">
                        <div className="inline-block bg-black/90 px-6 py-2 border-y border-cyan/50 backdrop-blur-md shadow-[0_0_15px_rgba(0,255,255,0.3)]">
                            <div className="text-cyan-400 font-mono text-sm tracking-[0.15em] animate-pulse font-bold uppercase drop-shadow-md">
                                {gameState.bossSubtitle.text}
                            </div>
                        </div>
                    </div>
                )}

                {/* 0. GLOBAL WIRE LAYER (Background) */}
                <div className="absolute inset-0 z-0 opacity-80">
                    <svg width="100%" height="100%" viewBox="0 0 1000 80" preserveAspectRatio="none">
                        {/* Top/Bottom Frames */}
                        <line x1="0" y1="0.5" x2="1000" y2="0.5" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />
                        <line x1="0" y1="80" x2="1000" y2="80" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />

                        {/* CENTER BUS LINES */}
                        <path d="M0,20 L380,20 Q500,0 620,20 L1000,20" fill="none" stroke="#00FFFF" strokeWidth="2" strokeOpacity="0.6" strokeDasharray="10 5" className="animate-shimmer" />
                        <path d="M0,40 L400,40 Q500,25 600,40 L1000,40" fill="none" stroke="#00FF00" strokeWidth="1" strokeOpacity="0.4" />
                        <path d="M0,60 L380,60 Q500,80 620,60 L1000,60" fill="none" stroke="#0088FF" strokeWidth="2" strokeOpacity="0.6" strokeDasharray="5 5" className="animate-pulse" />
                    </svg>
                </div>

                {/* 1. LEFT MODULE: Header + Bars (Absolute Left) */}
                <div className="absolute left-0 top-0 h-full flex items-stretch z-10">
                    {/* Header Box */}
                    <div className="bg-black/80 p-4 border border-cyan/30 border-r-0 backdrop-blur-sm rounded-l-2xl flex flex-col justify-center min-h-[80px]">
                        <h1 className="text-xl font-bold text-cyan-glow tracking-widest animate-pulse leading-none mb-1">CYBERYNTHE</h1>
                        <span className="text-xs text-cyan font-mono tracking-wider">PROTOCOL_V4</span>
                    </div>

                    {/* WIRE BUNDLE CONNECTOR (LEFT) */}
                    <div className="w-12 relative -ml-[1px] -mr-[1px] z-10 flex flex-col justify-center bg-black/40 backdrop-blur-sm">
                        <svg width="100%" height="100%" viewBox="0 0 48 80" preserveAspectRatio="none">
                            <path d="M0,0 L48,0 L48,80 L0,80 Z" fill="rgba(0,0,0,0.5)" />
                            {/* Traces */}
                            <path d="M0,20 L48,20" stroke="#00FF00" strokeWidth="2" strokeOpacity="0.5" strokeDasharray="4 2" className="animate-shimmer" />
                            <circle cx="24" cy="20" r="2" fill="#00FF00" className="animate-ping opacity-75" style={{ animationDuration: '2s' }} />
                            <path d="M0,40 L48,40" stroke="#00FFFF" strokeWidth="2" strokeOpacity="0.8" />
                            <circle cx="24" cy="40" r="3" fill="#00FFFF" className="animate-pulse" />
                            <path d="M0,60 L48,60" stroke="#0088FF" strokeWidth="2" strokeOpacity="0.5" strokeDasharray="2 4" className="animate-pulse" />
                            <circle cx="24" cy="60" r="2" fill="#0088FF" className="animate-ping opacity-75" style={{ animationDuration: '1.5s' }} />
                            <path d="M0,0 L48,0" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />
                            <path d="M0,80 L48,80" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />
                        </svg>
                    </div>

                    {/* BARS BOX (Separated Background) */}
                    <div className="relative flex flex-col justify-center gap-2 p-2 min-h-[80px]">
                        {/* Background Layer with Gradient Mask */}
                        <div
                            className="absolute inset-0 bg-black/80 border border-cyan/30 border-l-0 border-r-0 backdrop-blur-sm -z-10"
                            style={{
                                maskImage: 'linear-gradient(to right, black 50%, transparent 100%)',
                                WebkitMaskImage: 'linear-gradient(to right, black 50%, transparent 100%)'
                            }}
                        />

                        {/* Content Layer (Opaque) */}
                        <div className="w-80">
                            <div className="flex justify-between text-xs text-cyan mb-1 font-bold">
                                <span>INTEGRITY</span>
                                <span>{Math.floor(hp)} / {maxHp}</span>
                            </div>
                            <div className="h-2 w-full bg-gray-900 border border-cyan/20">
                                <div className="h-full bg-cyan transition-all duration-300 ease-out shadow-[0_0_10px_#00FFFF]" style={{ width: `${(hp / maxHp) * 100}%` }} />
                            </div>
                        </div>
                        <div className="w-80">
                            <div className="flex justify-between text-xs text-magenta mb-1 font-bold">
                                <span>M-RAM_BUFFER</span>
                                <span>{Math.floor(ram)} / {maxRam}</span>
                            </div>
                            <div className="h-2 w-full bg-gray-900 border border-magenta/20">
                                <div className="h-full bg-magenta transition-all duration-100 ease-linear shadow-[0_0_10px_#EA00FF]" style={{ width: `${(ram / maxRam) * 100}%` }} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* 2. CENTER MODULE: Floor Info ( MOVED TO LEFT ) */}
                <div className="absolute left-4 top-24 z-20 flex flex-col items-start">
                    <h1 className="text-xl font-bold text-white tracking-[0.2em] drop-shadow-[0_0_5px_rgba(255,255,255,0.8)] bg-black/60 px-4 py-1 rounded-full border-x border-cyan/20 backdrop-blur-md">
                        FLOOR {gameState.floorLevel.toString().padStart(3, '0')}
                    </h1>
                    <div className="flex gap-2 text-[10px] text-gray-400 mt-1 font-mono tracking-widest bg-black/80 px-2 py-0.5 rounded border border-gray-800/50 backdrop-blur-sm ml-1">
                        <span>SECTOR {gameState.sectorId}</span>
                        <span className="text-magenta">//</span>
                        <span>SEED: {gameState.seed}</span>
                    </div>

                    {/* BOSS HEALTH BAR MOVED TO TOP CENTER */}
                </div>

                {/* 3. RIGHT MODULE: XP & eBits (Absolute Right) */}
                <div className="absolute right-0 top-0 h-full flex items-stretch z-10">

                    {/* XP BOX (Extended Width + Separated Background) */}
                    <div className="relative flex flex-col justify-center min-h-[80px] w-64"> {/* Explicit wider width w-64 */}
                        {/* Background Layer with Gradient Mask */}
                        <div
                            className="absolute inset-0 bg-black/80 border border-blue-500/30 border-r-0 border-l-0 backdrop-blur-sm -z-10"
                            style={{
                                maskImage: 'linear-gradient(to left, black 50%, transparent 100%)',
                                WebkitMaskImage: 'linear-gradient(to left, black 50%, transparent 100%)'
                            }}
                        />

                        {/* Content (Aligned Right) */}
                        <div className="text-right pr-4">
                            <div className="text-[10px] text-blue-500/80">ACCESS_LEVEL</div>
                            <span className="text-xl text-blue-500 font-mono font-bold">{gameState.xp || 0} XP</span>
                        </div>
                    </div>

                    {/* WIRE BUNDLE CONNECTOR (RIGHT) */}
                    <div className="w-12 relative -ml-[1px] -mr-[1px] z-10 bg-black/40 backdrop-blur-sm">
                        <svg width="100%" height="100%" viewBox="0 0 48 80" preserveAspectRatio="none">
                            <path d="M0,0 L48,0 L48,80 L0,80 Z" fill="rgba(0,0,0,0.5)" />
                            {/* Traces */}
                            <path d="M0,20 L48,20" stroke="#0088FF" strokeWidth="2" strokeOpacity="0.5" strokeDasharray="4 2" className="animate-pulse" />
                            <circle cx="24" cy="20" r="2" fill="#0088FF" className="animate-ping opacity-75" style={{ animationDuration: '1.8s' }} />
                            <path d="M0,40 L48,40" stroke="#00FFFF" strokeWidth="2" strokeOpacity="0.8" />
                            <circle cx="24" cy="40" r="3" fill="#00FFFF" className="animate-pulse" />
                            <path d="M0,60 L48,60" stroke="#00FF00" strokeWidth="2" strokeOpacity="0.5" strokeDasharray="2 4" className="animate-shimmer" />
                            <circle cx="24" cy="60" r="2" fill="#00FF00" className="animate-ping opacity-75" style={{ animationDuration: '2.2s' }} />
                            <path d="M0,0 L48,0" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />
                            <path d="M0,80 L48,80" stroke="#00FFFF" strokeOpacity="0.3" strokeWidth="1" />
                        </svg>
                    </div>

                    {/* DEBUG: VISUAL SCAN INDICATOR */}
                    {gameState.lastScanTime && (Date.now() - gameState.lastScanTime < 1000) && (
                        <div className="absolute top-20 right-10 text-green-500 font-bold bg-black px-2 border border-green-500 z-50">
                            SCAN TRIGGERED!
                        </div>
                    )}

                    {/* EBITS BOX */}
                    <div className="bg-black/80 p-4 border border-yellow-500/30 border-l-0 backdrop-blur-sm rounded-r-2xl flex items-center gap-3 min-h-[80px]">
                        <div className="text-right">
                            <div className="text-[10px] text-yellow-500/80">AVAIALBLE_CREDITS</div>
                            <span className="text-2xl text-yellow-500 font-mono font-bold">{gameState.eBits}</span>
                        </div>
                        <div className="w-1 h-8 bg-yellow-500/20"></div>
                        <span className="text-xs text-yellow-500">eBITS</span>
                    </div>
                </div>

            </div>

            {/* BOTTOM BAR GRID */}
            <div className="flex justify-between items-end w-full">
                {/* LEFT: NOTIFICATION LOG */}
                <div className="w-96 flex flex-col-reverse gap-1 items-start justify-end pointer-events-none mask-image-linear-gradient">
                    {logs.map((log, i) => {
                        // 1. Determine Base Color (Border & Main Text)
                        let baseColor = "text-cyan-glow border-cyan";
                        if (/THREAT|NEUTRALIZED|KILL|HOSTILE/.test(log.msg)) baseColor = "text-red-500 border-red-500";
                        else if (/ITEM|STORED|INVENTORY|CACHE/.test(log.msg)) baseColor = "text-green-500 border-green-500";

                        // 2. Parser for highlights
                        const renderMessage = (text) => {
                            const parts = text.split(/(\+\d+\s*(?:XP|eBITS))/g);
                            return parts.map((part, index) => {
                                if (/XP/.test(part)) return <span key={index} className="text-blue-500 font-bold">{part}</span>;
                                if (/eBITS/.test(part)) return <span key={index} className="text-yellow-500 font-bold">{part}</span>;
                                return <span key={index}>{part}</span>;
                            });
                        };

                        return (
                            <div key={`${log.id}-${i}`} className={`text-xs font-mono px-2 py-1 bg-black/60 border-l-2 ${baseColor} animate-fade-in-up`}>
                                <span className="text-gray-500 mr-2">[{new Date(log.time).toLocaleTimeString([], { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" })}]</span>
                                {renderMessage(log.msg)}
                            </div>
                        );
                    })}
                    <div className="text-[10px] text-gray-500 mt-2 font-mono">[E] SCAN | [1] ADVANCE_TEST | [I] DECK | [M] MAP</div>
                </div>

                {/* RIGHT: RESONANCE MAP */}
                <div className="flex flex-col items-end relative">
                    {/* SONAR PING OVERLAY */}
                    {gameState.lastScanTime && (Date.now() - gameState.lastScanTime < 2000) && (
                        <div className="absolute inset-0 -top-12 -left-12 w-48 h-48 border-2 border-green-500 rounded-full animate-ping opacity-50 pointer-events-none"
                            key={gameState.lastScanTime} // Forces re-render on new scan
                        />
                    )}

                    <div className="w-24 h-24 border border-gray-800 bg-black/80 relative clip-triangle transition-all hover:bg-black/90 overflow-hidden">
                        {/* MAP CONTENT */}
                        <svg viewBox="0 0 100 100" className="w-full h-full opacity-80">
                            <polygon points="50,10 90,90 10,90" fill="none" stroke="#333" strokeWidth="1" />
                            <text x="50" y="30" fontSize="8" fill="white" textAnchor="middle">VOID</text>

                            {/* ACTIVE SCAN RIPPLE ON MAP */}
                            {gameState.lastScanTime && (Date.now() - gameState.lastScanTime < 2000) && (
                                <circle cx="50" cy="80" r="40" stroke="#00FF00" strokeWidth="2" fill="none" className="animate-ping" style={{ transformOrigin: '50% 80%' }} />
                            )}

                            <text x="20" y="85" fontSize="8" fill="#00FFFF" textAnchor="middle">CYAN</text>
                            <text x="80" y="85" fontSize="8" fill="#EA00FF" textAnchor="middle">MAGENTA</text>
                            <circle cx={15 + (70 * (gameState.ethicsScore || 0.5))} cy="80" r="3" fill="white" />
                        </svg>
                    </div>
                    <div className="text-right text-[9px] text-gray-500 mt-1">RESONANCE_ALIGNMENT</div>
                </div>

                {/* CENTER: SCANNING UI */}
                {gameState.scanningState?.active && (
                    <div className="absolute left-1/2 top-2/3 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-2 pointer-events-none z-50">
                        <div className="text-sm font-bold text-yellow-500 font-mono tracking-[0.2em] animate-pulse drop-shadow-[0_0_10px_#FFD700]">
                            SCANNING_DATA...
                        </div>
                        <div className="w-64 h-2 bg-black/80 border border-yellow-500/50 backdrop-blur-sm relative overflow-hidden rounded-full">
                            <div
                                className="h-full bg-yellow-500 relative transition-all duration-75 ease-linear shadow-[0_0_15px_#FFD700]"
                                style={{ width: `${(gameState.scanningState.progress || 0) * 100}%` }}
                            />
                        </div>
                        <div className="text-xs text-yellow-500/80 font-mono">
                            {((gameState.scanningState.progress || 0) * 100).toFixed(0)}% DECRYPTED
                        </div>
                    </div>
                )}
            </div>

            {/* LEVEL UP OVERLAY */}
            {
                levelUpActive && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[60]">
                        <div className="bg-black/90 border-y-4 border-yellow-500 p-8 flex flex-col items-center animate-bounce-in">
                            <h1 className="text-6xl font-bold text-yellow-500 tracking-tighter drop-shadow-[0_0_20px_#FFD700]">LEVEL UP</h1>
                            <div className="text-2xl text-white font-mono mt-2 tracking-[0.5em]">SYSTEM_UPGRADE_COMPLETE</div>
                            <div className="mt-4 text-sm text-yellow-500/80 blink">PRESS [I] TO ALLOCATE KERNEL POINTS</div>
                        </div>
                    </div>
                )
            }

            {/* ASCENSION OVERLAY REMOVED - ENDLESS MODE */}
        </div >
    );
}
