import React, { createContext, useContext, useState, useEffect } from 'react';

/**
 * IDENTITY: LOGIC_BREACH_02 (The Engineer)
 * DIRECTIVE: Implement Meta-Game State (Seeds & Levels)
 * CONSTRAINTS:
 * - Seed: Derived from Date().toDateString() (Daily Run)
 * - Sector Logic: Level / 25
 */

const GameContext = createContext();

export const GameProvider = ({ children }) => {
    const playerRotationRef = React.useRef(0); // Zero-cost sync for Compass
    const [gameState, setGameState] = useState({
        seed: '',
        floorLevel: 1,
        sectorId: 1,
        playerName: 'GHOST_USER',
        isPaused: false,
        isElite: false, // Permadeath Mode
        activePenalties: [],

        playerGridPos: { x: 1, y: 1 }, // Track player for Map
        spawnPoint: null, // Dynamic Spawn Point (Grid Coords)
        ethicsScore: 0.5, // 0.0 (Cyan) to 1.0 (Magenta)
        eBits: 0, // Currency
        isTransitioning: false, // Floor Loading State
        lootedCaches: [], // Array of IDs "x,y"
        notifications: [], // Array of {id, msg, time}
        xp: 0, // Experience Points
        scanningState: { active: false, progress: 0 }, // For HUD UI
        scannedTargets: [], // Array of {x, z, type}
        scannerLevel: 1, // 1: Short, 2: Med, 3: Long

        isPortalLocked: false, // Gatekeeper Logic
        mazeGrid: null, // For Projectile Collision
        bossEncounter: { active: false, name: '', hp: 0, maxHp: 0 },
        bossSubtitle: { text: '', duration: 0, timestamp: 0 }
    });

    const setBossSubtitle = (text, duration = 3000) => {
        setGameState(prev => ({
            ...prev,
            bossSubtitle: { text, duration, timestamp: Date.now() }
        }));
    };

    const addNotification = (msg) => {
        const id = Date.now();
        setGameState(prev => ({
            ...prev,
            notifications: [...prev.notifications, { id, msg, time: Date.now() }].slice(-5) // Keep last 5
        }));
    };

    const updateScannedTargets = (targets) => {
        setGameState(prev => ({ ...prev, scannedTargets: targets }));
    };

    const updateBossStatus = (status) => {
        setGameState(prev => ({
            ...prev,
            bossEncounter: { ...prev.bossEncounter, ...status }
        }));
    };

    const markCacheLooted = (x, y) => {
        const id = `${x},${y}`;
        setGameState(prev => ({
            ...prev,
            lootedCaches: [...prev.lootedCaches, id]
        }));
    };

    // PERSISTENCE PROTOCOL
    const checkPersistence = (currentIntegrity) => {
        if (currentIntegrity <= 0) {
            if (gameState.isElite) {
                console.warn("[SYSTEM]: ELITE_MODE_DEATH // WIPING_SESSION");
                // Reset to Floor 1, Seed Reset
                setGameState(prev => ({
                    ...prev,
                    floorLevel: 1,
                    sectorId: 1,
                    seed: btoa(Date.now().toString()).substring(0, 16)
                }));
                return 'WIPED';
            } else {
                console.log("[SYSTEM]: STANDARD_DEATH // RESPAWNING");
                // In standard, we would decrease loot, etc.
                return 'RESPAWNED';
            }
        }
    };

    // Initialize Session Seed
    useEffect(() => {
        const timestamp = Date.now().toString();
        // Uses current milliseconds for a truly unique session seed
        const seedHash = btoa(timestamp + "_CYBERYNTHE_SESSION").substring(0, 16);

        setGameState(prev => ({
            ...prev,
            seed: seedHash
        }));

        console.log(`[SYSTEM]: DAILY_SEED_INITIATED: ${seedHash}`);

        // INITIAL LORE TRIGGER (Floor 1)
        setBossSubtitle("Welcome, User. You have been disconnected for 1,402 days. Please stand by for de-fragmentation.", 6000);
    }, []);

    const advanceFloor = () => {
        // 1. SIGNAL TRANSITION START (Unmounts Maze)
        setGameState(prev => ({ ...prev, isTransitioning: true }));

        // 2. DELAY & UPDATE FLOOR
        setTimeout(() => {
            setGameState(prev => {
                const nextFloor = prev.floorLevel + 1;

                // ASCENSION CHECK REMOVED -> ENDLESS MODE
                if (nextFloor === 100) {
                    console.log("[SYSTEM]: CLASS_CHOICE_MILESTONE_REACHED");
                    // TODO: Trigger Class Selection UI
                }

                const nextSector = Math.ceil(nextFloor / 25);

                // LORE FLAVOR TEXT (GHOST PROTOCOL)
                // We set this here so it appears exactly when the floor loads
                let subtitle = null;
                let subDuration = 0;

                if (nextFloor === 1) { // Likely won't hit this via advance, but for restart usage
                    subtitle = "Welcome, User. You have been disconnected for 1,402 days. Please stand by for de-fragmentation.";
                    subDuration = 5000;
                } else if (nextFloor === 3) {
                    subtitle = "We didn't build the Labyrinth to keep things in. We built it to keep the static out. If you're reading this, the static won. Run.";
                    subDuration = 6000;
                } else if (nextFloor === 5) {
                    subtitle = "Why do I feel lighter? Every floor I descend, I lose a bit of my metadata. Eventually, there will be nothing left but the gradient.";
                    subDuration = 6000;
                }

                return {
                    ...prev,
                    floorLevel: nextFloor,
                    sectorId: nextSector,
                    spawnPoint: null,
                    scanningState: { active: false, progress: 0 }, // FORCE RESET UI
                    isPortalLocked: false, // Reset Lock
                    isTransitioning: true,
                    // Apply Subtitle directly to state here to avoid race conditions
                    bossSubtitle: subtitle ? { text: subtitle, duration: subDuration, timestamp: Date.now() + 600 } : prev.bossSubtitle
                    // Add 600ms delay to timestamp so it starts AFTER transition finishes (approx)
                };
            });

            // 3. FINISH TRANSITION (Remounts Maze)
            // Giving Rapier 500ms to fully flush physics world
            setTimeout(() => {
                setGameState(prev => ({ ...prev, isTransitioning: false }));
                console.log("[SYSTEM]: TRANSITION_COMPLETE // SIMULATION_RESUMED");
            }, 500);

        }, 100);
    };

    const updatePlayerPos = (x, y) => {
        // Only update if changed to avoid render thrashing
        if (x !== gameState.playerGridPos.x || y !== gameState.playerGridPos.y) {
            setGameState(prev => ({ ...prev, playerGridPos: { x, y } }));
        }
    };

    const updateScanningState = (active, progress) => {
        setGameState(prev => ({ ...prev, scanningState: { active, progress } }));
    };

    const triggerScan = () => {
        setGameState(prev => ({ ...prev, lastScanTime: Date.now() }));
    };

    // --- LEVELING LOGIC ---
    const XP_THRESHOLDS = [0, 188, 470, 1175, 2938, 7344];

    const getLevelFromXP = (xp) => {
        // Find highest threshold less than current XP
        let level = 1;
        for (let i = 1; i < XP_THRESHOLDS.length; i++) {
            if (xp >= XP_THRESHOLDS[i]) {
                level = i + 1;
            } else {
                break;
            }
        }
        return level;
    };

    const getNextLevelXP = (level) => {
        if (level >= XP_THRESHOLDS.length) return Math.floor(XP_THRESHOLDS[XP_THRESHOLDS.length - 1] * 2.5); // Fallback scaling
        return XP_THRESHOLDS[level]; // Threshold to Reach Next Level (e.g. Lvl 1 -> Index 1 (188))
    };

    return (
        <GameContext.Provider value={{
            gameState,
            advanceFloor,
            updatePlayerPos,
            setGameState,
            checkPersistence,
            addNotification,
            markCacheLooted,
            updateScanningState,
            triggerScan,
            updateScannedTargets,
            updateBossStatus,
            setBossSubtitle,
            getLevelFromXP,
            getNextLevelXP,
            playerRotationRef // EXPOSED REF
        }}> {/* Exposing setGameState for Pause */}
            {children}
        </GameContext.Provider>
    );
};

export const useGame = () => useContext(GameContext);
