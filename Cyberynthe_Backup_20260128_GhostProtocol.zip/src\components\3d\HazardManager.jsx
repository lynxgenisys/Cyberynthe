import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { InstancedRigidBodies, RigidBody } from '@react-three/rapier';
import * as THREE from 'three';

/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Environmental Hazards (Sector 3+)
 */

export default function HazardManager({ maze, floorLevel }) {
    // SECTOR 3: BUS_HIGHWAY (Floors 51-75)
    // Hazard: High Speed Data Packets (Moving Walls/Obstacles)

    const isSector3 = floorLevel >= 51 && floorLevel <= 75;

    // Generate Traffic Instances
    const trafficCount = isSector3 ? 10 : 0; // 10 roving packets
    const trafficRef = useRef([]);

    const instances = useMemo(() => {
        if (!isSector3) return [];

        const data = [];
        // Find long corridors or just random open spots?
        // Random open spots for now.
        const openCells = [];
        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell !== 0) openCells.push({ x, z });
            });
        });

        for (let i = 0; i < trafficCount; i++) {
            if (openCells.length === 0) break;
            const idx = Math.floor(Math.random() * openCells.length);
            const pos = openCells[idx];
            data.push({
                key: `traffic-${i}`,
                position: [pos.x * 2, 1, pos.z * 2],
                rotation: [0, 0, 0],
                scale: [1, 1, 1]
            });
            // Store simple state for animation outside of React state
            trafficRef.current[i] = {
                dir: Math.random() > 0.5 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 0, 1),
                speed: 5 + Math.random() * 5
            };
        }
        return data;
    }, [maze, isSector3]);

    const api = useRef();

    useFrame((state, delta) => {
        if (!isSector3 || !api.current) return;

        // Kinematic movement would be best, but InstancedRigidBodies control is tricky for individual kinematics without detailed API usage.
        // For "TRAFFIC", we want them to zoom nicely.
        // LIMITATION: @react-three/rapier InstancedRigidBodies logic usually assumes similar physics.
        // If we want complex pathfinding, individual RigidBodies might be better than Instanced for just 10 items.
        // Let's stick to Instanced for performance but just apply forces?
        // Actually, for 10 items, individual components are cleaner for logic.
        // REFACTOR ON THE FLY: Return individual DataPacket components if count is low.
    });

    if (!isSector3) return null;

    // Render Individual Kinematic Bodies for control
    return (
        <group>
            {instances.map((data, i) => (
                <DataPacket
                    key={data.key}
                    initPos={data.position}
                    dir={trafficRef.current[i].dir}
                    speed={trafficRef.current[i].speed}
                />
            ))}
        </group>
    );
}

const DataPacket = ({ initPos, dir, speed }) => {
    const body = useRef();
    const time = useRef(0);

    useFrame((state, delta) => {
        if (!body.current) return;
        time.current += delta;

        // Ping Pong movement (Sine wave logic for simplicity in corridors)
        // A real highway needs pathfinding, but "Roving Glitch" is enough.
        const offset = Math.sin(time.current * 0.5 * speed) * 4; // Move +/- 4 meters

        // We need next position
        const nextPos = {
            x: initPos[0] + dir.x * offset,
            y: initPos[1],
            z: initPos[2] + dir.z * offset
        };

        body.current.setNextKinematicTranslation(nextPos);
    });

    return (
        <RigidBody ref={body} type="kinematicPosition">
            <mesh castShadow>
                <boxGeometry args={[1, 1, 1]} />
                <meshStandardMaterial
                    color="#FFaa00"
                    emissive="#FF4400"
                    emissiveIntensity={2}
                    roughness={0}
                />
            </mesh>
        </RigidBody>
    );
};

