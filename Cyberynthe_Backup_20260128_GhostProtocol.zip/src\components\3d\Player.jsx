import React, { useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, CapsuleCollider, useRapier } from '@react-three/rapier';
import { KeyboardControls, PointerLockControls, useKeyboardControls } from '@react-three/drei';
import { useGame } from '../../context/GameContext'; // Import Logic Breach Link
import { useCombat } from '../../context/CombatContext';
import { usePlayer } from '../../context/PlayerContext';
import * as THREE from 'three';

const SPEED = 5;
const JUMP_FORCE = 5;
const CELL_SIZE = 2; // Must match MazeRenderer

const PlayerController = () => {
    const body = useRef();
    const [subscribeKeys, getKeys] = useKeyboardControls();
    const { camera } = useThree();
    const { updatePlayerPos, triggerScan, getLevelFromXP, playerRotationRef } = useGame(); // Link to MapContext & Scan Trigger

    // Raycaster for ground check
    const rapier = useRapier();

    // Force Camera to look forward on spawn
    React.useEffect(() => {
        camera.rotation.set(0, 0, 0); // Reset rotation
        camera.lookAt(new THREE.Vector3(0, 5, -100)); // Look at horizon
    }, [camera]);

    // Combat & Resources
    const { fireProjectile, fireBurst } = useCombat();
    const { lockResource } = usePlayer();

    // RESET POSITION ON FLOOR CHANGE (Dynamic Spawn)
    const { gameState } = useGame();
    React.useEffect(() => {
        if (body.current && gameState.spawnPoint) {
            const { x, z } = gameState.spawnPoint;

            // SpawnPoint is already in World Coordinates
            console.log("[PLAYER]: RESETTING_TO_SPAWN (1.5)");
            body.current.setTranslation({ x, y: 1.5, z }, true); // Lowered to 1.5 (Inside Maze)
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
            console.log(`[PLAYER]: SPAWN_RESET // FLOOR_${gameState.floorLevel} // POS [${x}, ${z}]`);
        }
    }, [gameState.floorLevel, gameState.spawnPoint]);

    // INPUT STATE
    const mouseDownTime = useRef(0);

    // COMBAT INPUT
    React.useEffect(() => {
        if (gameState.isPaused) return;

        const handleMouseDown = (e) => {
            if (!document.pointerLockElement) return;

            // LEFT CLICK: Record Start Time
            if (e.button === 0) {
                mouseDownTime.current = Date.now();
            }

            // RIGHT CLICK (2) -> BIT_FLIP (Magenta, 5 M-RAM)
            if (e.button === 2) {
                // ... same calculation for position ...
                const direction = new THREE.Vector3();
                camera.getWorldDirection(direction);
                const startPos = body.current.translation();
                const spawnPos = new THREE.Vector3(startPos.x, startPos.y + 1.5, startPos.z).add(direction.clone().multiplyScalar(0.2));

                if (lockResource(5)) {
                    fireProjectile(spawnPos, direction, 'SHRED');
                }
            }
        };

        const handleMouseUp = (e) => {
            if (!document.pointerLockElement || e.button !== 0) return;

            const duration = Date.now() - mouseDownTime.current;
            const direction = new THREE.Vector3();
            camera.getWorldDirection(direction);
            const startPos = body.current.translation();
            const spawnPos = new THREE.Vector3(startPos.x, startPos.y + 1.5, startPos.z).add(direction.clone().multiplyScalar(0.2));

            // LEVEL 5 CHECK (Exponential Curve)
            const playerLevel = getLevelFromXP(gameState.xp || 0);
            const canBurst = playerLevel >= 5;

            // CHARGE SHOT (Hold > 500ms)
            if (canBurst && duration > 500) {
                if (lockResource(25)) { // higher cost, efficiency
                    fireBurst(spawnPos, direction, 'PING');
                    console.log("[COMBAT]: BURST_COMPILE_COMPLETE");
                } else {
                    console.log("[SYSTEM]: INSUFFICIENT_RAM // BURST_FAILED");
                }
            } else {
                // STANDARD TAP
                if (lockResource(2)) {
                    fireProjectile(spawnPos, direction, 'PING');
                }
            }
        };

        const handleKeyDown = (e) => {
            if (!document.pointerLockElement) return;

            // 'E' -> SCAN PULSE (Green, 10 M-RAM)
            if (e.code === 'KeyE') {
                if (lockResource(10)) {
                    console.log("[PLAYER]: SCAN_INITIATED");
                    triggerScan();
                } else {
                    console.log("[SYSTEM]: INSUFFICIENT_RAM // UNABLE_TO_SCAN");
                }
            }
        };

        window.addEventListener('mousedown', handleMouseDown);
        window.addEventListener('mouseup', handleMouseUp);
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('mousedown', handleMouseDown);
            window.removeEventListener('mouseup', handleMouseUp);
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [gameState.isPaused, camera, fireProjectile, fireBurst, lockResource, triggerScan]);

    useFrame((state, delta) => {
        if (!body.current) return;

        let linvel = body.current.linvel();
        let translation = body.current.translation();

        // 1. FREEZE LOGIC
        const isFrozen = gameState.isTransitioning || !gameState.spawnPoint;



        if (isFrozen) {
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
            body.current.setAngvel({ x: 0, y: 0, z: 0 }, true);
            // Even if frozen, we must read valid translation for camera sync
            translation = body.current.translation();
        }
        else {
            // 2. MOVEMENT LOGIC (Only if Active)
            const { forward, backward, leftward, rightward, jump, run } = getKeys();

            // Calculate Movement Vector relative to Camera
            const forwardDir = new THREE.Vector3();
            camera.getWorldDirection(forwardDir);
            forwardDir.y = 0; // Flatten
            forwardDir.normalize();

            const rightDir = new THREE.Vector3();
            rightDir.crossVectors(forwardDir, new THREE.Vector3(0, 1, 0));

            const direction = new THREE.Vector3();

            if (forward) direction.add(forwardDir);
            if (backward) direction.sub(forwardDir);
            if (rightward) direction.add(rightDir);
            if (leftward) direction.sub(rightDir);

            if (direction.lengthSq() > 0) {
                const currentSpeed = run ? SPEED * 1.6 : SPEED;
                direction.normalize().multiplyScalar(currentSpeed);
            }

            // Apply Velocity (preserve vertical velocity for gravity)
            body.current.setLinvel({ x: direction.x, y: linvel.y, z: direction.z }, true);

            // SECTOR 4: MAGNETIC PULL
            if (gameState.floorLevel >= 76 && gameState.floorLevel <= 100) {
                const centerX = 50;
                const centerZ = 50;
                const dx = centerX - translation.x;
                const dz = centerZ - translation.z;
                body.current.applyImpulse({ x: dx * 0.01, y: 0, z: dz * 0.01 }, true);
            }

            // Jump
            if (jump && Math.abs(linvel.y) < 0.1) {
                body.current.applyImpulse({ x: 0, y: JUMP_FORCE, z: 0 }, true);
            }
        }

        // 3. SYNC CAMERA (ALWAYS RUNS)
        camera.position.set(translation.x, translation.y + 1.5, translation.z);

        // SYNC MAP
        const gridX = Math.round(translation.x / CELL_SIZE);
        const gridY = Math.round(translation.z / CELL_SIZE);
        updatePlayerPos(gridX, gridY);

        // VOID CATCH PROTOCOL (Bug -> Feature)
        if (translation.y < -10) {
            console.warn("[SYSTEM]: ANOMALY_DETECTED // PLAYER_FELL_INTO_VOID");
            // Respawn at Spawn Point if available, else Start
            const spawnX = gameState.spawnPoint ? gameState.spawnPoint.x : 2;
            const spawnZ = gameState.spawnPoint ? gameState.spawnPoint.z : 2;

            body.current.setTranslation({ x: spawnX, y: 5, z: spawnZ }, true); // Drop from safer height
            body.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
        }

        // SYNC CAMERA FOR COMPASS (Vector Math - Gimbal Lock Safe)
        if (playerRotationRef) {
            const dir = new THREE.Vector3();
            camera.getWorldDirection(dir);
            // 0 = North (-Z), PI/2 = West (-X), PI = South (+Z), -PI/2 = East (+X)
            // atan2(x, z) standard: 0 at (1,0) usually.
            // We want 0 at (0, -1). 
            // Math.atan2(x, z) -> angle from +Z axis?
            // Let's just pass the raw atan2(x, z) and let HUD shift if needed, 
            // BUT aligning 0 to North is safest.
            // North: x=0, z=-1.
            // atan2(0, -1) = PI.
            // atan2(0, 1) = 0. (South)
            // To make North 0: atan2(x, -z)?
            // North z=-1 -> -z=1. atan2(0, 1) = 0. Correct.
            playerRotationRef.current = Math.atan2(dir.x, -dir.z);
        }
    });

    return (
        <group>
            <RigidBody
                ref={body}
                colliders={false}
                position={[2, 2, 2]} // Lowered spawn
                enabledRotations={[false, false, false]}
                friction={0}
            >
                <CapsuleCollider args={[0.5, 0.5]} />
                <mesh visible={false}>
                    <capsuleGeometry args={[0.5, 1]} />
                    <meshStandardMaterial color="cyan" />
                </mesh>
            </RigidBody>

            {/* Only lock pointer if game is NOT paused */}
            {!gameState.isPaused && <PointerLockControls />}
        </group>
    );
};

const Player = () => {
    const keyboardMap = [
        { name: 'forward', keys: ['ArrowUp', 'KeyW'] },
        { name: 'backward', keys: ['ArrowDown', 'KeyS'] },
        { name: 'leftward', keys: ['ArrowLeft', 'KeyA'] },
        { name: 'rightward', keys: ['ArrowRight', 'KeyD'] },
        { name: 'jump', keys: ['Space'] },
        { name: 'run', keys: ['Shift'] },
    ];

    return (
        <KeyboardControls map={keyboardMap}>
            <PlayerController />
        </KeyboardControls>
    );
};

export default Player;
