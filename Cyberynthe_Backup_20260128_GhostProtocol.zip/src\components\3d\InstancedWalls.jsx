import React, { useMemo, useRef, useEffect } from 'react';
import { InstancedRigidBodies } from '@react-three/rapier';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

/**
 * IDENTITY: ARCH_SYS_01_SUB
 * DIRECTIVE: Instanced Wall Rendering
 * UPDATE: Sector 2 Render Stutter
 */

const CHUNK_SIZE = 16;

const WallChunk = React.memo(({ chunkKey, instances, wallMaterial, cellSize, wallHeight, isSector2 }) => {
    const meshRef = useRef();

    // SECTOR 2 STUTTER (Glitch Effect)
    useFrame((state) => {
        if (!isSector2 || !meshRef.current) return;

        // Random Glitch: 0.5% chance to toggle visibility per frame
        if (Math.random() < 0.005) {
            meshRef.current.visible = !meshRef.current.visible;
        }
        // Force restore visibility if hidden (10% chance per frame) to prevent long blackouts
        if (!meshRef.current.visible && Math.random() < 0.1) {
            meshRef.current.visible = true;
        }
    });

    // Compute Bounding Sphere for just this chunk
    React.useLayoutEffect(() => {
        if (meshRef.current) {
            meshRef.current.geometry.computeBoundingSphere(); // Default works if instances are localized?
            // Actually, for InstancedMesh, default sphere is radius 1 at origin. 
            // We need to compute it based on the instances' spread.
            // But doing it manually per chunk is easier:
            // Center = Chunk Center. Radius = Chunk Diagonal / 2.
            // Chunk is 16*2=32 units wide. Diagonal = sqrt(32^2 + 32^2) = 45. Radius = 23.

            // To be safe, let's keep it simple: 
            // If we don't set it, Three.js uses the geometry's bounding sphere, which is small. Culling will fail (falsely cull).
            // So we MUST expand it.

            // Let's assume standard density.
            const chunkWorldSize = CHUNK_SIZE * cellSize;
            const radius = (chunkWorldSize * 1.414) / 2;

            // We need the center in Local Space? 
            // The instances have World Position. The Mesh is at 0,0,0.
            // So we need clear coordinates.
            // Let's parse the key "cx-cy" to find center.
            const [cx, cy] = chunkKey.split('-').map(Number);
            const centerX = (cx * CHUNK_SIZE * cellSize) + (chunkWorldSize / 2);
            const centerZ = (cy * CHUNK_SIZE * cellSize) + (chunkWorldSize / 2);

            meshRef.current.geometry.boundingSphere = new THREE.Sphere(
                new THREE.Vector3(centerX, wallHeight / 2, centerZ),
                radius
            );
        }
    }, [chunkKey, cellSize, wallHeight]);

    return (
        <InstancedRigidBodies instances={instances} type="fixed" colliders="cuboid">
            <instancedMesh
                ref={meshRef}
                args={[null, null, instances.length]}
                count={instances.length}
                castShadow={false}
                receiveShadow
                frustumCulled={false}
            >
                <boxGeometry args={[cellSize, wallHeight, cellSize]} />
                <primitive object={wallMaterial} attach="material" />
            </instancedMesh>
        </InstancedRigidBodies>
    );
});

export default function InstancedWalls({ maze, wallMaterial, cellSize, wallHeight, floorLevel }) {

    // Determine Sector
    const isSector2 = floorLevel >= 26 && floorLevel <= 50;

    // 1. Group Walls into Chunks
    const chunks = useMemo(() => {
        const chunkMap = new Map();

        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell === 0) { // WALL
                    const cx = Math.floor(x / CHUNK_SIZE);
                    const cy = Math.floor(z / CHUNK_SIZE);
                    const key = `${cx}-${cy}`;

                    if (!chunkMap.has(key)) chunkMap.set(key, []);

                    chunkMap.get(key).push({
                        key: `wall-${x}-${z}`,
                        position: [x * cellSize, wallHeight / 2, z * cellSize],
                        rotation: [0, 0, 0],
                        scale: [1, 1, 1]
                    });
                }
            });
        });
        return Array.from(chunkMap.entries());
    }, [maze, cellSize, wallHeight]);

    return (
        <group>
            {chunks.map(([key, instances]) => (
                <WallChunk
                    key={key}
                    chunkKey={key}
                    instances={instances}
                    wallMaterial={wallMaterial}
                    cellSize={cellSize}
                    wallHeight={wallHeight}
                    isSector2={isSector2}
                />
            ))}
        </group>
    );
}
