import React, { useMemo, useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { MobLogic } from '../../engine/MobAI';
import { useCombat } from '../../context/CombatContext';
import { useGame } from '../../context/GameContext';
import * as THREE from 'three';

/**
 * IDENTITY: SCHEDULER_03
 * DIRECTIVE: Manage Entity Lifecycle (Spawning, AI, Rendering)
 */

const MAX_MOBS = 50; // Cap to prevent infinite loops and stabilize InstancedMesh

export default function MobManager({ maze, floorLevel }) {
    const [mobs, setMobs] = useState([]);
    const { positionBuffer, lifeBuffer, typeBuffer, MAX_PROJECTILES, triggerImpact } = useCombat();
    const { gameState, setGameState, addNotification, updateBossStatus, getLevelFromXP, setBossSubtitle } = useGame();

    // Instancing Refs
    const meshRef = useRef();
    const xrayMeshRef = useRef();
    const spawnQueue = useRef([]); // For adding mobs mid-frame
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // INITIAL SPAWN LOGIC (Run once per maze generation)
    React.useEffect(() => {
        if (!maze || !maze.grid) return;

        console.log(`[SCHEDULER]: ANALYZING_SPAWN_VECTORS (FLOOR ${floorLevel})`);
        const newMobs = [];
        const deadEnds = [];

        // 1. Identify Spawn Points
        maze.grid.forEach((row, z) => {
            row.forEach((cell, x) => {
                if (cell !== 1) return; // Only Floor
                let walls = 0;
                if (x === 0 || maze.grid[z][x - 1] === 0) walls++;
                if (x === maze.width - 1 || maze.grid[z][x + 1] === 0) walls++;
                if (z === 0 || maze.grid[z - 1][x] === 0) walls++;
                if (z === maze.height - 1 || maze.grid[z + 1][x] === 0) walls++;

                if (walls >= 3) deadEnds.push({ x, z });
            });
        });

        // 2. BOSS CHECK (Floor 10 Specific)
        if (floorLevel === 10) {
            console.log("[SCHEDULER]: INITIALIZING_FLOOR_10_PROTOCOL");
            const exitPos = maze.metadata.exit || { x: 50, y: 50 };

            // LOCK PORTAL
            setGameState(prev => ({ ...prev, isPortalLocked: true }));
            addNotification("WARNING: GATEKEEPER_DETECTED");

            // BOSS DIALOGUE: INTRO
            setBossSubtitle("UNREGISTERED_PROCESS_DETECTED. INITIATING_SCRUB.", 4000);

            const bossData = MobLogic.createMob('IO_SENTINEL', floorLevel);
            if (bossData) {
                console.log(`[SCHEDULER]: SPAWNING_BOSS @ [${exitPos.x}, ${exitPos.y}] (World: ${exitPos.x * 2}, ${exitPos.y * 2})`);
                newMobs.push({
                    ...bossData,
                    instanceId: Math.random(),
                    x: exitPos.x * 2,
                    z: exitPos.y * 2,
                    phase: 1, // 1: Beam, 2: Spawn
                    summonTimer: 0
                });
                updateBossStatus({ active: true, name: bossData.name, hp: bossData.currentHp, maxHp: bossData.maxHp });
            }
        }
        // SECTOR BOSSES (Every 25 Floors)
        else if (floorLevel % 25 === 0 && deadEnds.length > 0) {
            const bossPos = deadEnds.pop();
            const bossData = MobLogic.createMob('SECTOR_GUARDIAN', floorLevel);
            if (bossData) newMobs.push({ ...bossData, instanceId: Math.random(), x: bossPos.x * 2, z: bossPos.z * 2 });
        }

        // 3. Populate Regular Mobs
        if (floorLevel !== 10) {
            deadEnds.forEach(pos => {
                const rand = Math.random();
                if (rand < 0.05) { // 5% HUNTER
                    const hunterData = MobLogic.createMob('HUNTER', floorLevel || 1);
                    if (hunterData) {
                        newMobs.push({ ...hunterData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
                    }
                } else if (rand < 0.4) {
                    const count = Math.floor(Math.random() * 2) + 1;
                    for (let i = 0; i < count; i++) {
                        const mobData = MobLogic.createMob('BIT_MITE', floorLevel || 1);
                        if (mobData) {
                            newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2 + (Math.random() - 0.5), z: pos.z * 2 + (Math.random() - 0.5) });
                        }
                    }
                } else if (rand > 0.8) {
                    const mobData = MobLogic.createMob('STATELESS_SENTRY', floorLevel || 1);
                    if (mobData) {
                        newMobs.push({ ...mobData, instanceId: Math.random(), x: pos.x * 2, z: pos.z * 2 });
                    }
                }
            });
        }

        console.log(`[SCHEDULER]: DEPLOYED ${newMobs.length} HOSTILES`);
        setMobs(newMobs.slice(0, MAX_MOBS));

    }, [maze, floorLevel]);

    // COMBAT, AI & RENDERING LOOP
    useFrame((state, delta) => {
        if (mobs.length === 0 || !gameState.playerGridPos || !meshRef.current) return;

        let mobsDirty = false;

        // 1. UPDATE LOGIC & INSTANCES
        mobs.forEach((mob, i) => {
            const playerX = (gameState.playerGridPos?.x || 1) * 2;
            const playerZ = (gameState.playerGridPos?.y || 1) * 2;
            const dx = playerX - mob.x;
            const dz = playerZ - mob.z;
            const distSq = dx * dx + dz * dz;

            // AI CULLING & LOGIC
            const isHunter = mob.id === 'HUNTER';

            if (distSq > 900) {
                if (isHunter) {
                    if (distSq > 3600) {
                        const angle = Math.atan2(dz, dx);
                        const spawnDist = 40;
                        mob.x = playerX - Math.cos(angle) * spawnDist;
                        mob.z = playerZ - Math.sin(angle) * spawnDist;
                        mob.x += (Math.random() - 0.5) * 4;
                        mob.z += (Math.random() - 0.5) * 4;
                    }
                } else {
                    // DESPAWN (Hide & Sleep)
                    tempObject.scale.setScalar(0);
                    tempObject.updateMatrix();
                    meshRef.current.setMatrixAt(i, tempObject.matrix);
                    if (xrayMeshRef.current) xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                    return; // SKIP AI logic for distant NON-HUNTERS
                }
            }

            // COLLISION HELPER
            const margin = 0.7;
            const checkCollision = (cx, cz) => {
                const gx = Math.round(cx / 2);
                const gz = Math.round(cz / 2);
                if (gx >= 0 && gx < maze.width && gz >= 0 && gz < maze.height) {
                    return maze.grid[gz][gx] === 0;
                }
                return true;
            };

            // AI MOVEMENT
            if (distSq > 1 && (mob.id === 'BIT_MITE' || mob.id === 'HUNTER')) {
                const len = Math.sqrt(distSq);
                const speed = mob.id === 'HUNTER' ? 3.5 : 2.0;
                const moveX = (dx / len) * speed * delta;
                const moveZ = (dz / len) * speed * delta;
                const nextX = mob.x + moveX;
                const nextZ = mob.z + moveZ;

                if (!checkCollision(nextX, nextZ) && !checkCollision(nextX + margin, nextZ) && !checkCollision(nextX - margin, nextZ)) {
                    mob.x = nextX;
                    mob.z = nextZ;
                } else {
                    if (!checkCollision(nextX, mob.z)) mob.x = nextX;
                    else if (!checkCollision(mob.x, nextZ)) mob.z = nextZ;
                }
            }

            // SEPARATION FORCE
            let sepX = 0;
            let sepZ = 0;
            mobs.forEach((other, j) => {
                if (i === j) return;
                const sdx = mob.x - other.x;
                const sdz = mob.z - other.z;
                const sDistSq = sdx * sdx + sdz * sdz;
                if (sDistSq < 0.25) {
                    const sLen = Math.sqrt(sDistSq) || 0.1;
                    sepX += (sdx / sLen) / sDistSq;
                    sepZ += (sdz / sLen) / sDistSq;
                }
            });

            if (Math.abs(sepX) > 0.01 || Math.abs(sepZ) > 0.01) {
                const pushX = sepX * delta * 2;
                const pushZ = sepZ * delta * 2;
                const nextX = mob.x + pushX;
                const nextZ = mob.z + pushZ;
                if (!checkCollision(nextX, nextZ)) {
                    mob.x = nextX;
                    mob.z = nextZ;
                }
            }

            // HIT DETECTION (Using Buffers)
            if (positionBuffer && positionBuffer.current && lifeBuffer && lifeBuffer.current) {
                const pArr = positionBuffer.current;
                const lArr = lifeBuffer.current;
                const tArr = typeBuffer.current;

                for (let k = 0; k < MAX_PROJECTILES; k++) {
                    if (lArr[k] <= 0) continue;

                    const px = pArr[k * 3];
                    const py = pArr[k * 3 + 1];
                    const pz = pArr[k * 3 + 2];
                    const pdx = mob.x - px;
                    const pdz = mob.z - pz;

                    if (pdx * pdx + pdz * pdz < 0.6) {
                        let damage = 10;
                        let isCrit = false;

                        if (mob.scanTimer > 0) {
                            damage *= 2.5;
                            isCrit = true;
                        }

                        if (tArr[k] === 1) { // SHRED
                            mob.isHacked = true;
                            mob.hackTimer = 5.0;
                        }

                        mob.currentHp -= damage;
                        mob.lastHitTime = Date.now();
                        lArr[k] = 0;

                        triggerImpact(new THREE.Vector3(px, py, pz), isCrit ? '#EA00FF' : '#FFFF00');

                        if (mob.id === 'IO_SENTINEL' || mob.id === 'SECTOR_GUARDIAN') {
                            updateBossStatus({ hp: mob.currentHp });
                            // BOSS DIALOGUE: DAMAGE (Chance)
                            if (mob.id === 'IO_SENTINEL' && Math.random() < 0.1) {
                                setBossSubtitle("INTEGRITY_LEAK_DETECTED. RE-ROUTING_COOLANT.", 2000);
                            }
                        }
                    }
                }
            }

            // DEATH CHECK
            if (mob.currentHp <= 0) {
                if (!mob.isDead) {
                    mob.isDead = true;
                    mobsDirty = true;
                    // BOSS DIALOGUE: DEATH
                    if (mob.id === 'IO_SENTINEL') {
                        setBossSubtitle("FATAL_ERROR. GUEST_PERMISSION_ELEVATED... KERNEL_KEY_RELEASED.", 5000);
                    }
                }
            }

            // SCAN LOGIC
            if (gameState.lastScanTime) {
                const scanAge = (Date.now() - gameState.lastScanTime) / 1000;
                if (scanAge < 2.5) {
                    const waveRadius = scanAge * 25;
                    const dist = Math.sqrt(distSq);
                    if (dist < waveRadius && dist > waveRadius - 5) {
                        mob.scanTimer = 10.0;
                    }
                }
            }
            if (mob.scanTimer > 0) mob.scanTimer -= delta;

            // RENDER MATRIX SETUP
            tempObject.position.set(mob.x, 1, mob.z);
            tempObject.lookAt(playerX, 1, playerZ);

            if (mob.id === 'SECTOR_GUARDIAN') {
                tempObject.scale.setScalar(3.0);
            } else if (mob.id === 'IO_SENTINEL') {
                tempObject.scale.setScalar(4.0);

                // BOSS DIALOGUE: PHASES
                if (mob.phase === 1) {
                    // Random Beam Dialogue
                    if (Math.random() < 0.005) { // Rare tick check
                        setBossSubtitle("ALIGNING_LOGIC_RAILS...", 2000);
                    }
                    if (mob.currentHp < (mob.maxHp * 0.6)) {
                        mob.phase = 2;
                        addNotification("WARNING: SENTINEL_PHASE_2 // BUFFER_OVERFLOW");
                        setBossSubtitle("WARNING: BUFFER_OVERFLOW. DEPLOYING_SUB-PROCESSES.", 4000);
                    }
                }

                if (mob.phase === 2) {
                    mob.summonTimer = (mob.summonTimer || 0) - delta;
                    if (mob.summonTimer <= 0) {
                        mob.summonTimer = 20.0; // Faster Spawns (was 30)
                        setBossSubtitle("FORK_PROCESS_01... FORK_PROCESS_02...", 3000);

                        const miteData = MobLogic.createMob('BIT_MITE', floorLevel);
                        if (miteData) {
                            // FIXED: SPAWN QUEUE LIMIT CHECK
                            const count = 5;
                            for (let k = 0; k < count; k++) {
                                // Check if adding more would exceed safe limits (Soft Check)
                                // We trust the main cleanup loop to keep it under 50 eventually, 
                                // but we shouldn't queue 100s.
                                if (spawnQueue.current.length < 10) {
                                    spawnQueue.current.push({
                                        ...miteData,
                                        instanceId: Math.random(),
                                        x: mob.x + (Math.random() - 0.5) * 4,
                                        z: mob.z + (Math.random() - 0.5) * 4
                                    });
                                }
                            }
                            mobsDirty = true;
                            addNotification("WARNING: SUB_PROCESSES_SPAWNED");
                        }
                    }
                }
            } else {
                tempObject.scale.setScalar(1.0);
            }

            tempObject.updateMatrix();
            meshRef.current.setMatrixAt(i, tempObject.matrix);

            // Render X-Ray
            if (xrayMeshRef.current) {
                if (mob.scanTimer > 0) {
                    xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                } else {
                    tempObject.scale.setScalar(0);
                    tempObject.updateMatrix();
                    xrayMeshRef.current.setMatrixAt(i, tempObject.matrix);
                }
            }

            // Render Color
            const isHit = mob.lastHitTime && Date.now() - mob.lastHitTime < 100;
            if (isHit) tempColor.setHex(0xFFFFFF);
            else if (mob.id === 'SECTOR_GUARDIAN') tempColor.setHex(0xFFD700);
            else if (mob.id === 'IO_SENTINEL') tempColor.setHex(0x00FFFF);
            else if (mob.id === 'HUNTER') tempColor.setHex(0xAA00FF);
            else tempColor.setHex(0xFF0000);
            meshRef.current.setColorAt(i, tempColor);
        });

        // 2. COMMIT RENDERS
        meshRef.current.instanceMatrix.needsUpdate = true;
        if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
        if (xrayMeshRef.current) xrayMeshRef.current.instanceMatrix.needsUpdate = true;

        // 3. PROCESS DEATHS & SPAWNS
        if (mobsDirty) {
            let pendingXp = 0;
            let totalBits = 0;
            const survivingMobs = mobs.filter(m => {
                if (m.currentHp <= 0) {
                    if (m.id === 'IO_SENTINEL') {
                        setGameState(prev => ({ ...prev, isPortalLocked: false }));
                        addNotification("GATEWAY_UNLOCKED: KEY_COMPILED");
                        addNotification("REWARD: 100 eBITS");
                        updateBossStatus({ active: false });
                        totalBits += 100;
                        pendingXp += 500;
                    } else if (m.id === 'SECTOR_GUARDIAN') {
                        updateBossStatus({ active: false });
                        pendingXp += 200;
                        totalBits += 50;
                    } else {
                        const playerLvl = getLevelFromXP(gameState.xp);
                        if (playerLvl < 5 || floorLevel >= 10) {
                            pendingXp += 10;
                        }
                        totalBits += Math.floor(Math.random() * 5) + 1;
                    }
                    return false;
                }
                return true;
            });

            if (spawnQueue.current.length > 0) {
                // FIXED: ENFORCE MAX_MOBS
                const availableSlots = MAX_MOBS - survivingMobs.length;
                if (availableSlots > 0) {
                    const toAdd = spawnQueue.current.slice(0, availableSlots);
                    survivingMobs.push(...toAdd);
                }
                spawnQueue.current = []; // Always clear queue to prevent backlog
            }

            setMobs(survivingMobs);

            if (pendingXp > 0) {
                addNotification(`THREAT_NEUTRALIZED: +${pendingXp} XP`);
                setGameState(prev => ({ ...prev, xp: (prev.xp || 0) + pendingXp, eBits: (prev.eBits || 0) + totalBits }));
            }
        }
    });

    return (
        <group>
            {/* MAIN PHYSICAL MESH */}
            <instancedMesh ref={meshRef} args={[null, null, MAX_MOBS]} count={mobs.length} frustumCulled={false}>
                <coneGeometry args={[0.4, 0.8, 4]} />
                <meshStandardMaterial
                    color="#FFFFFF"
                    emissive="#111111"
                    roughness={0.4}
                    metalness={0.6}
                />
            </instancedMesh>

            {/* X-RAY OVERLAY */}
            <instancedMesh ref={xrayMeshRef} args={[null, null, MAX_MOBS]} count={mobs.length} frustumCulled={false}>
                <coneGeometry args={[0.45, 0.85, 4]} />
                <meshBasicMaterial
                    color="#00FF00"
                    wireframe={true}
                    transparent={true}
                    opacity={0.5}
                    depthTest={false}
                    depthWrite={false}
                />
            </instancedMesh>
        </group>
    );
}
