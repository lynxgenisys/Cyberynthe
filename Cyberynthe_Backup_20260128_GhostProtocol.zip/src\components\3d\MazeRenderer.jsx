import React, { useMemo, useEffect, useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGame } from '../../context/GameContext';
// import { generateMaze } from '../../engine/MazeGenerator'; // Legacy Sync
// Worker Import handled via new URL() pattern
import { RigidBody, CuboidCollider } from '@react-three/rapier';
import MobManager from './MobManager';
import LootManager from './LootManager';
import InstancedWalls from './InstancedWalls';

import HazardManager from './HazardManager';
import * as THREE from 'three';

/**
 * IDENTITY: ARCH_SYS_01
 * DIRECTIVE: Render the 3D Labyrinth with HD Procedural Textures & Objectives
 * OPTIMIZATION: InstancedMesh for Walls (Draw Calls: ~1)
 */

// Advanced Procedural Texture Generator (Kept same)
const createProceduralTexture = (type) => {
    const size = 1024;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');

    if (type === 'WALL_GRID') {
        // 1. Base: Deep Cyber Blue-Black (Lightened)
        const gradient = ctx.createLinearGradient(0, 0, 0, size);
        gradient.addColorStop(0, '#151525');
        gradient.addColorStop(1, '#202030');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);

        // 2. Scanline Noise (High Res)
        ctx.fillStyle = '#0a0a20';
        for (let i = 0; i < size; i += 2) {
            if (Math.random() > 0.8) ctx.fillRect(0, i, size, 1);
        }

        // 3. The Grid (Cyan Glow)
        // Outer Glow
        ctx.strokeStyle = '#004444';
        ctx.lineWidth = 16;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#00FFFF';
        ctx.strokeRect(0, 0, size, size);

        // Core Line
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 6;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#FFFFFF';
        ctx.strokeRect(0, 0, size, size);

        // Cross-Section (Subtle)
        ctx.strokeStyle = '#008888';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(size / 2, 0); ctx.lineTo(size / 2, size);
        ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2);
        ctx.stroke();

        // 4. Data Nodes (Corners)
        ctx.fillStyle = '#00FFFF';
        ctx.shadowBlur = 30;
        ctx.shadowColor = '#00FFFF';
        const nodeSize = 24;
        ctx.fillRect(0, 0, nodeSize, nodeSize);
        ctx.fillRect(size - nodeSize, 0, nodeSize, nodeSize);
        ctx.fillRect(0, size - nodeSize, nodeSize, nodeSize);
        ctx.fillRect(size - nodeSize, size - nodeSize, nodeSize, nodeSize);
    }
    else if (type === 'FLOOR_PLATE') {
        // 1. Base: Deep Matte Grey
        ctx.fillStyle = '#101012';
        ctx.fillRect(0, 0, size, size);

        // 2. Hex Pattern (Geometric)
        ctx.strokeStyle = '#181820';
        ctx.lineWidth = 2;
        ctx.beginPath();
        const hexSize = size / 8;
        for (let y = 0; y < size; y += hexSize) {
            for (let x = 0; x < size; x += hexSize) {
                // Offset rows
                const xOff = (y / hexSize) % 2 === 0 ? 0 : hexSize / 2;
                ctx.strokeRect(x + xOff, y, hexSize, hexSize);

                // Random lit hexes
                if (Math.random() > 0.95) {
                    ctx.fillStyle = '#1a1a25';
                    ctx.fillRect(x + xOff + 2, y + 2, hexSize - 4, hexSize - 4);
                }
            }
        }
        ctx.stroke();

        // 3. Navigation Lines (Center)
        ctx.strokeStyle = '#0044aa';
        ctx.lineWidth = 4;
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2);
        ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.needsUpdate = true;
    return texture;
};

// Extracted EXIT Component to handle Scan State
const ExitTile = ({ x, z, gameState, advanceFloor, addNotification, WallHeight, CellSize }) => {
    const [scanTimer, setScanTimer] = useState(0);

    const meshRef = useRef();

    // SCAN & ANIMATION LOGIC
    useFrame((state, delta) => {
        // 1. ANIMATION (Rotate & Pulse)
        if (meshRef.current) {
            meshRef.current.rotation.y += delta * 0.5; // Slow Rotate
            const pulse = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.1; // 1.0 to 1.2
            meshRef.current.scale.setScalar(pulse);
        }

        // 2. SCAN VISIBILITY
        if (gameState.lastScanTime) {
            const playerX = gameState.playerGridPos?.x * 2 || 0;
            const playerZ = gameState.playerGridPos?.y * 2 || 0;
            const dx = playerX - x;
            const dz = playerZ - z;
            const distSq = dx * dx + dz * dz;

            const scanAge = (Date.now() - gameState.lastScanTime) / 1000;
            if (scanAge < 2.5) {
                const waveRadius = scanAge * 25;
                const dist = Math.sqrt(distSq);
                if (dist < waveRadius && dist > waveRadius - 5) {
                    if (scanTimer <= 0) setScanTimer(10.0);
                }
            }
        }
        if (scanTimer > 0) setScanTimer(prev => prev - delta);
    });

    return (
        <RigidBody
            type="fixed"
            sensor
            onIntersectionEnter={() => {
                if (gameState.isPortalLocked) {
                    // console.log("[SYSTEM]: PORTAL_LOCKED"); // Removed for spam
                    addNotification("PORTAL_LOCKED: DEFEAT_SENTINEL");
                } else {
                    addNotification("PORTAL_BREACH: ADVANCING...");
                    advanceFloor();
                }
            }}
            position={[x, 0, z]}
        >
            <group>
                <pointLight
                    color={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                    intensity={2}
                    distance={5}
                    position={[0, 2, 0]}
                />
                <mesh ref={meshRef} position={[0, WallHeight / 2, 0]}>
                    <torusGeometry args={[1, 0.2, 16, 32]} />
                    <meshStandardMaterial
                        color={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                        emissive={gameState.isPortalLocked ? "#FF0000" : "#EA00FF"}
                        emissiveIntensity={2}
                    />
                </mesh>

                {/* SCAN REVEAL BEACON */}
                {scanTimer > 0 && (
                    <mesh position={[0, 10, 0]}> {/* Tall Beacon */}
                        <cylinderGeometry args={[0.1, 0.1, 20]} />
                        <meshBasicMaterial color="#EA00FF" transparent opacity={0.5} depthTest={false} />
                    </mesh>
                )}
            </group>
        </RigidBody>
    );
};

export default function MazeRenderer() {
    // ... (Hooks kept same)
    const { gameState, advanceFloor, setGameState, addNotification } = useGame();

    // CONSTANTS
    const CELL_SIZE = 2;
    const WALL_HEIGHT = 4;

    // 1. GENERATE MAZE (Async Web Worker)
    const [maze, setMaze] = useState(null);

    useEffect(() => {
        // Clear previous maze immediately to prevent ghost rendering while worker matches new seed
        setMaze(null);

        // Instantiate Worker
        const worker = new Worker(new URL('../../workers/maze.worker.js', import.meta.url), { type: 'module' });

        worker.onmessage = (e) => {
            if (e.data.success) {
                console.log(`[MAZE_RENDERER]: Worker Success | ${e.data.data.width}x${e.data.data.height}`);
                setMaze(e.data.data);
            } else {
                console.error('[MAZE_RENDERER]: Worker Failed', e.data.error);
            }
            worker.terminate(); // One-shot usage
        };

        worker.postMessage({ seed: gameState.seed, floorLevel: gameState.floorLevel });

        return () => {
            worker.terminate();
        };
    }, [gameState.seed, gameState.floorLevel]);





    // 3. MATERIALS (Memory Safe)
    const [materials, setMaterials] = useState(null);

    useEffect(() => {
        const wallTex = createProceduralTexture('WALL_GRID');
        const floorTex = createProceduralTexture('FLOOR_PLATE');

        const wallMat = new THREE.MeshStandardMaterial({
            color: '#FFFFFF',
            emissive: '#00FFFF',
            emissiveIntensity: 0.8,
            emissiveMap: wallTex,
            roughness: 0.2,
            metalness: 0.8,
            map: wallTex
        });

        const floorMat = new THREE.MeshStandardMaterial({
            color: '#8888aa',
            roughness: 0.5,
            metalness: 0.5,
            map: floorTex
        });

        setMaterials({ wall: wallMat, floor: floorMat });

        return () => {
            console.log('[RENDERER]: DISPOSING MATERIALS & TEXTURES');
            wallMat.dispose();
            if (wallMat.map) wallMat.map.dispose();
            if (wallMat.emissiveMap) wallMat.emissiveMap.dispose();
            floorMat.dispose();
            if (floorMat.map) floorMat.map.dispose();
        };
    }, []);

    if (!maze || !materials) return null;

    return (
        <MazeScene
            maze={maze}
            materials={materials}
            gameState={gameState}
            advanceFloor={advanceFloor}
            addNotification={addNotification}
            setGameState={setGameState}
            CELL_SIZE={CELL_SIZE}
            WALL_HEIGHT={WALL_HEIGHT}
        />
    );
}

// Sub-Component: Only renders when data is ready. Guarantees hook stability.
function MazeScene({ maze, materials, gameState, advanceFloor, addNotification, setGameState, CELL_SIZE, WALL_HEIGHT }) {
    const { wall: wallMaterial, floor: floorMaterial } = materials;

    // SYNC SPAWN POINT
    useEffect(() => {
        if (maze.metadata?.start) {
            const startNode = maze.metadata.start;
            setGameState(prev => ({
                ...prev,
                spawnPoint: { x: startNode.x * CELL_SIZE, y: 1.5, z: startNode.y * CELL_SIZE },
                playerGridPos: { x: startNode.x, y: startNode.y },
                mazeGrid: maze.grid,
                mazeWidth: maze.width,
                mazeHeight: maze.height
            }));
        }
    }, [maze, setGameState]);

    return (
        <group>
            {/* 1. INSTANCED GEOMETRY */}
            <InstancedWalls
                key={`walls-${gameState.floorLevel}`}
                maze={maze}
                wallMaterial={wallMaterial}
                cellSize={CELL_SIZE}
                wallHeight={WALL_HEIGHT}
                floorLevel={gameState.floorLevel}
            />

            {/* 2. DYNAMIC OBJECTS */}
            {maze.metadata?.start && (
                <group position={[maze.metadata.start.x * CELL_SIZE, 0.1, maze.metadata.start.y * CELL_SIZE]}>
                    <mesh rotation={[-Math.PI / 2, 0, 0]}>
                        <ringGeometry args={[0.5, 0.8, 32]} />
                        <meshStandardMaterial color="#00FFFF" emissive="#00FFFF" emissiveIntensity={1} />
                    </mesh>
                </group>
            )}

            {maze.metadata?.exit && (
                <ExitTile
                    key={`exit-${maze.metadata.exit.x}-${maze.metadata.exit.y}`}
                    x={maze.metadata.exit.x * CELL_SIZE}
                    z={maze.metadata.exit.y * CELL_SIZE}
                    gameState={gameState}
                    advanceFloor={advanceFloor}
                    addNotification={addNotification}
                    WallHeight={WALL_HEIGHT}
                    CellSize={CELL_SIZE}
                />
            )}

            {/* FLOOR PLANE */}
            <RigidBody
                key={`floor-${maze.width}-${maze.height}`}
                type="fixed"
                rotation={[-Math.PI / 2, 0, 0]}
                position={[maze.width, -0.1, maze.height]}
            >
                <mesh receiveShadow>
                    <planeGeometry args={[maze.width * CELL_SIZE * 2, maze.height * CELL_SIZE * 2]} />
                    <primitive object={floorMaterial} attach="material" />
                </mesh>
            </RigidBody>

            {/* MOBS */}
            <MobManager maze={maze} floorLevel={gameState.floorLevel} />

            {/* HAZARDS */}
            <HazardManager maze={maze} floorLevel={gameState.floorLevel} />

            {/* LOOT */}
            <LootManager maze={maze} floorLevel={gameState.floorLevel} />
        </group>
    );
}
