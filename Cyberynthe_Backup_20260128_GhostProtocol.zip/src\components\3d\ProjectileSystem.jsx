import React, { useRef, useMemo, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useCombat } from '../../context/CombatContext';
import { useGame } from '../../context/GameContext';
import * as THREE from 'three';

/**
 * IDENTITY: LOGIC_BREACH_02
 * DIRECTIVE: Render Active Projectiles (OPTIMIZED)
 * MECHANIC: InstancedMesh for <1 draw call per frame
 */

const MAX_PROJECTILES = 200;

export default function ProjectileSystem() {
    const { positionBuffer, velocityBuffer, lifeBuffer, typeBuffer, MAX_PROJECTILES, triggerImpact } = useCombat();
    const { gameState } = useGame();
    const meshRef = useRef();

    // Reusable Temporary Objects
    const tempObject = useMemo(() => new THREE.Object3D(), []);
    const tempColor = useMemo(() => new THREE.Color(), []);

    // Initialize Color Buffer
    useLayoutEffect(() => {
        if (meshRef.current) {
            meshRef.current.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_PROJECTILES * 3), 3);
        }
    }, [MAX_PROJECTILES]);

    useFrame((state, delta) => {
        const mesh = meshRef.current;
        if (!mesh) return;

        const pArr = positionBuffer.current;
        const vArr = velocityBuffer.current;
        const lArr = lifeBuffer.current;
        const tArr = typeBuffer.current;

        // Iterate ALL slots (Ring Buffer is sparse)
        // Optimization: 200 items is negligible for CPU loop.
        for (let i = 0; i < MAX_PROJECTILES; i++) {
            if (lArr[i] <= 0) {
                // INACTIVE: Hide
                tempObject.scale.setScalar(0);
                tempObject.updateMatrix();
                mesh.setMatrixAt(i, tempObject.matrix);
                continue;
            }

            // ACTIVE: Update Physics
            lArr[i] -= delta;

            if (lArr[i] <= 0) {
                // Just died in this frame
                tempObject.scale.setScalar(0);
                tempObject.updateMatrix();
                mesh.setMatrixAt(i, tempObject.matrix);
                continue;
            }

            // Move
            const idx3 = i * 3;
            pArr[idx3] += vArr[idx3] * delta;
            pArr[idx3 + 1] += vArr[idx3 + 1] * delta;
            pArr[idx3 + 2] += vArr[idx3 + 2] * delta;

            const px = pArr[idx3];
            const py = pArr[idx3 + 1];
            const pz = pArr[idx3 + 2];

            // COLLISION: WALL
            const gx = Math.round(px / 2);
            const gz = Math.round(pz / 2);

            if (gameState.mazeGrid) {
                if (gx >= 0 && gx < gameState.mazeWidth && gz >= 0 && gz < gameState.mazeHeight) {
                    if (gameState.mazeGrid[gz][gx] === 0) { // WALL
                        lArr[i] = 0;
                        // Impact Logic (Cyan)
                        triggerImpact({ x: px, y: py, z: pz }, '#00FFFF');
                    }
                }
            }

            // COLLISION: FLOOR
            if (py <= 0.2) {
                lArr[i] = 0;
                triggerImpact({ x: px, y: 0, z: pz }, '#00FFFF');
            }

            // RENDER
            tempObject.position.set(px, py, pz);

            // Look At Velocity
            // Target = Pos + Vel
            tempObject.lookAt(px + vArr[idx3], py + vArr[idx3 + 1], pz + vArr[idx3 + 2]);

            // Scale Effect (Bloom Pulse?)
            tempObject.scale.setScalar(1);

            tempObject.updateMatrix();
            mesh.setMatrixAt(i, tempObject.matrix);

            // COLOR
            const isPing = tArr[i] === 0; // 0=PING
            tempColor.set(isPing ? '#00FFFF' : '#FF00FF');
            tempColor.multiplyScalar(3);
            mesh.setColorAt(i, tempColor);
        }

        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    });


    return (
        <instancedMesh ref={meshRef} args={[null, null, MAX_PROJECTILES]} frustumCulled={false}>
            {/* Narrower "Laser" Beam (1/4 Width) */}
            <boxGeometry args={[0.2, 0.05, 0.05]} />
            <meshBasicMaterial
                toneMapped={false}
                color="#FFFFFF" // Tinted by instanceColor
            />
        </instancedMesh>
    );
}
