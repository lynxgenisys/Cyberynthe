import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Physics } from '@react-three/rapier';
import { EffectComposer, Bloom, Noise, Vignette } from '@react-three/postprocessing';
import MazeRenderer from './MazeRenderer';
import Player from './Player';
import ProjectileSystem from './ProjectileSystem';
import ImpactSystem from './ImpactSystem';
import Shockwave from './Shockwave';

import { Stars } from '@react-three/drei';

const CyberScene = () => {
    return (
        <>
            <color attach="background" args={['#050110']} />
            <fog attach="fog" args={['#050110', 5, 60]} /> {/* Fade into Deep Void */}
            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />

            {/* AMBIENT GLOW */}
            {/* AMBIENT GLOW (Neutral White to verify textures) */}
            <ambientLight intensity={0.8} color="#FFFFFF" />
            <pointLight position={[10, 10, 10]} intensity={1} color="#EA00FF" />

            <Physics gravity={[0, -20, 0]}>
                <MazeRenderer />
                <Player />
            </Physics>

            <ProjectileSystem />
            <ImpactSystem />
            <Shockwave />

            {/* POST PROCESSING */}
            <EffectComposer>
                <Bloom luminanceThreshold={0} luminanceSmoothing={0.9} height={300} intensity={0.5} />
                <Noise opacity={0.1} />
                <Vignette eskil={false} offset={0.1} darkness={1.1} />
            </EffectComposer>
        </>
    );
};

export default function Scene3D() {
    return (
        <div className="absolute inset-0 -z-10">
            <Canvas shadows camera={{ position: [0, 5, 0], fov: 60 }}>
                <Suspense fallback={null}>
                    <CyberScene />
                </Suspense>
            </Canvas>
        </div>
    );
}
